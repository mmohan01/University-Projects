﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Mime;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using Microsoft.Research.Kinect.Nui;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Shared;

namespace ModelViewer
{
    public class KinectStructure
    {
        #region Properties

        /// <summary>
        /// Kinect joint positions.
        /// </summary>
        public List<Vector3> Joints { get; set; }

        /// <summary>
        /// Overall skeleton position.
        /// </summary>
        public Vector3 Position { get; set; }

        #endregion

        #region Fields

        private static StreamWriter streamWriter;

        #endregion

        public KinectStructure(List<Vector3> joints, Vector3 position)
        {
            Joints = joints;
            Position = position;
        }

        /// <summary>
        /// Open a new animation file for the kinect data.
        /// </summary>
        /// <param name="filename"></param>
        /// <returns></returns>
        public static bool CreateNewRecording(string filename, Vector3 offset, float scale)
        {
            try
            {
                FileStream fs = new FileStream(filename, FileMode.Create, FileAccess.Write);
                streamWriter = new StreamWriter(fs);
            }
            catch (IOException e)
            {
                return false;
            }
            streamWriter.WriteLine("#Offset");
            streamWriter.WriteLine(offset);
            streamWriter.WriteLine("#Scale");
            streamWriter.WriteLine(scale);
            return true;
        }

        /// <summary>
        /// Write a new animation frame to the file.
        /// </summary>
        /// <param name="frame"></param>
        public static void WriteFrame(AnimationClip frame, TimeSpan duration)
        {
            if (streamWriter == null)
                return;
            
            foreach (Keyframe f in frame.Keyframes)
            {
                streamWriter.WriteLine("#Frame");
                streamWriter.WriteLine(duration.TotalMilliseconds);
                streamWriter.WriteLine(f.Bone);
                streamWriter.WriteLine(f.Transform);
            }
        }

        /// <summary>
        /// Close the animation file.
        /// </summary>
        public static void StopRecording()
        {
            if (streamWriter != null)
            {
                streamWriter.WriteLine("#End");
                streamWriter.Close();
                streamWriter = null;
            }
        }

        /// <summary>
        /// Load saved kinect animation.
        /// </summary>
        /// <param name="filename"></param>
        /// <returns></returns>
        public static AnimationClip LoadAnimationClip(string filename, Dictionary<int, int> kinectSkeletonMap)
        {
            try
            {
                TextReader r = new StreamReader(filename);

                float scale = 1;
                Vector3 offset;
                List<Keyframe> keyframes = new List<Keyframe>();
                var duration = new TimeSpan();

                string line = r.ReadLine();
                while (line != null && line != "#End")
                {
                    if(line == "#Offset")
                    {
                        offset = ReadVector3(r.ReadLine());
                    }
                    else if (line == "#Scale")
                    {
                        scale = float.Parse(r.ReadLine());
                    }
                    else if (line == "#End")
                    {
                        break;
                    }
                    else if (line == "#Frame")
                    {
                        var strDuration = r.ReadLine();
                        var frameDuration = TimeSpan.FromMilliseconds(double.Parse(strDuration));
                        line = r.ReadLine();
                        //Bone
                        int bone = int.Parse(line);
                        line = r.ReadLine();
                        //Matrix
                        Matrix m = ReadMatrix(line);
                        Keyframe frame = new Keyframe(bone, frameDuration, m);
                        keyframes.Add(frame);
                    }
                    else
                    {
                        line = r.ReadLine();
                    }
                }

                return new AnimationClip(duration, keyframes);
            }
            catch
            {
                
            }
            return null;
        }

        private static Matrix ReadMatrix(string line)
        {
            //{ {M11:1 M12:0 M13:0 M14:0} {M21:0 M22:1 M23:0 M24:0} {M31:0 M32:0 M33:1 M34:0} {M41:0.1071188 M42:-3.145712E-08 M43:-2.63794 M44:1} }
            line = line.Replace("{ ", "");

            string[] items = new string[16];
            for (int i = 0; i < 16; i+=4)
            {
                //{M11:
                line = line.Remove(0, 5);
                items[i] = line.Substring(0, line.IndexOf(" "));
                line = line.Substring(line.IndexOf(" ") + 1);
                //M12:
                line = line.Remove(0, 4);
                items[i + 1] = line.Substring(0, line.IndexOf(" "));
                line = line.Substring(line.IndexOf(" ") + 1);
                //M13:
                line = line.Remove(0, 4);
                items[i + 2] = line.Substring(0, line.IndexOf(" "));
                line = line.Substring(line.IndexOf(" ") + 1);
                //M14:
                line = line.Remove(0, 4);
                items[i + 1] = line.Substring(0, line.IndexOf("}"));
                line = line.Substring(line.IndexOf("}") + 2);
            }
            float[] fitems = new float[16];
            for(int i = 0; i < 16; i++)
                fitems[i] = float.Parse(items[i]);
            return new Matrix(fitems[0], fitems[1], fitems[2], fitems[3],
                fitems[4], fitems[5], fitems[6], fitems[7],
                fitems[8], fitems[9], fitems[10], fitems[11],
                fitems[12], fitems[13], fitems[14], fitems[15]);
        }

        private static Vector3 ReadVector3(string item)
        {
            //{X:0.2444362 Y:0.1245253 Z:2.216544}
            item = item.Replace("{", "").Replace("}", "");
            string[] xyz = item.Split(' ');
            float x = float.Parse(xyz[0].Replace("X:", ""));
            float y = float.Parse(xyz[1].Replace("Y:", ""));
            float z = float.Parse(xyz[2].Replace("Z:", ""));
            return new Vector3(x, y, z);
        }
    }
}
