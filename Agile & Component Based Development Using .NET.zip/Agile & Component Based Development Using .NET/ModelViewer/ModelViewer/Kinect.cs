﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using Microsoft.Research.Kinect.Nui;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Shared;

namespace ModelViewer
{
    /// <summary>
    /// Contains all functions to use and map the kinect data to a model.
    /// </summary>
    public class Kinect
    {
        #region Properties

        /// <summary>
        /// Has the Kinect been fully initialized.
        /// </summary>
        public bool Initialized { get; set; }

        /// <summary>
        /// Kinect skeletal information.
        /// </summary>
        public SkeletonData SkeletonData { get; private set; }

        /// <summary>
        /// Scale value for kinect skeleton.
        /// </summary>
        public float ModelScale { get; set; }

        /// <summary>
        /// Position offset for kinect skeleton.
        /// </summary>
        public Vector3 ModelOffset { get; set; }

        /// <summary>
        /// Fired when the first frame of the skeleton has been obtained.
        /// </summary>
        public event EventHandler SkeletonFirstFrameReady;

        #endregion

        #region Private

        private bool gotFirstSkeletonFrame = false;
        private Runtime nui;
        private Dictionary<int, int> kinectSkeletonMap;

        //Local transforms for model
        private Matrix[] modelTransforms;
        //Initalial bone translations.
        private List<Vector3> translations;
        //Minimum point on kinect skeleton to move it all into positive coords
        private Vector2 minimumPoint = new Vector2();
        //Inital root bone rotation so we can move the whole model from the root translation
        private Quaternion rootRotation;

        //Animation clip
        List<Keyframe> animationKeyframes = new List<Keyframe>();

        //Filter variables
        private Vector3[] movingAveragePositions = new Vector3[10];
        private int movingAverageCurrentIndex = 0;
        private Vector3 movingAveragePosition = Vector3.Zero;

        #region Kinect Hierarch
        Dictionary<JointID, JointID> kinectHierarchy = new Dictionary<JointID, JointID>
                                                               {
                                                                   {JointID.HipCenter, JointID.HipCenter},
                                                                   {JointID.HipLeft, JointID.HipCenter},
                                                                   {JointID.HipRight, JointID.HipCenter},
                                                                   {JointID.Spine, JointID.HipCenter},
                                                                   //Left leg
                                                                   {JointID.KneeLeft, JointID.HipLeft},
                                                                   {JointID.AnkleLeft, JointID.KneeLeft},
                                                                   {JointID.FootLeft, JointID.AnkleLeft},
                                                                   //Right leg
                                                                   {JointID.KneeRight, JointID.HipRight},
                                                                   {JointID.AnkleRight, JointID.KneeRight},
                                                                   {JointID.FootRight, JointID.AnkleRight},
                                                                   //Spine
                                                                   {JointID.ShoulderCenter, JointID.Spine},
                                                                   {JointID.Head, JointID.ShoulderCenter},
                                                                   //Shoulders
                                                                   {JointID.ShoulderLeft, JointID.ShoulderCenter},
                                                                   {JointID.ShoulderRight, JointID.ShoulderCenter},
                                                                   //Left arm
                                                                   {JointID.ElbowLeft, JointID.ShoulderLeft},
                                                                   {JointID.HandLeft, JointID.ElbowLeft},
                                                                   {JointID.WristLeft, JointID.HandLeft},
                                                                   //Right arm
                                                                   {JointID.ElbowRight, JointID.ShoulderRight},
                                                                   {JointID.HandRight, JointID.ElbowRight},
                                                                   {JointID.WristRight, JointID.HandRight}
                                                               };
        #endregion

        #endregion

        #region Constructor

        ~Kinect()
        {
            if (nui != null)
                nui.Uninitialize();
        }

        /// <summary>
        /// Try to start the kinect.
        /// </summary>
        /// <param name="kinectSkeletonMap">Map of JointId to model bone index.</param>
        public void Initialize(Dictionary<int, int> kinectSkeletonMap)
        {
            this.kinectSkeletonMap = kinectSkeletonMap;
            ModelScale = 1;
            ModelOffset = Vector3.Zero;
            gotFirstSkeletonFrame = false;

            try
            {
                nui = new Runtime();
                nui.Initialize(RuntimeOptions.UseSkeletalTracking);
            }
            catch
            {
                Debug.WriteLine("Runtime initialization failed. Please make sure Kinect device is plugged in.");
                Initialized = false;
                return;
            }

            var parameters = new TransformSmoothParameters();
            parameters.Smoothing = 0.7f;
            parameters.Correction = 0.3f;
            parameters.Prediction = 0.4f;
            parameters.JitterRadius = 1.0f;
            parameters.MaxDeviationRadius = 0.5f;
            nui.SkeletonEngine.SmoothParameters = parameters;

            nui.SkeletonFrameReady += nui_SkeletonFrameReady;
            nui.NuiCamera.ElevationAngle = 0;
            Initialized = true;
        }

        #endregion
  
        /// <summary>
        /// Map the kinect skeleton positions onto the model skeleton.
        /// </summary>
        /// <param name="model"></param>     
        public AnimationClip Map(Model model)
        {
            if (SkeletonData != null)
            {
                Vector3 orientationAdjustment = new Vector3(1, -1, -1);
                Quaternion o = Quaternion.Identity;
                
                #region Left Arm

                //gets the positions of each joint
                var leftShoulder = GetKinectPosition(JointID.ShoulderLeft) * orientationAdjustment;
                var leftElbow = GetKinectPosition(JointID.ElbowLeft) * orientationAdjustment;
                var leftWrist = GetKinectPosition(JointID.WristLeft) * orientationAdjustment;
                var lefthand = GetKinectPosition(JointID.HandLeft) * orientationAdjustment;

                var leftUpperArm = leftElbow - leftShoulder;
                var leftForeArm = leftWrist - leftElbow;
                var leftHand = lefthand - leftWrist;

                {	//Shoulder, yaw
                    Vector3 tmp = leftUpperArm;
                    tmp.Y = 0;
                    tmp.Normalize();
                    o = GetRotationTo(Vector3.Left, tmp, Vector3.Zero);
                }

                {	//Shoulder, pitch
                    Vector3 tmp = Vector3.Transform(leftUpperArm, Quaternion.Inverse(o));
                    tmp.Normalize();
                    o = o * GetRotationTo(Vector3.Left, tmp, Vector3.Zero);
                }

                {	//Shoulder, roll
                    Vector3 tmp = Vector3.Transform(leftUpperArm, Quaternion.Inverse(o));
                    tmp.Normalize();
                    o = o * GetRotationTo(Vector3.Left, tmp, Vector3.Zero);
                    o.X *= 0.5f;
                    o.Y *= 0.5f;
                    o.Z *= 0.5f;
                }
                AdjustRotation(model, kinectSkeletonMap[(int)JointID.ShoulderLeft], o);

                {	//Elbow, yaw
                    Vector3 tmp = Vector3.Transform(leftUpperArm, Quaternion.Inverse(o));
                    tmp.Y = 0;
                    tmp.Normalize();
                    o = GetRotationTo(Vector3.Left, tmp, Vector3.Zero);
                }

                {	//Elbow, pitch
                    Vector3 tmp = Vector3.Transform(leftUpperArm, Quaternion.Inverse(o));
                    tmp.Normalize();
                    o = o * GetRotationTo(Vector3.Left, tmp, Vector3.Zero);
                }

                {	//Elbow, roll
                    Vector3 tmp = Vector3.Transform(leftUpperArm, Quaternion.Inverse(o));
                    tmp.Normalize();
                    o = o * GetRotationTo(Vector3.Left, tmp, Vector3.Zero);
                    o.X *= 0.6f;
                    o.Y *= 0.6f;
                    o.Z *= 0.6f;
                }
                AdjustRotation(model, kinectSkeletonMap[(int)JointID.ElbowLeft], o);

                {	//Elbow, pitch
                    Vector3 tmp = Vector3.Transform(leftForeArm, Quaternion.Inverse(o));
                    tmp.Normalize();
                    o = GetRotationTo(Vector3.Left, tmp, Vector3.Zero);
                }
                AdjustRotation(model, kinectSkeletonMap[(int)JointID.WristLeft], o);

                #endregion
                
                //Controls movement for the right arm
                #region Right Arm

                orientationAdjustment = new Vector3(1, -1, 1);
                var rightShoulder = GetKinectPosition(JointID.ShoulderRight) * orientationAdjustment;
                var rightElbow = GetKinectPosition(JointID.ElbowRight) * orientationAdjustment;
                var rightWrist = GetKinectPosition(JointID.WristRight) * orientationAdjustment;
                var righthand = GetKinectPosition(JointID.HandRight) * orientationAdjustment;

                var rightUpperArm = rightElbow - rightShoulder;
                var rightForeArm = rightWrist - rightElbow;
                var rightHand = righthand - rightWrist;

                {	//Shoulder, yaw
                    Vector3 tmp = rightUpperArm;
                    tmp.Y = 0;
                    tmp.Normalize();
                    o = GetRotationTo(Vector3.Right, tmp, Vector3.Zero);
                }

                {	//Shoulder, pitch
                    Vector3 tmp = Vector3.Transform(rightUpperArm, Quaternion.Inverse(o));
                    tmp.Normalize();
                    o = o * GetRotationTo(Vector3.Right, tmp, Vector3.Zero);
                }

                {	//Shoulder, roll
                    Vector3 tmp = Vector3.Transform(rightUpperArm, Quaternion.Inverse(o));
                    tmp.Normalize();
                    o = o * GetRotationTo(Vector3.Right, tmp, Vector3.Zero);
                    o.X *= 0.5f;
                    o.Y *= 0.5f;
                    o.Z *= 0.5f;
                }
                AdjustRotation(model, kinectSkeletonMap[(int)JointID.ShoulderRight], o);

                {	//Elbow, yaw
                    Vector3 tmp = Vector3.Transform(rightUpperArm, Quaternion.Inverse(o));
                    tmp.Y = 0;
                    tmp.Normalize();
                    o = GetRotationTo(Vector3.Right, tmp, Vector3.Zero);
                }

                {	//Elbow, pitch
                    Vector3 tmp = Vector3.Transform(rightUpperArm, Quaternion.Inverse(o));
                    tmp.Normalize();
                    o = o * GetRotationTo(Vector3.Right, tmp, Vector3.Zero);
                }

                {	//Elbow, roll
                    Vector3 tmp = Vector3.Transform(rightUpperArm, Quaternion.Inverse(o));
                    tmp.Normalize();
                    o = o * GetRotationTo(Vector3.Right, tmp, Vector3.Zero);
                    o.X *= 0.6f;
                    o.Y *= 0.6f;
                    o.Z *= 0.6f;
                }
                AdjustRotation(model, kinectSkeletonMap[(int)JointID.ElbowRight], o);

                {	//Elbow, pitch
                    Vector3 tmp = Vector3.Transform(rightForeArm, Quaternion.Inverse(o));
                    tmp.Normalize();
                    o = GetRotationTo(Vector3.Right, tmp, Vector3.Zero);
                }
                AdjustRotation(model, kinectSkeletonMap[(int)JointID.WristRight], o);

                #endregion

                //Controls movement for the head
                #region Head

                orientationAdjustment = new Vector3(-1, -1, -1);

                var shoulderCentre = GetKinectPosition(JointID.ShoulderCenter) * orientationAdjustment;
                var head = GetKinectPosition(JointID.Head) * orientationAdjustment;
                var headToShoulder = head - shoulderCentre;

                {	//Head, yaw
                    Vector3 tmp = headToShoulder;
                    tmp.Y = 0;
                    tmp.Normalize();
                    o = GetRotationTo(Vector3.Up, tmp, Vector3.Zero);
                    o.X *= 0.5f;
                    o.Y *= 0.5f;
                    o.Z *= 0.5f;
                }

                AdjustRotation(model, kinectSkeletonMap[(int)JointID.Head] + 1, o);

                #endregion

                //controls movement for the hips and legs
                #region Hips

                //hip and leg variables
                #region Hip variables

                orientationAdjustment = new Vector3(1, 1, 1);
                var hipCenter = GetKinectPosition(JointID.HipCenter) * orientationAdjustment;

                var hipLeft = GetKinectPosition(JointID.HipLeft) * orientationAdjustment;
                var leftKnee = GetKinectPosition(JointID.KneeLeft) * orientationAdjustment;
                var leftAnkle = GetKinectPosition(JointID.AnkleLeft) * orientationAdjustment;
                var leftToe = GetKinectPosition(JointID.FootLeft) * orientationAdjustment;

                var hipRight = GetKinectPosition(JointID.HipRight) * orientationAdjustment;
                var rightKnee = GetKinectPosition(JointID.KneeRight) * orientationAdjustment;
                var rightAnkle = GetKinectPosition(JointID.AnkleRight) * orientationAdjustment;
                var rightToe = GetKinectPosition(JointID.FootRight) * orientationAdjustment;

                //gets the distances between the joints for the left leg
                var leftHip = hipLeft - hipCenter;
                var leftUpperLeg = leftKnee - hipLeft;
                var leftLowerLeg = leftAnkle - leftKnee;
                var leftFoot = leftToe - leftAnkle;

                //gets the distances between the joints for the right leg
                var rightHip = hipRight - hipCenter;
                var rightUpperLeg = rightKnee - hipRight;
                var rightLowerLeg = rightAnkle - rightKnee;
                var rightFoot = rightToe - rightAnkle;

                #endregion

                //controls movement for the left leg
                #region Left Leg

                {	//Right Hip, yaw
                    Vector3 tmp = leftHip;
                    tmp.Y = 0;
                    tmp.Normalize();
                    o = GetRotationTo(Vector3.Left, tmp, Vector3.Zero);
                }

                {	//Right Hip, pitch
                    Vector3 tmp = Vector3.Transform(leftHip, Quaternion.Inverse(o));
                    //tmp.X = 0; 
                    tmp.Normalize();
                    o = o * GetRotationTo(Vector3.Left, tmp, Vector3.Zero);
                }
                {	//Right Hip, roll
                    Vector3 tmp = Vector3.Transform(leftHip, Quaternion.Inverse(o));
                    tmp.Normalize();
                    o = o * GetRotationTo(Vector3.Left, tmp, Vector3.Zero);
                }
                //Rotates o so it has a more visually correct position when applied to the hip joint
                o = o * Quaternion.CreateFromYawPitchRoll(MathHelper.ToRadians(-180), 0, MathHelper.ToRadians(45));
                o.Y *= -1;
                AdjustRotation(model, kinectSkeletonMap[(int)JointID.HipLeft], o);
                //undo changes made to o
                o = o * Quaternion.CreateFromYawPitchRoll(MathHelper.ToRadians(180), 0, MathHelper.ToRadians(-45));
                o.Y *= -1;

                {	//Knee, yaw
                    Vector3 tmp = Vector3.Transform(leftUpperLeg, Quaternion.Inverse(o)); ;
                    tmp.Y = 0;
                    tmp.Normalize();
                    o = GetRotationTo(Vector3.Down, tmp, Vector3.Zero);
                }

                {	//Knee, pitch
                    Vector3 tmp = Vector3.Transform(leftUpperLeg, Quaternion.Inverse(o));
                    tmp.Z = 0;
                    tmp.Normalize();
                    o = o * GetRotationTo(Vector3.Down, tmp, Vector3.Zero);
                }

                {	//Knee, roll
                    Vector3 tmp = Vector3.Transform(leftUpperLeg, Quaternion.Inverse(o));
                    tmp.Normalize();
                    o = o * GetRotationTo(Vector3.Down, tmp, Vector3.Zero);
                }
                var temp = o.Y;
                o.Y = o.X;
                o.X = temp;
                o.X *= -1;
                o.Y *= -1;
                //o = o * Quaternion.CreateFromYawPitchRoll(0, MathHelper.ToRadians(-30), MathHelper.ToRadians(30));
                AdjustRotation(model, kinectSkeletonMap[(int)JointID.KneeLeft], o);
                //o = o * Quaternion.CreateFromYawPitchRoll(0, MathHelper.ToRadians(30), MathHelper.ToRadians(-30));
                temp = o.Y;
                o.Y = o.X;
                o.X = temp;
                o.X *= -1;
                o.Y *= -1;

                {	//Ankle, pitch
                    Vector3 tmp = leftLowerLeg;//Vector3.Transform(rightLowerLeg, Quaternion.Inverse(o));
                    //tmp.X = 0;
                    tmp.Normalize();
                    o = GetRotationTo(Vector3.Forward, tmp, Vector3.Zero);
                }
                //{	//Ankle, pitch
                //    Vector3 tmp = Vector3.Transform(rightLowerLeg, Quaternion.Inverse(o));
                //    tmp.Normalize();
                //    o = GetRotationTo(Vector3.Up, tmp, Vector3.Zero);
                //}
                //o = o * Quaternion.CreateFromYawPitchRoll(MathHelper.ToRadians(30), 0, 0);
                o.Z *= -1;
                AdjustRotation(model, kinectSkeletonMap[(int)JointID.AnkleLeft], o);

                {	//Foot, yaw
                    Vector3 tmp = Vector3.Transform(leftFoot, Quaternion.Inverse(o));
                    tmp.X = 0;
                    tmp.Normalize();
                    o = GetRotationTo(Vector3.Right, tmp, Vector3.Zero);
                }

                {	//Foot, pitch
                    Vector3 tmp = Vector3.Transform(leftFoot, Quaternion.Inverse(o));
                    tmp.Normalize();
                    o = o * GetRotationTo(Vector3.Right, tmp, Vector3.Zero);
                }
                o = o * Quaternion.CreateFromYawPitchRoll(MathHelper.ToRadians(30), 0, MathHelper.ToRadians(-90));
                AdjustRotation(model, kinectSkeletonMap[(int)JointID.FootLeft], o);

                #endregion

                //controls movement for the right leg
                #region Right Leg

                {	//Right Hip, yaw
                    Vector3 tmp = rightHip;
                    tmp.Y = 0;
                    tmp.Normalize();
                    o = GetRotationTo(Vector3.Right, tmp, Vector3.Zero);
                }

                {	//Right Hip, pitch
                    Vector3 tmp = Vector3.Transform(rightHip, Quaternion.Inverse(o));
                    //tmp.X = 0; 
                    tmp.Normalize();
                    o = o * GetRotationTo(Vector3.Right, tmp, Vector3.Zero);
                }
                {	//Right Hip, roll
                    Vector3 tmp = Vector3.Transform(rightHip, Quaternion.Inverse(o));
                    tmp.Normalize();
                    o = o * GetRotationTo(Vector3.Right, tmp, Vector3.Zero);
                }
                //rotates o into a position that is more visually correct
                o = o * Quaternion.CreateFromYawPitchRoll(MathHelper.ToRadians(180), 0, MathHelper.ToRadians(-45));
                o.Y *= -1;
                AdjustRotation(model, kinectSkeletonMap[(int)JointID.HipRight], o);
                //undo changes to o
                o = o * Quaternion.CreateFromYawPitchRoll(MathHelper.ToRadians(-180), 0, MathHelper.ToRadians(45));
                o.Y *= -1;

                {	//Knee, yaw
                    Vector3 tmp = Vector3.Transform(rightUpperLeg, Quaternion.Inverse(o)); ;
                    tmp.Y = 0;
                    tmp.Normalize();
                    o = GetRotationTo(Vector3.Down, tmp, Vector3.Zero);
                }

                {	//Knee, pitch
                    Vector3 tmp = Vector3.Transform(rightUpperLeg, Quaternion.Inverse(o));
                    tmp.Z = 0;
                    tmp.Normalize();
                    o = o * GetRotationTo(Vector3.Down, tmp, Vector3.Zero);
                }

                {	//Knee, roll
                    Vector3 tmp = Vector3.Transform(rightUpperLeg, Quaternion.Inverse(o));
                    tmp.Normalize();
                    o = o * GetRotationTo(Vector3.Down, tmp, Vector3.Zero);
                }
                //swaps the x and y values and inverts them. Makes the axis more visually correct
                temp = o.Y;
                o.Y = o.X;
                o.X = temp;
                o.X *= -1;
                o.Y *= -1;
                AdjustRotation(model, kinectSkeletonMap[(int)JointID.KneeRight], o);
                //undo changes to o 
                temp = o.Y;
                o.Y = o.X;
                o.X = temp;
                o.X *= -1;
                o.Y *= -1;

                {	//Ankle, pitch
                    Vector3 tmp = rightLowerLeg;//Vector3.Transform(rightLowerLeg, Quaternion.Inverse(o));
                    tmp.Z = 0;
                    tmp.Normalize();
                    o = GetRotationTo(Vector3.Forward, tmp, Vector3.Zero);
                }
                //{	//Ankle, pitch
                //    Vector3 tmp = Vector3.Transform(rightLowerLeg, Quaternion.Inverse(o));
                //    tmp.Normalize();
                //    o = GetRotationTo(Vector3.Up, tmp, Vector3.Zero);
                //}
                //o = o * Quaternion.CreateFromYawPitchRoll(MathHelper.ToRadians(30), 0, 0);
                //o.Z *= -1;
                AdjustRotation(model, kinectSkeletonMap[(int)JointID.AnkleRight], o);

                {	//Foot, yaw
                    Vector3 tmp = Vector3.Transform(rightFoot, Quaternion.Inverse(o));
                    tmp.X = 0;
                    tmp.Normalize();
                    o = GetRotationTo(Vector3.Right, tmp, Vector3.Zero);
                }

                {	//Foot, pitch
                    Vector3 tmp;
                    tmp = Vector3.Transform(rightFoot, Quaternion.Inverse(o));
                    tmp.Normalize();
                    o = o * GetRotationTo(Vector3.Right, tmp, Vector3.Zero);
                }
                o = o * Quaternion.CreateFromYawPitchRoll(MathHelper.ToRadians(30), 0, MathHelper.ToRadians(-90));
                AdjustRotation(model, kinectSkeletonMap[(int)JointID.FootRight], o);


                #endregion

                #endregion

                //Scale the overall skeleton position to move the root of the model.
                var skeletonPosition = new Vector3((SkeletonData.Position.X - ModelOffset.X)*ModelScale,
                                                   (SkeletonData.Position.Y - ModelOffset.Y)*ModelScale,
                                                   (SkeletonData.Position.Z - ModelOffset.Z)*ModelScale);
                //Filter the position as Skeleton.Position is very noisey
                UpdateMovingAverage(skeletonPosition);
                model.Root.Transform = Matrix.CreateTranslation(movingAveragePosition) * Matrix.CreateFromQuaternion(rootRotation);

                animationKeyframes.Clear();
                for (int i = 0; i < modelTransforms.Length; i++)
                {
                    if (i == model.Root.Index || i == 43 /*mesh root*/)
                        continue;
                    animationKeyframes.Add(new Keyframe(i - 1, TimeSpan.FromMilliseconds(5), modelTransforms[i]));
                }

                return new AnimationClip(TimeSpan.FromMilliseconds(10), animationKeyframes);
            }

            return null;
        }

        /// <summary>
        /// Move the model into a standard T pose (Guessing this only works on the goblin.dae).
        /// </summary>
        /// <param name="model"></param>
        public void CreateModelTPose(Model model)
        {
            if (translations == null)
                translations = new List<Vector3>();
            else
                translations.Clear();

            modelTransforms = new Matrix[model.Bones.Count];

            Vector3 scale;
            Quaternion rot;
            Vector3 translation;
            for (int i = 0; i < model.Bones.Count; i++)
            {
                model.Bones[i].Transform.Decompose(out scale, out rot, out translation);
                //Keep the original root rotation so we can move the whole model by the root
                if (i == model.Root.Index)
                {
                    rootRotation = rot;
                }
                //Store original translations
                translations.Add(translation);

                //Store the models unrotated transforms locally
                if (i > 1)
                    /*model.Bones[i].Transform*/
                    modelTransforms[i] = Matrix.CreateTranslation(translation) * Matrix.CreateFromQuaternion(Quaternion.Identity);
                else
                    modelTransforms[i] = model.Bones[i].Transform;
            }

            //Left hip
            var q = Quaternion.CreateFromYawPitchRoll(MathHelper.ToRadians(180), 0, 0);
            modelTransforms[kinectSkeletonMap[(int)JointID.HipLeft]] = Matrix.CreateTranslation(translations[kinectSkeletonMap[(int)JointID.HipLeft]]) * Matrix.CreateFromQuaternion(q);
            //Knee
            //q = Quaternion.CreateFromYawPitchRoll(0, 0, MathHelper.ToRadians(270));
            //model.Bones[36].Transform = Matrix.CreateTranslation(translations[36]) * Matrix.CreateFromQuaternion(q);
            //foot
            //q = Quaternion.CreateFromYawPitchRoll(0, MathHelper.ToRadians(270), 0);
            //model.Bones[42].Transform = Matrix.CreateTranslation(translations[42]) * Matrix.CreateFromQuaternion(q);

            //Right hip
            q = Quaternion.CreateFromYawPitchRoll(MathHelper.ToRadians(180), 0, 0);
            modelTransforms[kinectSkeletonMap[(int)JointID.HipRight]] = Matrix.CreateTranslation(translations[kinectSkeletonMap[(int)JointID.HipRight]]) * Matrix.CreateFromQuaternion(q);

            //left shoulder
            q = Quaternion.CreateFromYawPitchRoll(0, 0, MathHelper.ToRadians(270));
            modelTransforms[kinectSkeletonMap[(int)JointID.ShoulderLeft]] = Matrix.CreateTranslation(translations[kinectSkeletonMap[(int)JointID.ShoulderLeft]]) * Matrix.CreateFromQuaternion(q);
            //Correct yaw
            q = Quaternion.CreateFromYawPitchRoll(MathHelper.ToRadians(0), MathHelper.ToRadians(0), MathHelper.ToRadians(0));
            modelTransforms[kinectSkeletonMap[(int)JointID.ElbowLeft]] = Matrix.CreateTranslation(translations[kinectSkeletonMap[(int)JointID.ElbowLeft]]) * Matrix.CreateFromQuaternion(q);


            //right shoulder
            q = Quaternion.CreateFromYawPitchRoll(0, 0, MathHelper.ToRadians(90));
            modelTransforms[kinectSkeletonMap[(int)JointID.ShoulderRight]] = Matrix.CreateTranslation(translations[kinectSkeletonMap[(int)JointID.ShoulderRight]]) * Matrix.CreateFromQuaternion(q);

            //head
            q = Quaternion.CreateFromYawPitchRoll(MathHelper.ToRadians(0), MathHelper.ToRadians(0), MathHelper.ToRadians(0));
            modelTransforms[18] = Matrix.CreateTranslation(translations[18]) * Matrix.CreateFromQuaternion(q);
        }

        /// <summary>
        /// Generate a scale and offset to centre the model.
        /// </summary>
        /// <param name="model"></param>
        public void ScaleKinectSkeletonToModel(Model model)
        {
            if (SkeletonData != null)
            {
                float modelSize = MeasureModel(model);
                float skeletonSize = MeasureKinectSkeleton(SkeletonData.Joints);
                ModelScale = modelSize / skeletonSize;
                float dist = SkeletonData.Position.Z;
                ModelOffset = new Vector3(SkeletonData.Position.X, SkeletonData.Position.Y,
                                     SkeletonData.Position.Z);
            }
        }

        /// <summary>
        /// Start recording the kinect data to a file.
        /// </summary>
        /// <returns></returns>
        public bool StartRecording()
        {
            int i = 1;
            string filename = "Kinect animation 1.xml";
            while (File.Exists(filename))
            {
                filename = "Kinect animation " + i + ".xml";
                i++;
            }
            return KinectStructure.CreateNewRecording(filename, ModelOffset, ModelScale);
        }

        /// <summary>
        /// Stop recording kinect data.
        /// </summary>
        public void StopRecording()
        {
            KinectStructure.StopRecording();
        }

        /// <summary>
        /// Serialize the current kinect data.
        /// </summary>
        public void SerialiseKinectFrame(TimeSpan duration, AnimationClip clip)
        {
            //List<Vector3> jointList = new List<Vector3>();

            //foreach (Joint joints in SkeletonData.Joints)
            //{
            //    Vector3 jp = new Vector3(joints.Position.X, joints.Position.Y, joints.Position.Z);
            //    jointList.Add(jp);
            //}

            //Vector3 kinectPosition = new Vector3(SkeletonData.Position.X, SkeletonData.Position.Y, SkeletonData.Position.Z);
            //KinectStructure data = new KinectStructure(jointList, kinectPosition);
            KinectStructure.WriteFrame(clip, duration);
        }

        /// <summary>
        /// Reset the kinect information.
        /// </summary>
        public void Reset()
        {
            gotFirstSkeletonFrame = false;
            ModelScale = 1;
            ModelOffset = Vector3.Zero;
        }

        /// <summary>
        /// Get rotation to point.
        /// </summary>
        /// <param name="bodyPart"></param>
        /// <param name="direction"></param>
        /// <param name="zeroX"></param>
        /// <param name="zeroY"></param>
        /// <param name="zeroZ"></param>
        /// <returns></returns>
        private Quaternion GetRotation(Vector3 bodyPart, Vector3 direction, bool zeroX, bool zeroY, bool zeroZ)
        {
            Vector3 tmp = bodyPart;
            if (zeroX)
                tmp.X = 0;
            if (zeroY)
                tmp.Y = 0;
            if (zeroZ)
                tmp.Z = 0;
            tmp.Normalize();
            return GetRotationTo(direction, tmp, Vector3.Zero);
        }

        /// <summary>
        /// Rotate the bone by rotation.
        /// </summary>
        /// <param name="model"></param>
        /// <param name="boneIndex"></param>
        /// <param name="rotation"></param>
        private void AdjustRotation(Model model, int boneIndex, Quaternion rotation)
        {
            modelTransforms[boneIndex] = Matrix.CreateTranslation(translations[boneIndex]) *
                                                 Matrix.CreateFromQuaternion(rotation);
            model.Bones[boneIndex].Transform = modelTransforms[boneIndex];
        }

        /// <summary>
        /// Return the kinect joint position.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        private Vector3 GetKinectPosition(JointID id)
        {
            var pos = new Vector3(SkeletonData.Joints[id].Position.X - minimumPoint.X,
                               SkeletonData.Joints[id].Position.Y - minimumPoint.Y,
                               SkeletonData.Joints[id].Position.Z/* - ModelOffset.Z*/);// *ModelScale;

            if(pos.X < 0 || pos.Y < 0)
            {
                Debug.WriteLine("Warning::: " + id + " == " + pos);
            }

            return pos;
        }

        /// <summary>
        /// Calculate the rotation from start to dest. Taken from the web.
        /// </summary>
        /// <param name="start"></param>
        /// <param name="dest"></param>
        /// <param name="fallback"></param>
        /// <returns></returns>
        private Quaternion GetRotationTo(Vector3 start, Vector3 dest, Vector3 fallback)
        {
            Quaternion q;
            Vector3 v0 = start;
            Vector3 v1 = dest;

            v0.Normalize();
            v1.Normalize();

            float d = Vector3.Dot(v0, v1);
            if (d >= 1.0f) return Quaternion.Identity;

            if (d < (1e-6f - 1.0f))
            {
                if (fallback != Vector3.Zero)
                {
                    //q = Quaternion.AngleAxis(Math.PI, fallback);
                    q = Quaternion.CreateFromAxisAngle(fallback, MathHelper.Pi);
                }
                else
                {
                    Vector3 axis = Vector3.Cross(Vector3.Right, start);
                    if (axis.Length() <= float.Epsilon) axis = Vector3.Cross(Vector3.Up, start);
                    axis.Normalize();
                    q = Quaternion.CreateFromAxisAngle(axis, MathHelper.Pi);
                }
            }
            else
            {
                float s = (float)Math.Sqrt((1 + d) * 2);
                float invs = 1 / s;
                Vector3 c = Vector3.Cross(v0, v1);

                q.X = c.X * invs;
                q.Y = c.Y * invs;
                q.Z = c.Z * invs;
                q.W = s * 0.5f;
                //q.Normalize();
            }
            return q;
        }

        /// <summary>
        /// Event handler for new kinect data.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void nui_SkeletonFrameReady(object sender, SkeletonFrameReadyEventArgs e)
        {
            foreach (SkeletonData s in e.SkeletonFrame.Skeletons)
            {
                if (s.TrackingState == SkeletonTrackingState.Tracked)
                {
                    SkeletonData = s;
                    //Get the minimum point
                    foreach (Joint joint in SkeletonData.Joints)
                    {
                        if (joint.Position.X < minimumPoint.X)
                            minimumPoint.X = joint.Position.X;
                        if (joint.Position.Y < minimumPoint.Y)
                            minimumPoint.Y = joint.Position.Y;
                    }
                    if (!gotFirstSkeletonFrame)
                    {
                        gotFirstSkeletonFrame = true;
                        if (SkeletonFirstFrameReady != null)
                            SkeletonFirstFrameReady(this, EventArgs.Empty);
                    }
                }
            }
        }

        /// <summary>
        /// Measure the size of the model's skeleton.
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        private float MeasureModel(Model model)
        {
            Vector3 modelCenter = Vector3.Zero; float modelRadius;
            Matrix[] modelTransforms = new Matrix[model.Bones.Count];
            model.CopyAbsoluteBoneTransformsTo(modelTransforms);

            foreach (ModelMesh mesh in model.Meshes)
            {
                BoundingSphere meshBounds = mesh.BoundingSphere;
                Matrix transform = modelTransforms[mesh.ParentBone.Index];
                Vector3 meshCenter = Vector3.Transform(meshBounds.Center, transform);

                modelCenter += meshCenter;
            }

            modelCenter /= model.Meshes.Count;

            // Now we know the center point, we can compute the model radius  
            // by examining the radius of each mesh bounding sphere.  
            modelRadius = 0;

            foreach (ModelMesh mesh in model.Meshes)
            {
                BoundingSphere meshBounds = mesh.BoundingSphere;
                Matrix transform = modelTransforms[mesh.ParentBone.Index];
                Vector3 meshCenter = Vector3.Transform(meshBounds.Center, transform);

                float transformScale = transform.Forward.Length();

                float meshRadius = (meshCenter - modelCenter).Length() +
                                   (meshBounds.Radius * transformScale);

                modelRadius = Math.Max(modelRadius, meshRadius);
            }

            return modelRadius;
        }

        /// <summary>
        /// Measure the size of the current kinect skeleton.
        /// </summary>
        /// <param name="joints"></param>
        /// <returns></returns>
        private float MeasureKinectSkeleton(JointsCollection joints)
        {
            var points = new List<Vector3>();
            foreach (Joint j in joints)
                points.Add(new Vector3(j.Position.X, j.Position.Y, j.Position.Z));

            var bound = BoundingSphere.CreateFromPoints(points);
            return bound.Radius;
        }

        /// <summary>
        /// Simple position filter for the overall skeleton position to remove some jitter.
        /// </summary>
        /// <param name="pos"></param>
        private void UpdateMovingAverage(Vector3 pos)
        {
            movingAveragePositions[movingAverageCurrentIndex] = pos;

            if (++movingAverageCurrentIndex == movingAveragePositions.Length)
                movingAverageCurrentIndex = 0;

            Vector3 total = Vector3.Zero;

            for (int i = 0; i < movingAveragePositions.Length; i++)
            {
                total += movingAveragePositions[i];
            }

            movingAveragePosition = total / movingAveragePositions.Length;
        }
    }
}
