﻿#region File Description
//-----------------------------------------------------------------------------
// CubePrimitive.cs
//
// Microsoft XNA Community Game Platform
// Copyright (C) Microsoft Corporation. All rights reserved.
//-----------------------------------------------------------------------------
#endregion

#region Using Statements
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
#endregion

namespace ModelViewer.Primitives
{
    /// <summary>
    /// Geometric primitive class for drawing cubes.
    /// </summary>
    public class CubePrimitive : GeometricPrimitive
    {
        /// <summary>
        /// Constructs a new cube primitive, using default settings.
        /// </summary>
        public CubePrimitive(GraphicsDevice graphicsDevice)
            : this(graphicsDevice, 10F, 10f, 10f)
        {
        }


        /// <summary>
        /// Constructs a new cube primitive, with the specified size.
        /// </summary>
        public CubePrimitive(GraphicsDevice graphicsDevice, float sizeX = 40F, float sizeY= 40F, float sizeZ=40F)
        {
            // A cube has six faces, each one pointing in a different direction.
            Vector3[] normals =
            {
                new Vector3(0, 0, 1),
                new Vector3(0, 0, -1),
                new Vector3(1, 0, 0),
                new Vector3(-1, 0, 0),
                new Vector3(0, 1, 0),
                new Vector3(0, -1, 0),
            };

            // Get two vectors perpendicular to the face normal and to each other.
            //Vector3 side1 = new Vector3(normals[0].Y, normals[0].Z, normals[0].X);
            //Vector3 side2 = Vector3.Cross(normals[0], side1);

            //// Six indices (two triangles) per face.
            //AddIndex(CurrentVertex + 0);
            //AddIndex(CurrentVertex + 1);
            //AddIndex(CurrentVertex + 2);

            //AddIndex(CurrentVertex + 0);
            //AddIndex(CurrentVertex + 2);
            //AddIndex(CurrentVertex + 3);

            //// Four vertices per face.
            //AddVertex((normals[0] - side1 - side2) * sizeZ / 2, normals[0]);
            //AddVertex((normals[0] - side1 + side2) * sizeZ / 2, normals[0]);
            //AddVertex((normals[0] + side1 + side2) * sizeZ / 2, normals[0]);
            //AddVertex((normals[0] + side1 - side2) * sizeZ / 2, normals[0]);



            //Vector3 side3 = new Vector3(normals[1].Y, normals[1].Z, normals[1].X);
            //Vector3 side4 = Vector3.Cross(normals[1], side3);

            //// Six indices (two triangles) per face.
            //AddIndex(CurrentVertex + 0);
            //AddIndex(CurrentVertex + 1);
            //AddIndex(CurrentVertex + 2);

            //AddIndex(CurrentVertex + 0);
            //AddIndex(CurrentVertex + 2);
            //AddIndex(CurrentVertex + 3);

            //// Four vertices per face.
            //AddVertex((normals[1] - side3 - side4) * sizeZ / 2, normals[1]);
            //AddVertex((normals[1] - side3 + side4) * sizeZ / 2, normals[1]);
            //AddVertex((normals[1] + side3 + side4) * sizeZ / 2, normals[1]);
            //AddVertex((normals[1] + side3 - side4) * sizeZ / 2, normals[1]);


            //Vector3 side5 = new Vector3(normals[2].Y, normals[2].Z, normals[2].X);
            //Vector3 side6 = Vector3.Cross(normals[2], side5);

            //// Six indices (two triangles) per face.
            //AddIndex(CurrentVertex + 0);
            //AddIndex(CurrentVertex + 1);
            //AddIndex(CurrentVertex + 2);

            //AddIndex(CurrentVertex + 0);
            //AddIndex(CurrentVertex + 2);
            //AddIndex(CurrentVertex + 3);

            //// Four vertices per face.
            //AddVertex((normals[2] - side5 - side6) * sizeX / 2, normals[2]);
            //AddVertex((normals[2] - side5 + side6) * sizeX / 2, normals[2]);
            //AddVertex((normals[2] + side5 + side6) * sizeX / 2, normals[2]);
            //AddVertex((normals[2] + side5 - side6) * sizeX / 2, normals[2]);



            //Vector3 side7 = new Vector3(normals[3].Y, normals[3].Z, normals[3].X);
            //Vector3 side8 = Vector3.Cross(normals[3], side7);

            //// Six indices (two triangles) per face.
            //AddIndex(CurrentVertex + 0);
            //AddIndex(CurrentVertex + 1);
            //AddIndex(CurrentVertex + 2);

            //AddIndex(CurrentVertex + 0);
            //AddIndex(CurrentVertex + 2);
            //AddIndex(CurrentVertex + 3);

            //// Four vertices per face.
            //AddVertex((normals[3] - side7 - side8) * sizeX / 2, normals[3]);
            //AddVertex((normals[3] - side7 + side8) * sizeX / 2, normals[3]);
            //AddVertex((normals[3] + side7 + side8) * sizeX / 2, normals[3]);
            //AddVertex((normals[3] + side7 - side8) * sizeX / 2, normals[3]);



            //Vector3 side9 = new Vector3(normals[4].Y, normals[4].Z, normals[4].X);
            //Vector3 side10 = Vector3.Cross(normals[4], side9);

            //// Six indices (two triangles) per face.
            //AddIndex(CurrentVertex + 0);
            //AddIndex(CurrentVertex + 1);
            //AddIndex(CurrentVertex + 2);

            //AddIndex(CurrentVertex + 0);
            //AddIndex(CurrentVertex + 2);
            //AddIndex(CurrentVertex + 3);

            //// Four vertices per face.
            //AddVertex((normals[4] - side9 - side10) * sizeY / 2, normals[4]);
            //AddVertex((normals[4] - side9 + side10) * sizeY / 2, normals[4]);
            //AddVertex((normals[4] + side9 + side10) * sizeY / 2, normals[4]);
            //AddVertex((normals[4] + side9 - side10) * sizeY / 2, normals[4]);



            //Vector3 side11 = new Vector3(normals[5].Y, normals[5].Z, normals[5].X);
            //Vector3 side12 = Vector3.Cross(normals[5], side11);

            //// Six indices (two triangles) per face.
            //AddIndex(CurrentVertex + 0);
            //AddIndex(CurrentVertex + 1);
            //AddIndex(CurrentVertex + 2);

            //AddIndex(CurrentVertex + 0);
            //AddIndex(CurrentVertex + 2);
            //AddIndex(CurrentVertex + 3);

            //// Four vertices per face.
            //AddVertex((normals[5] - side11 - side12) * sizeY / 2, normals[5]);
            //AddVertex((normals[5] - side11 + side12) * sizeY / 2, normals[5]);
            //AddVertex((normals[5] + side11 + side12) * sizeY / 2, normals[5]);
            //AddVertex((normals[5] + side11 - side12) * sizeY / 2, normals[5]);


            //Create each face in turn.
            for (int i = 0; i < normals.Length; i++ )
            {
                // Get two vectors perpendicular to the face normal and to each other.
                Vector3 side1 = new Vector3(normals[i].Y, normals[i].Z, normals[i].X);
                Vector3 side2 = Vector3.Cross(normals[i], side1);

                // Six indices (two triangles) per face.
                AddIndex(CurrentVertex + 0);
                AddIndex(CurrentVertex + 1);
                AddIndex(CurrentVertex + 2);

                AddIndex(CurrentVertex + 0);
                AddIndex(CurrentVertex + 2);
                AddIndex(CurrentVertex + 3);

                // Four vertices per face.
                AddVertex((normals[i] - side1 - side2) * sizeX / 2, normals[i]);
                AddVertex((normals[i] - side1 + side2) * sizeX/ 2, normals[i]);
                AddVertex((normals[i] + side1 + side2) * sizeX / 2, normals[i]);
                AddVertex((normals[i] + side1 - side2) * sizeX / 2, normals[i]);
            }

            InitializePrimitive(graphicsDevice);
        }
    }
}
