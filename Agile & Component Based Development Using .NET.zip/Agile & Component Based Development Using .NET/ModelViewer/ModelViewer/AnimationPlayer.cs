﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Shared;

namespace ModelViewer
{
    class AnimationPlayer
    {
        
        // Information about the currently playing animation clip.
        AnimationClip currentClipValue;
        TimeSpan currentTimeValue;
        int currentKeyframe;


        // Current animation transform matrices.
        Matrix[] boneTransforms;
        Matrix[] worldTransforms;
        Matrix[] skinTransforms;


        // Backlink to the bind pose and skeleton hierarchy data.
        List<Matrix> bindPoses;
        List<Matrix> inverseBindPoses;
        List<int> skeletonHierarchy;

        
        /// <summary>
        /// Constructor for the animation player
        /// </summary>
        /// <param name="bPose">List of the skeleton's bind poses</param>
        /// <param name="iBindPose">List of the skeleton's inverse bind poses</param>
        /// <param name="sHierarchy">List fo the skeleton hierarchy, which indexes the parent of each bone</param>
        public AnimationPlayer(List<Matrix> bPose, List<Matrix> iBindPose, List<int> sHierarchy)
        {
            //Ensures that all three lists have data within them, stopping the program if they don't
            if (bPose == null || iBindPose == null || sHierarchy == null)
                throw new ArgumentNullException("");

            bindPoses = bPose;
            inverseBindPoses = iBindPose;
            skeletonHierarchy = sHierarchy;

            boneTransforms = new Matrix[bindPoses.Count];
            worldTransforms = new Matrix[bindPoses.Count];
            skinTransforms = new Matrix[bindPoses.Count];     
        }

        /// <summary>
        /// Sets the animation player to start playing a clip
        /// </summary>
        /// <param name="clip">The clip to start playing</param>
        public void StartClip(AnimationClip clip)
        {
            //Ensures that the clip contains data
            if (clip == null)
                throw new ArgumentNullException("clip");

            currentClipValue = clip;
            
            currentTimeValue = TimeSpan.Zero;
            currentKeyframe = 0;

        }

        /// <summary>
        /// Updates the animation player to its next frame
        /// </summary>
        /// <param name="time">The current time in the program</param>
        /// <param name="relativeToCurrentTime"></param>
        /// <param name="rootTransform"></param>
        /// <param name="stopped">Whether the animation player has been called to stop or not</param>
        public void Update(TimeSpan time, bool relativeToCurrentTime, Matrix rootTransform, bool stopped)
        {
            //Doesn't update the transforms of the bones if it is stopped
            if (stopped == false)
            {
                UpdateBoneTransforms(time, relativeToCurrentTime);
            }
            else
            {
                bindPoses.CopyTo(boneTransforms, 0); //if the player has been stopped it sets the bones back to their starting transforms
            }
            UpdateWorldTransforms(rootTransform);
            UpdateSkinTransforms();
        }
        
        /// <summary>
        /// Calculates how the model should be skinned with the current world transforms
        /// </summary>
        public void UpdateSkinTransforms()
        {
            for (int bone = 0; bone < skinTransforms.Length; bone++)
            {
                skinTransforms[bone] = inverseBindPoses[bone] * worldTransforms[bone];
                
            }
        }

        /// <summary>
        /// Helper used by the Update method to refresh the BoneTransforms data.
        /// </summary>
        public void UpdateBoneTransforms(TimeSpan time, bool relativeToCurrentTime)
        {
            if (currentClipValue == null)
                throw new InvalidOperationException(
                            "AnimationPlayer.Update was called before StartClip");

            // Update the animation position.
            if (relativeToCurrentTime)
            {
                time += currentTimeValue;

                // If we reached the end, loop back to the start.
                while (time >= currentClipValue.Duration)
                    time -= currentClipValue.Duration;
            }

            if ((time < TimeSpan.Zero) || (time >= currentClipValue.Duration))
                throw new ArgumentOutOfRangeException("time");

            // If the position moved backwards, reset the keyframe index.
            if (time < currentTimeValue)
            {
                currentKeyframe = 0;
                bindPoses.CopyTo(boneTransforms, 0);
            }

            currentTimeValue = time;

            // Read keyframe matrices.
            IList<Keyframe> keyframes = currentClipValue.Keyframes;

            while (currentKeyframe < keyframes.Count)
            {
                Keyframe keyframe = keyframes[currentKeyframe];

                // Stop when we've read up to the current time position.
                if (keyframe.Time > currentTimeValue)
                    break;

                // Use this keyframe.
                boneTransforms[keyframe.Bone] = keyframe.Transform;

                currentKeyframe++;
            }
        }


        /// <summary>
        /// Helper used by the Update method to refresh the WorldTransforms data.
        /// </summary>
        public void UpdateWorldTransforms(Matrix rootTransform)
        {
            // Root bone.
            worldTransforms[0] = boneTransforms[0] * rootTransform;

            // Child bones.
            for (int bone = 1; bone < worldTransforms.Length; bone++)
            {
                int parentBone = skeletonHierarchy[bone];

                worldTransforms[bone] = boneTransforms[bone] * worldTransforms[parentBone];
                

            }
        }

        /// <summary>
        /// Passes back the value of skinTransforms
        /// </summary>
        /// <returns></returns>
        public Matrix[] GetSkinTransforms()
        {
            return skinTransforms;
        }

    }
}
