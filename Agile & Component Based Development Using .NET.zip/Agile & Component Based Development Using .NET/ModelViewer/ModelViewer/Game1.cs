using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.Research.Kinect.Nui;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using ModelViewer.Primitives;
using Shared;
using SkeletonJointShape = ModelViewer.Primitives.SpherePrimitive;
//using SkeletonJointShape = ModelViewer.Primitives.CubePrimitive;
namespace ModelViewer
{
    /// <summary>
    /// Camera taken from http://create.msdn.com/en-US/education/catalog/sample/skinned_model
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        #region Fields

        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        SpriteFont font;
        KeyboardState currentKeyboardState = new KeyboardState();
        KeyboardState previousKeyboardState = new KeyboardState();
        TimeSpan stop = new TimeSpan(0, 0, 10);

        private Model myModel;
        private SkeletonFormat animatedModelInfo;
        private AnimationPlayer animationPlayer;
        private Kinect kinect = new Kinect();
        //Draw joint shape
        private SkeletonJointShape skeletonJointPrimitive;
        private int currentAnimationClipIndex = -1;
        private string currentAnimationClipName = "";
        private AnimationClip currentAnimationClip = null;

        //TODO
        private bool modelHasSkeleton = true;
        #endregion

        #region Camera

        float cameraArc = 0;
        float cameraRotation = 0;
        float cameraDistance = 182;
        private float cameraX = 0;
        private float cameraY = -50;

        private Matrix view;
        private Matrix projection;

        #endregion

        #region Control Booleans

        private bool showSkeleton = true;
        private bool showWireframe = false;
        private bool showModel = false;
        private bool animationPaused = false;
        private bool animationStopped = true;
        private bool useKinect = false;
        private bool recordKinect = false;
        private bool drawKinectSkeleton = true;

        #endregion

        #region Crap

        //Used to draw lines between bones
        VertexPositionNormalTexture[] boneLineVertices;
        short[] boneLineIndices;

        private int skeletonScaleTimer;
        private double lastFrame;

        #endregion

        #region Init

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            base.Initialize();
            graphics.PreferredBackBufferWidth = 1280;
            graphics.PreferredBackBufferHeight = 720;
            graphics.ApplyChanges();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
            font = Content.Load<SpriteFont>("Font");
            myModel = Content.Load<Model>("Goblin");

            skeletonJointPrimitive = new SkeletonJointShape(GraphicsDevice);

            projection = Matrix.CreatePerspectiveFieldOfView(MathHelper.PiOver4,
                                                                    graphics.GraphicsDevice.Viewport.AspectRatio,
                                                                    1,
                                                                    10000);
            //Check the model for skeletal animation information
            animatedModelInfo = (SkeletonFormat)myModel.Tag;
            if (animatedModelInfo == null)
                modelHasSkeleton = false;

            if (modelHasSkeleton)
            {
                DebugPrintBones(myModel.Root, "");
                //One time build up of bone lines
                var v = new List<VertexPositionNormalTexture>();
                var i = new List<short>();
                JoinBones(myModel.Root, ref v, ref i);
                boneLineVertices = v.ToArray();
                boneLineIndices = i.ToArray();

                //Creates an anistance of the animation player
                animationPlayer = new AnimationPlayer(animatedModelInfo.BindPose, animatedModelInfo.InverseBindPose, animatedModelInfo.SkeletonHierarchy);

                //Sets the animation player to play a clip
                var nextClip = NextAnimationClip();
                if (nextClip != null)
                {
                    currentAnimationClip = nextClip.Item1;
                    currentAnimationClipName = nextClip.Item2;
                    currentAnimationClipIndex = nextClip.Item3;
                    animationPlayer.StartClip(currentAnimationClip);
                }

                //Try to start the kinect
                kinect.Initialize(((SkeletonFormat)myModel.Tag).KinectMap);
                if (kinect.Initialized)
                {
                    kinect.SkeletonFirstFrameReady += new EventHandler(kinect_SkeletonFirstFrameReady);
                    kinect.CreateModelTPose(myModel);
                }
            }
        }

        #endregion

        /// <summary>
        /// Select the next animation clip.
        /// </summary>
        private Tuple<AnimationClip, string, int> NextAnimationClip()
        {
            if (animatedModelInfo != null && animatedModelInfo.animationClip != null)
            {
                int i = 0;
                if (currentAnimationClipIndex == animatedModelInfo.animationClip.Count - 1)
                    currentAnimationClipIndex = -1;
                foreach (var animationClip in animatedModelInfo.animationClip)
                {
                    if(i > currentAnimationClipIndex)
                    {
                        return Tuple.Create(animationClip.Value, animationClip.Key, i);
                    }
                    i++;
                }
            }
            return null;
        }

        /// <summary>
        /// Allows the game to run logic.
        /// </summary>
        protected override void Update(GameTime gameTime)
        {
            HandleInput();
            UpdateCamera(gameTime);

            //An automatic timer that scales the kinect skeleton to the model's skeleton
            #region Skeleton scale timer
            if (kinect.Initialized && skeletonScaleTimer > 0)
            {
                skeletonScaleTimer -= gameTime.ElapsedGameTime.Milliseconds; //decrease the timer
                //Checks if the value of the timer is below 0, meaning time to execute the code associated with it
                if (skeletonScaleTimer < 0)
                {
                    kinect.ScaleKinectSkeletonToModel(myModel);
                    if (kinect.ModelScale > 50 && kinect.ModelScale < 130)
                    {
                        //This should mean we have good skeleton data
                        skeletonScaleTimer = 0;
                    }
                    else
                    {
                        //Rerun the timer in 200ms
                        skeletonScaleTimer = 200;
                    }
                }
            }
            #endregion

            //Prevents the animatio player from updating if it is paused, so it freezes in place
            if (!animationPaused)
                animationPlayer.Update(gameTime.ElapsedGameTime, true, Matrix.Identity, animationStopped);

            //Stops the animation player
            if (animationStopped)
                animationPlayer.Update(stop, true, Matrix.Identity, animationStopped);

            //Check the kinect is ready to be used and the user has selected the kinect as the animation source
            if (modelHasSkeleton && kinect.Initialized && useKinect)
            {
                var animationClip = kinect.Map(myModel);
                if (animationClip != null)
                {
                    animationPlayer.StartClip(animationClip);
                    if (recordKinect)
                    {
                        kinect.SerialiseKinectFrame(TimeSpan.FromMilliseconds(DateTime.Now.TimeOfDay.TotalMilliseconds - lastFrame), animationClip);
                        lastFrame = DateTime.Now.TimeOfDay.TotalMilliseconds;
                    }
                }
            }


            base.Update(gameTime);
        }

        /// <summary>
        /// Draws everything onto the screen.
        /// </summary>
        /// <param name="gameTime"></param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.DeepSkyBlue);
            // Compute camera matrices.
            view = Matrix.CreateTranslation(cameraX, cameraY, 0) *
                          Matrix.CreateRotationY(MathHelper.ToRadians(cameraRotation)) *
                          Matrix.CreateRotationX(MathHelper.ToRadians(cameraArc)) *
                          Matrix.CreateLookAt(new Vector3(0, 0, -cameraDistance),
                                              new Vector3(0, 0, 0), Vector3.Up);

            //Draws the model
            if (showModel)
            {
                GraphicsDevice.DepthStencilState = new DepthStencilState() { DepthBufferEnable = true };
                DrawModel(myModel);
            }

            //Draws the wireframe of the model
            if (showWireframe)
            {
                GraphicsDevice.DepthStencilState = new DepthStencilState() { DepthBufferEnable = false };
                GraphicsDevice.RasterizerState = new RasterizerState() { FillMode = FillMode.WireFrame, };
                DrawModel(myModel);
                GraphicsDevice.RasterizerState = new RasterizerState() { FillMode = FillMode.Solid };
                GraphicsDevice.DepthStencilState = new DepthStencilState() { DepthBufferEnable = true };
            }

            //Draws the skeleton
            if (showSkeleton)
            {
                DrawSkeleton();
            }

            //Draws the controls
            DrawInformation();

            base.Draw(gameTime);
        }

        /// <summary>
        /// Draws the mesh onto the screen.
        /// </summary>
        /// <param name="model"></param>
        private void DrawModel(Model model)
        {
            Matrix[] modelTransforms = new Matrix[myModel.Bones.Count];
            myModel.CopyAbsoluteBoneTransformsTo(modelTransforms);

            //Get updated transforms from the animation player
            Matrix[] skinBone = animationPlayer.GetSkinTransforms();

            foreach (ModelMesh mesh in myModel.Meshes)
            {
                if (modelHasSkeleton)
                {
                    foreach (SkinnedEffect effect in mesh.Effects)
                    {
                        effect.SetBoneTransforms(skinBone);

                        effect.View = view;
                        effect.Projection = projection;
                        effect.World = modelTransforms[mesh.ParentBone.Index];

                        effect.EnableDefaultLighting();

                    }
                }
                else
                {
                    foreach (BasicEffect effect in mesh.Effects)
                    {
                        effect.View = view;
                        effect.Projection = projection;
                        effect.World = modelTransforms[mesh.ParentBone.Index];

                        effect.EnableDefaultLighting();
                    }
                }
                mesh.Draw();
            }
        }

        /// <summary>
        /// Draws the skeleton onto the screen.
        /// </summary>
        private void DrawSkeleton()
        {
            Matrix world = Matrix.CreateTranslation(0, 0, 0);

            //Some debug colouring for the bones
            Color c = new Color(255, 255, 0, 100);

            for(int i = 0; i < myModel.Bones.Count; i++)
            {
                world = ComputeMatrix(myModel.Bones[i], Matrix.Identity);

                //Recolours certain sections of the model (Goblin version) to make it easier to see which body part is which
                //Left Shoulder - Red
                if (i == 6)
                {
                    c = new Color(255, 0, 0);
                }
                //Left Elbow - Green
                else if(i == 7)
                {
                    c = new Color(0, 255, 0);
                }
                //Left Hip - Purple
                else if (i == 35)
                {
                    c = new Color(255, 0, 255);
                }
                //Left Knee - Pink
                else if (i == 36)
                {
                    c = new Color(255, 0, 100);
                }
                //Left Ankle - Blue
                else if (i == 37)
                {
                    c = new Color(0, 0, 255);
                }
                //Right Hip - Green
                else if (i == 39)
                {
                    c = new Color(0, 255, 0);
                }
                //Right Knee - Light Blue
                else if (i == 40)
                {
                    c = new Color(0, 255, 255);
                }
                //Right Ankle - White
                else if (i == 41)
                {
                    c = new Color(255, 255, 255);
                }
                else
                {
                   c = new Color(255, 255, 0);
                }

                skeletonJointPrimitive.Draw(world, view, projection, c);

                //Also draw kinect skeleton
                if (kinect.Initialized && kinect.SkeletonData != null && useKinect && drawKinectSkeleton)
                {
                    foreach (Joint j in kinect.SkeletonData.Joints)
                    {
                        skeletonJointPrimitive.Draw(Matrix.CreateTranslation((j.Position.X - kinect.ModelOffset.X) * kinect.ModelScale, (j.Position.Y - kinect.ModelOffset.Y) * kinect.ModelScale + 40, (j.Position.Z - kinect.ModelOffset.Z) * kinect.ModelScale), view,
                                    projection, Color.Red);
                    }
                }

            }
        }

        /// <summary>
        /// Fired when the kinect is turned on and it finds skeletal data.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void kinect_SkeletonFirstFrameReady(object sender, EventArgs e)
        {
            //Wait 0.5secs and then try to get a decent model scale
            skeletonScaleTimer = 500;
        }

        /// <summary>
        /// Creates the world matrix for the nodes in the skeleton.
        /// </summary>
        /// <param name="bone"></param>
        /// <param name="m1"></param>
        /// <returns></returns>
        private static Matrix ComputeMatrix(ModelBone bone, Matrix m1)
        {
            Matrix m2 = m1 * bone.Transform;
            if (bone.Parent == null)
                return m2;
            return ComputeMatrix(bone.Parent, m2);

        }

        /// <summary>
        /// Outputs the bone information into VS output window.
        /// </summary>
        /// <param name="bone"></param>
        /// <param name="indent"></param>
        [System.Diagnostics.Conditional("DEBUG")]
        private static void DebugPrintBones(ModelBone bone, string indent)
        {
            System.Diagnostics.Debug.WriteLine(indent + "Index : " + bone.Index + ". Name: " + bone.Name + " (" + bone.Children.Count + ")");
            System.Diagnostics.Debug.WriteLine(indent + ">>" + bone.Transform.Translation);
            if (bone.Children != null && bone.Children.Count > 0)
            {
                indent += "....|";
                foreach (ModelBone b in bone.Children)
                    DebugPrintBones(b, indent);
            }
        }

        /// <summary>
        /// Draws the bones between the nodes in the skeleton.
        /// </summary>
        /// <param name="bone"></param>
        private void JoinBones(ModelBone bone, ref List<VertexPositionNormalTexture> vertices, ref List<short> indicies)
        {
            //Get this bone's position
            Matrix world = ComputeMatrix(bone, Matrix.Identity);
            //Add the position to the list, it will be the p2 of the last line and then p1 of all children lines
            var pos = new VertexPositionNormalTexture(new Vector3(world.M41, world.M42, world.M43), Vector3.Forward, new Vector2());
            vertices.Add(pos);
            indicies.Add((short)(vertices.Count - 1));

            for(int i = 0; i < bone.Children.Count; i++)
            {
                JoinBones(bone.Children[i], ref vertices, ref indicies);
                //Add p1 for next child line
                vertices.Add(pos);
                indicies.Add((short)(vertices.Count - 1));
            }
        }

        /// <summary>
        /// A user interface to give instructions for how to use the camera and toggle the components of the model.
        /// </summary>
        private void DrawInformation()
        {
            spriteBatch.Begin();

            spriteBatch.DrawString(font, (kinect.Initialized ? (useKinect? "1 - Stop kinect" : "1 - Use Kinect") : "1 - No kinect found") +
                                   "  2 - Toggle wireframe  3 - Toggle skeleton  4 - Toggle skin  "
                                   + (useKinect? "SPACEBAR - " + (recordKinect? "Stop recording kinect" : "Start kinect recording") : 
                                   "SPACEBAR - Play/Pause  ENTER - Stop") 
                                   + (kinect.Initialized && useKinect? "  5 - Show kinect" : ""),
                                   new Vector2(3, 10), Color.White);

            if(modelHasSkeleton)
                spriteBatch.DrawString(font, (useKinect? "" : "TAB - Next animation  Current animation: '" + currentAnimationClipName + "'"),
                                       new Vector2(3, 30), Color.White);

            spriteBatch.DrawString(font,
                                   "UP DOWN LEFT RIGHT - Rotate  W A S D - Move  Z - Zoom out  X - Zoom In  R - Reset camera" ,
                                   new Vector2(10, graphics.PreferredBackBufferHeight - 40), Color.White);
            if (recordKinect)
            {
                spriteBatch.DrawString(font,
                                   "RECORDING KINECT",
                                   new Vector2(graphics.PreferredBackBufferWidth - 180, graphics.PreferredBackBufferHeight - 40), Color.Red);
            }

            if (kinect.Initialized && skeletonScaleTimer > 0)
            {
                spriteBatch.DrawString(font,
                                   "...GETTING KINECT SCALE...",
                                   new Vector2(graphics.PreferredBackBufferWidth / 2 - 150, graphics.PreferredBackBufferHeight / 2), Color.White);
            }

            spriteBatch.End();
        }

        #region Handle Input

        /// <summary>
        /// Was a key pressed.
        /// </summary>
        /// <param name="key"></param>
        /// <returns>boolean</returns>
        private bool WasPressed(Keys key)
        {
            return (currentKeyboardState.IsKeyUp(key) && previousKeyboardState.IsKeyDown(key));
        }

        /// <summary>
        /// Handles input for quitting the game.
        /// </summary>
        private void HandleInput()
        {
            previousKeyboardState = currentKeyboardState;
            currentKeyboardState = Keyboard.GetState();

            // Check for exit.
            if (currentKeyboardState.IsKeyDown(Keys.Escape))
            {
                Exit();
            }

            if (WasPressed(Keys.NumPad1) || (WasPressed(Keys.D1)) && kinect.Initialized && modelHasSkeleton)
            {
                if (!useKinect)
                {
                    //About to turn on use kinect so
                    //Kinect uses animation player
                    animationPaused = false;
                    animationStopped = false;
                    kinect.Reset();
                }
                else
                {
                    //About to turn off kinect so
                    //Stop animation
                    animationPaused = false;
                    animationStopped = true;
                    //Put back the last animation
                    if(currentAnimationClip != null)
                        animationPlayer.StartClip(currentAnimationClip);
                }
                useKinect = !useKinect;
            }

            //Controls the wireframe display
            if (WasPressed(Keys.NumPad2) || (WasPressed(Keys.D2)))
            {
                showWireframe = !showWireframe;
            }

            //controls the model's skeleton display
            if (WasPressed(Keys.NumPad3) || (WasPressed(Keys.D3)) && modelHasSkeleton)
            {
                showSkeleton = !showSkeleton;
            }
            
            //controls the model display
            if (WasPressed(Keys.NumPad4) || (WasPressed(Keys.D4)))
            {
                showModel = !showModel;
            }

            //controls the kinect's skeleton display
            if (WasPressed(Keys.NumPad5) || (WasPressed(Keys.D5)))
            {
                drawKinectSkeleton = !drawKinectSkeleton;
            }

            //makes the animation player play the next clip
            if (WasPressed(Keys.Tab) && modelHasSkeleton && !useKinect)
            {
                var nextClip = NextAnimationClip();
                if (nextClip != null)
                {
                    currentAnimationClip = nextClip.Item1;
                    currentAnimationClipName = nextClip.Item2;
                    currentAnimationClipIndex = nextClip.Item3;
                    animationPlayer.StartClip(currentAnimationClip);
                }
            }

            //controls the pause feature for the animation player
            if (WasPressed(Keys.Space) && modelHasSkeleton)
            {
                if (!useKinect)
                {
                    //Make space bar play stopped animation
                    if (animationStopped)
                    {
                        animationStopped = false;
                        animationPaused = false;
                    }
                    else
                        animationPaused = !animationPaused;
                }
                else
                {
                    //When using kinect the space bar starts and stops recording
                    recordKinect = !recordKinect;
                    if (recordKinect)
                    {
                        kinect.StartRecording();
                        lastFrame = DateTime.Now.TimeOfDay.TotalMilliseconds;
                    }
                    else
                        kinect.StopRecording();
                }
            }

            //controls the stop feature for the animation player
            if (WasPressed(Keys.Enter) && !useKinect)
            {
                animationStopped = true;
            }

            //Manual button to scale the kinect skeleton to the model's skeleton
            if (WasPressed(Keys.Q) && useKinect)
            {
                kinect.ScaleKinectSkeletonToModel(myModel);
            }
        }

        /// <summary>
        /// Handles camera input.
        /// </summary>
        private void UpdateCamera(GameTime gameTime)
        {
            float time = (float)gameTime.ElapsedGameTime.TotalMilliseconds;

            //moves the camera down
            if (currentKeyboardState.IsKeyDown(Keys.S))
            {
                cameraY += time * 0.1f;
            }

            //moves the camera up
            if (currentKeyboardState.IsKeyDown(Keys.W))
            {
                cameraY -= time * 0.1f;
            }

            //moves the camera right
            if (currentKeyboardState.IsKeyDown(Keys.D))
            {
                cameraX += time * 0.1f;
            }

            //moves the camera left
            if (currentKeyboardState.IsKeyDown(Keys.A))
            {
                cameraX -= time * 0.1f;
            }

            // Check for input to rotate the camera up and down around the model.
            if (currentKeyboardState.IsKeyDown(Keys.Up))
            {
                cameraArc += time * 0.1f;
            }

            if (currentKeyboardState.IsKeyDown(Keys.Down))
            {
                cameraArc -= time * 0.1f;
            }

            // Check for input to rotate the camera horizontally around the model.
            if (currentKeyboardState.IsKeyDown(Keys.Right))
            {
                cameraRotation += time * 0.1f;
            }

            if (currentKeyboardState.IsKeyDown(Keys.Left))
            {
                cameraRotation -= time * 0.1f;
            }


            // Check for input to zoom camera in and out.
            if (currentKeyboardState.IsKeyDown(Keys.Z))
                cameraDistance += time * 0.25f;

            if (currentKeyboardState.IsKeyDown(Keys.X))
                cameraDistance -= time * 0.25f;

            //resets the camera
            if (currentKeyboardState.IsKeyDown(Keys.R))
            {
                cameraArc = 0;
                cameraRotation = 0;
                cameraDistance = 100;
            }
        }

        #endregion
    }
}
