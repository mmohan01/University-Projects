﻿using System;
using System.IO;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Serialization;
using Microsoft.Xna.Framework.Content.Pipeline;
using TOutput = Microsoft.Xna.Framework.Content.Pipeline.Graphics.NodeContent;

namespace ColladaImporter
{
    /// <summary>
    /// This class will be instantiated by the XNA Framework Content Pipeline
    /// to apply custom processing to content data, converting an object of
    /// type TInput to TOutput. The input and output types may be the same if
    /// the processor wishes to alter data without changing its type.
    ///
    /// This should be part of a Content Pipeline Extension Library project.
    /// </summary>
    [ContentImporter(".dae", DisplayName = "Collada Importer", CacheImportedData = true, DefaultProcessor = "ModelProcessor")]
    public class ColladaContentImporter : ContentImporter<TOutput>
    {
        /// <summary>
        /// Called to import content.
        /// </summary>
        /// <param name="filename"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public override TOutput Import(string filename, ContentImporterContext context)
        {
            var fileInfo = new FileInfo(filename);
            Logging.CreateErrorLogFile(fileInfo.Name);
            FileStream fs = null;
            try
            {
                //Check for anything not within the Collada xml schema
                //if (ValidateXml(filename))
                {
                    var serializer = new XmlSerializer(typeof(Base.COLLADA));
                    fs = new FileStream(filename, FileMode.Open);
                    var reader = new XmlTextReader(fs);
                    var collada = (Base.COLLADA)serializer.Deserialize(reader);

                    if (collada != null)
                    {
                        return collada.Build(fileInfo);
                    }
                }
                return null;
            }
            catch (Exception e)
            {
                Logging.LogError(e.ToString());
                return null;
            }
            finally
            {
                if (fs != null)
                    fs.Close();
            }
        }

        /// <summary>
        /// Check the imported xml against schema.
        /// </summary>
        /// <param name="filename"></param>
        private bool ValidateXml(String filename)
        {
            #region Load the schema in from the resource file

            XmlSchemaCollection xsc = new XmlSchemaCollection();
            byte[] bytes = System.Text.Encoding.UTF8.GetBytes(Resources.collada_schema_1_4);
            Stream stream = new MemoryStream(bytes);
            XmlReader reader = new XmlTextReader(stream);
            xsc.Add(null, reader);

            #endregion

            XmlTextReader xmlreader = null;
            XmlValidatingReader valreader = null;
            bool xmlValid = true;

            xmlreader = new XmlTextReader(filename);
            valreader = new XmlValidatingReader(xmlreader);
            valreader.Schemas.Add(xsc);
            valreader.ValidationEventHandler += delegate(object sender, ValidationEventArgs args)
            {
                Logging.LogError("Xml validation error: " + args.Message);
                xmlValid = false;
            };

            try
            {
                while (valreader.Read()) { }
            }
            catch
            {
                Logging.LogError("Error validating collada document.");
                xmlValid = false;
            }
            valreader.Close();
            reader.Close();
            xmlreader.Close();
            return xmlValid;
        }
    }
}