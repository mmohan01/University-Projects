using System.ComponentModel;
using ColladaImporter.Base;
using ColladaImporter.Processor;
using System;
using System.IO;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content.Pipeline;
using Microsoft.Xna.Framework.Content.Pipeline.Graphics;
using Microsoft.Xna.Framework.Content.Pipeline.Processors;
using Shared;

// TODO: replace these with the processor input and output types.

namespace ColladaImporter
{
    /// <summary>
    /// This class will be instantiated by the XNA Framework Content Pipeline
    /// to apply custom processing to content data, converting an object of
    /// type TInput to TOutput. The input and output types may be the same if
    /// the processor wishes to alter data without changing its type.
    ///
    /// This should be part of a Content Pipeline Extension Library project.
    ///
    /// TODO: change the ContentProcessor attribute to specify the correct
    /// display name for this processor.
    /// </summary>
    [ContentProcessor(DisplayName = "Collada Processor")]
    public class ColladaContentProcessor : ModelProcessor
    {
        public override ModelContent Process(NodeContent input, ContentProcessorContext context)
        {
            System.IO.FileInfo f = new FileInfo(context.OutputFilename);
            Logging.CreateErrorLogFile(f.Name.Replace(f.Extension, " - Processor.html"));
            
            var modelContent = base.Process(input, context);
            Dictionary<int, int> kinectSkeletonMap = SkeletonAnalyzer.Analyze(modelContent);
            
            var skel = MeshHelper.FindSkeleton(input);
            if (skel == null)
            {
                Logging.LogSuccessful("No skeletal information found. Standard model created successfully.");
                DefaultEffect = MaterialProcessorDefaultEffect.BasicEffect;
                return modelContent;
                //throw new InvalidContentException("Input skeleton not found.");
            }

          
            FlattenTransforms(input, skel);
            IList<BoneContent> bones = MeshHelper.FlattenSkeleton(skel);
            
            //Checks if the skeleton has more bones than the amount that can be stored
            if (bones.Count > SkinnedEffect.MaxBones)
            {
                Logging.LogError("Model has too many bones (Max = " + SkinnedEffect.MaxBones + ")");
                throw new InvalidContentException(string.Format(
                    "Skeleton has {0} bones, but the maximum supported is {1}.",
                    bones.Count, SkinnedEffect.MaxBones));
            }

            //Creates lists to store information on each bone, which is needed for the animation player's multiplications
            List<Matrix> bindPose = new List<Matrix>();
            List<Matrix> inverseBindPose = new List<Matrix>();
            List<int> skeletonHierarchy = new List<int>();

            //Gets the transform, inverted transform and parent of each bone in the skeleton, storing them in lists
            foreach (BoneContent bone in bones)
            {

                bindPose.Add(bone.Transform);
                inverseBindPose.Add(Matrix.Invert(bone.AbsoluteTransform));
                skeletonHierarchy.Add(bones.IndexOf(bone.Parent as BoneContent));


                // LUKAS TO FIX THIS!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


                //     bindPose[i] = ((weights[i][i].Weight * bindPose[i]) * inverseBindPose[i] * bindPose[i].Translation.X);
                //    bindPose[i] = ((weights[i][i].Weight * bindPose[i]) * inverseBindPose[i] * bindPose[i].Translation.Y);

            }

         /*
            List<Vector4> blendI = new List<Vector4>();
            List<Vector4> blendW = new List<Vector4>();
            List<Vector3> verticies = new List<Vector3>();
            foreach(NodeContent node in input.Children)
            {
                if (node.GetType() == typeof(MeshContent))
                {
                    MeshContent meshContent = (MeshContent)node;
                    IEnumerable<Microsoft.Xna.Framework.Graphics.PackedVector.Byte4> blendIndices = null;
                    IEnumerable<Vector4> blendWeights = null;
                    verticies = new List<Vector3>(meshContent.Geometry[0].Vertices.Positions);

                    #region Find Bone Weights and add to collection
                    foreach (var channel in meshContent.Geometry[0].Vertices.Channels)
                    {
                        if (channel.Name == "BlendIndices0")
                        {
                            //We have a bone weight collection
                            blendIndices = channel.ReadConvertedContent<Microsoft.Xna.Framework.Graphics.PackedVector.Byte4>();
                        }
                        else if (channel.Name == "BlendWeight0")
                        {
                            blendWeights = channel.ReadConvertedContent<Vector4>();
                        }

                        
                    }
                    foreach (var blendIndex in blendIndices)
                    {
                        blendI.Add(blendIndex.ToVector4());
                    }
                    foreach (var blendWeight in blendWeights)
                    {
                        blendW.Add(blendWeight);
                    }

                    #endregion

                    for (int i = 0; i < blendI.Count; i++ )
                    {
                        Matrix m = Matrix.Identity;
                        m += (inverseBindPose[(int)blendI[i].X] * bones[(int)blendI[i].X].Transform) * blendW[i].X;
                        m += (inverseBindPose[(int)blendI[i].Y] * bones[(int)blendI[i].Y].Transform) * blendW[i].Y;
                        m += (inverseBindPose[(int)blendI[i].Z] * bones[(int)blendI[i].Z].Transform) * blendW[i].Z;
                        m += (inverseBindPose[(int)blendI[i].W] * bones[(int)blendI[i].W].Transform) * blendW[i].W;
                        Vector3 newPosition = Vector3.Transform(verticies[i], m);

                        verticies[i] = newPosition;
                        meshContent.Geometry[0].Vertices.Positions[i] = new Vector3();
                    }

                    break;
                }

            }
   */
            
            var animationClips = ProcessAnimations(input.Animations, bones);

            modelContent.Tag = new SkeletonFormat(bindPose, inverseBindPose, skeletonHierarchy, kinectSkeletonMap, animationClips);

            Logging.LogSuccessful("Skeletal information found. Animated model created successfully");
            return modelContent;
            
        }
        

        

        /// <summary>
        /// Force all the materials to use our skinned model effect.
        /// </summary>
        [DefaultValue(MaterialProcessorDefaultEffect.SkinnedEffect)]
        public override MaterialProcessorDefaultEffect DefaultEffect
        {
            get { return MaterialProcessorDefaultEffect.SkinnedEffect; }
            set { }
        }

        /// <summary>
        /// Converts the transforms of each bone into the local co-ordinate system
        /// </summary>
        /// <param name="node">The current bone to work on</param>
        /// <param name="skeleton"></param>
        static void FlattenTransforms(NodeContent node, BoneContent skeleton)
        {
            //Loops for each child the current node has
            foreach (NodeContent child in node.Children)
            {
                // Don't process the skeleton, because that is special.
                if (child == skeleton)
                    continue;

                // Convert the transform into the actual geometry.
                MeshHelper.TransformScene(child, child.Transform);

                //Change the transform back to identity.
                child.Transform = Matrix.Identity;

                // Recurse.
                FlattenTransforms(child, skeleton);
            }
        }

        /// <summary>
        /// Converts an intermediate format content pipeline AnimationContentDictionary
        /// object to our runtime AnimationClip format.
        /// </summary>
        static Dictionary<string, AnimationClip> ProcessAnimations(
            AnimationContentDictionary animations, IList<BoneContent> bones)
        {
            // Build up a table mapping bone names to indices.
            Dictionary<string, int> boneMap = new Dictionary<string, int>();

            for (int i = 0; i < bones.Count; i++)
            {
                string boneName = bones[i].Name;

                if (!string.IsNullOrEmpty(boneName))
                    boneMap.Add(boneName, i);
            }

            // Convert each animation in turn.
            Dictionary<string, AnimationClip> animationClips;
            animationClips = new Dictionary<string, AnimationClip>();

            foreach (KeyValuePair<string, AnimationContent> animation in animations)
            {
                AnimationClip processed = ProcessAnimation(animation.Value, boneMap);

                animationClips.Add(animation.Key, processed);
            }

            //Checks if any animations have been found and stored
            if (animationClips.Count == 0)
            {
                Logging.LogError("Input file does not contain any animations.");
                throw new InvalidContentException(
                            "Input file does not contain any animations.");
            }

            return animationClips;
        }


        /// <summary>
        /// Converts an intermediate format content pipeline AnimationContent
        /// object to our runtime AnimationClip format.
        /// </summary>
        static AnimationClip ProcessAnimation(AnimationContent animation,
                                              Dictionary<string, int> boneMap)
        {
            List<Keyframe> keyframes = new List<Keyframe>();

            // For each input animation channel.
            foreach (KeyValuePair<string, AnimationChannel> channel in
                animation.Channels)
            {
                // Look up what bone this channel is controlling.
                int boneIndex;

                //Stops the program trying to process an animation for a bone that doesn't exist in the skeleton
                if (!boneMap.TryGetValue(channel.Key, out boneIndex))
                {
                    var msg = string.Format(
                        "Found animation for bone '{0}', " +
                        "which is not part of the skeleton.", channel.Key);
                    Logging.LogError(msg);
                    throw new InvalidContentException(msg);
                }

                // Convert the keyframe data.
                foreach (AnimationKeyframe keyframe in channel.Value)
                {
                    keyframes.Add(new Keyframe(boneIndex, keyframe.Time,
                                               Matrix.Transpose(keyframe.Transform)));
                }
            }

            // Sort the merged keyframes by time.
            keyframes.Sort(CompareKeyframeTimes);

            //Checks if the animation has any keyframes, stopping the program if it doesn't
            if (keyframes.Count == 0)
            {
                Logging.LogError("Animation has no keyframes.");
                throw new InvalidContentException("Animation has no keyframes.");
            }

            //Checks if the animation has a timespan that is playable, stopping the program if it doesn't
            if (animation.Duration <= TimeSpan.Zero)
            {
                Logging.LogError("Animation has a zero duration.");
                throw new InvalidContentException("Animation has a zero duration.");
            }

            return new AnimationClip(animation.Duration, keyframes);
        }


        /// <summary>
        /// Comparison function for sorting keyframes into ascending time order.
        /// </summary>
        static int CompareKeyframeTimes(Keyframe a, Keyframe b)
        {
            return a.Time.CompareTo(b.Time);
        }

    }
}