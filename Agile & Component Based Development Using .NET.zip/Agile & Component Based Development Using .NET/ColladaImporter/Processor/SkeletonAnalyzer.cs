﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content.Pipeline.Processors;
using Shared;

namespace ColladaImporter.Processor
{
    /// <summary>
    /// Assumptions:
    /// - Model is upright and facing you
    /// - Centre of the hip is the first joint from the root.
    /// - There is a left and right hip
    /// - There is a left and right shoulder from a central shoulder joint
    /// - We can deal with up to 3 arm/leg bones and a collar/extra hip like bone.
    /// </summary>
    public class SkeletonAnalyzer
    {
        private static Dictionary<int,int> skeletonMap = new Dictionary<int, int>();
        private static ModelContent model;

        /// <summary>
        /// Create a kinect skeleton map for a humanoid biped skeleton.
        /// </summary>
        /// <param name="modelContent">Model.</param>
        /// <returns>Map of indices between kinect joints and model joints.</returns>
        public static Dictionary<int, int> Analyze(ModelContent modelContent)
        {
            model = modelContent;

            var boxRoot = new GroupedSkeletalHierarchy();
            BoxSkeleton(modelContent.Root.Children[0], ref boxRoot);
            boxRoot = boxRoot.SubBoxes[0];

            #region Hip & Spine

            //First group parent is the centre hip, pick the legs and spine
            skeletonMap.Add((int)JointID.HipCenter, boxRoot.Parent);

            MapMajors(boxRoot, new int[] { (int)JointID.HipLeft, (int)JointID.HipRight, (int)JointID.Spine });
            
            #endregion

            #region Legs

            MapLimbs(JointID.HipLeft, boxRoot[skeletonMap[(int)JointID.HipLeft]], new int[] { (int)JointID.KneeLeft, (int)JointID.AnkleLeft, (int)JointID.FootLeft });
            MapLimbs(JointID.HipRight, boxRoot[skeletonMap[(int)JointID.HipRight]], new int[] { (int)JointID.KneeRight, (int)JointID.AnkleRight, (int)JointID.FootRight });
            
            #endregion

            #region Spine, Shoulders, Head and Arms

            var spineBox = boxRoot[skeletonMap[(int) JointID.Spine]];
            skeletonMap.Add((int)JointID.ShoulderCenter, spineBox.Children[spineBox.Children.Count - 1]);

            if(spineBox.SubBoxes.Count == 1)
            {
                MapMajors(spineBox.SubBoxes[0], new int[] {(int) JointID.ShoulderLeft, (int) JointID.ShoulderRight, (int) JointID.Head});
                //This box is the shoulders and possibly head

                #region arms

                MapLimbs(JointID.ShoulderLeft, spineBox.SubBoxes[0][skeletonMap[(int)JointID.ShoulderLeft]], new int[] { (int)JointID.ElbowLeft, (int)JointID.WristLeft, (int)JointID.HandLeft });
                MapLimbs(JointID.ShoulderRight, spineBox.SubBoxes[0][skeletonMap[(int)JointID.ShoulderRight]], new int[] { (int)JointID.ElbowRight, (int)JointID.WristRight, (int)JointID.HandRight });

                #endregion
            }
            else
            {
                //We have a problem
            }

            #endregion

            return skeletonMap;
        }

        /// <summary>
        /// Map either the hip section or shoulder section to the kinect.
        /// </summary>
        /// <param name="majorSection">Grouped section.</param>
        /// <param name="possibilities">Possible kinect joints in order of left, right and up.</param>
        private static void MapMajors(GroupedSkeletalHierarchy majorSection, int[] possibilities)
        {
            Matrix pos1 = ComputeMatrix(model.Bones[majorSection.Children[0]], Matrix.Identity);
            Matrix pos2 = ComputeMatrix(model.Bones[majorSection.Children[1]], Matrix.Identity);
            Matrix pos3 = ComputeMatrix(model.Bones[majorSection.Children[2]], Matrix.Identity);

            var positions = new float[] { pos1.Translation.X, pos2.Translation.X, pos3.Translation.X };
            var copy = new List<int>(majorSection.Children);

            int screenRightMajorIndex = positions.Min();
            int screenLeftMajorIndex = positions.Max();
            //Remove the found indices to get the middle index
            copy.RemoveAt(screenRightMajorIndex);
            if(screenLeftMajorIndex > 0)
                copy.RemoveAt(screenLeftMajorIndex - 1);

            skeletonMap.Add(possibilities[0], majorSection.Children[screenRightMajorIndex]);
            skeletonMap.Add(possibilities[1], majorSection.Children[screenLeftMajorIndex]);
            //Only one left is the middle joint
            skeletonMap.Add(possibilities[2], copy[0]);
        }

        /// <summary>
        /// Map the limbs to the kinect.
        /// </summary>
        /// <param name="parent">Parent kinect JointID.</param>
        /// <param name="limb">Grouped section.</param>
        /// <param name="possibilities">Possible kinect joints in the order that you would add them looking down the limb.</param>
        private static void MapLimbs(JointID parent, GroupedSkeletalHierarchy limb, int[] possibilities )
        {
            if (limb.SubBoxes.Count > 0)
            {
                // this arm has a hand

                if(limb.Children.Count == 3)
                {
                    // there are too many joints, possibly have collar bones where our shoulders are currently mapped, correct them.
                    skeletonMap[(int)parent] = limb.Children[0];

                    // straight map
                    skeletonMap.Add(possibilities[0], limb.Children[1]);
                    skeletonMap.Add(possibilities[1], limb.Children[2]);

                    switch(parent)
                    {
                        case JointID.ShoulderLeft:
                            skeletonMap.Add((int)JointID.HandLeft, limb.SubBoxes[0].Children[0]);
                            break;
                        case JointID.ShoulderRight:
                            skeletonMap.Add((int)JointID.HandRight, limb.SubBoxes[0].Children[0]);
                            break;
                        case JointID.HipLeft:
                            skeletonMap.Add((int)JointID.FootLeft, limb.SubBoxes[0].Children[0]);
                            break;
                        case JointID.HipRight:
                            skeletonMap.Add((int)JointID.FootRight, limb.SubBoxes[0].Children[0]);
                            break;
                    }
                    return;
                }
            }

            if (limb.Children.Count == 3)
            {
                // straight map
                skeletonMap.Add(possibilities[0], limb.Children[0]);
                skeletonMap.Add(possibilities[1], limb.Children[1]);
                //Only one left is the middle joint
                skeletonMap.Add(possibilities[2], limb.Children[2]);
            }
            else if (limb.Children.Count == 1)
            {
                //assuming that we only have an ankle/wrist
                skeletonMap.Add(possibilities[1], limb.Children[0]);
            }
            else if (limb.Children.Count == 2)
            {
                // asssuming that we only have a knee/elbow and an ankle/wrist
                skeletonMap.Add(possibilities[0], limb.Children[0]);
                skeletonMap.Add(possibilities[1], limb.Children[1]);

            }
            else if (limb.Children.Count == 4)
            {
                // there are too many joints, possibly have collar bones where our shoulders are currently mapped, correct them.
                skeletonMap[(int)parent] = limb.Children[0];

                // straight map
                skeletonMap.Add(possibilities[0], limb.Children[1]);
                skeletonMap.Add(possibilities[1], limb.Children[2]);
                skeletonMap.Add(possibilities[2], limb.Children[3]);

                //switch (parent)
                //{
                //    case JointID.ShoulderLeft:
                //        skeletonMap.Add((int)JointID.HandLeft, limb.Children[3]);
                //        break;
                //    case JointID.ShoulderRight:
                //        skeletonMap.Add((int)JointID.HandRight, limb.Children[3]);
                //        break;
                //    case JointID.HipLeft:
                //        skeletonMap.Add((int)JointID.FootLeft, limb.Children[3]);
                //        break;
                //    case JointID.HipRight:
                //        skeletonMap.Add((int)JointID.FootRight, limb.Children[3]);
                //        break;
                //}
            }
            else
            {
                //We are not this magical
                Logging.LogUnsupported("Too many limb bones...We are not this magical");
            }
        }

        /// <summary>
        /// Calculate the bone matrix.
        /// </summary>
        /// <param name="bone"></param>
        /// <param name="m1"></param>
        /// <returns></returns>
        private static Matrix ComputeMatrix(ModelBoneContent bone, Matrix m1)
        {
            Matrix m2 = m1 * bone.Transform;
            if (bone.Parent == null)
                return m2;
            return ComputeMatrix(bone.Parent, m2);

        }

        /// <summary>
        /// Group the model skeleton into major sections.
        /// </summary>
        /// <param name="parent"></param>
        /// <param name="box"></param>
        private static void BoxSkeleton(ModelBoneContent parent, ref GroupedSkeletalHierarchy box)
        {
            if (parent.Children.Count > 1)
            {
                //Create new box with this parent as the boxes parent
                var subBox = new GroupedSkeletalHierarchy { Parent = FindBoneIndex(parent.Name) };
                box.SubBoxes.Add(subBox);
                foreach (var bone in parent.Children)
                {
                    subBox.Children.Add(FindBoneIndex(bone.Name));
                    if (bone.Children.Count > 0)
                    {
                        var boxI = new GroupedSkeletalHierarchy { Parent = FindBoneIndex(bone.Name) };
                        subBox.SubBoxes.Add(boxI);
                        BoxSkeleton(bone, ref boxI);
                    }
                }

            }
            else if (parent.Children.Count == 1)
            {
                box.Children.Add(FindBoneIndex(parent.Children[0].Name));
                BoxSkeleton(parent.Children[0], ref box);
            }
        }
        
        /// <summary>
        /// Creates boxes to place the kinect skeleton into. Not used now.
        /// </summary>
        /// <returns></returns>
        private static GroupedSkeletalHierarchy GenerateKinectBox()
        {
            var boxRoot = new GroupedSkeletalHierarchy();
            //Start at HipCenter
            var boxA = new GroupedSkeletalHierarchy { Parent = (int)JointID.HipCenter };
            boxA.Children.Add((int)JointID.Spine);
            boxA.Children.Add((int)JointID.HipLeft);
            boxA.Children.Add((int)JointID.HipRight);

            var boxD = new GroupedSkeletalHierarchy { Parent = (int)JointID.Spine };
            boxD.Children.Add((int)JointID.ShoulderCenter);
            boxA.SubBoxes.Add(boxD);

            var boxE = new GroupedSkeletalHierarchy { Parent = (int)JointID.ShoulderCenter };
            boxE.Children.Add((int)JointID.Head);
            boxE.Children.Add((int)JointID.ShoulderLeft);
            boxE.Children.Add((int)JointID.ShoulderRight);
            boxD.SubBoxes.Add(boxE);

            var boxF = new GroupedSkeletalHierarchy { Parent = (int)JointID.ShoulderLeft };
            boxF.Children.Add((int)JointID.ElbowLeft);
            boxF.Children.Add((int)JointID.WristLeft);
            boxF.Children.Add((int)JointID.HandLeft);
            boxE.SubBoxes.Add(boxF);

            var boxG = new GroupedSkeletalHierarchy { Parent = (int)JointID.ShoulderRight };
            boxG.Children.Add((int)JointID.ElbowRight);
            boxG.Children.Add((int)JointID.WristRight);
            boxG.Children.Add((int)JointID.HandRight);
            boxE.SubBoxes.Add(boxG);

            var boxB = new GroupedSkeletalHierarchy { Parent = (int)JointID.HipLeft };
            boxB.Children.Add((int)JointID.KneeLeft);
            boxB.Children.Add((int)JointID.AnkleLeft);
            boxB.Children.Add((int)JointID.FootLeft);
            boxA.SubBoxes.Add(boxB);

            var boxC = new GroupedSkeletalHierarchy { Parent = (int)JointID.HipRight };
            boxC.Children.Add((int)JointID.KneeRight);
            boxC.Children.Add((int)JointID.AnkleRight);
            boxC.Children.Add((int)JointID.FootRight);
            boxA.SubBoxes.Add(boxC);

            return boxA;
        }

        /// <summary>
        /// Return bone index based on bone name.
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        private static int FindBoneIndex(string name)
        {
            for (int i = 0; i < model.Bones.Count; i++)
            {
                if (model.Bones[i].Name == name)
                    return i;
            }
            return -1;
        }

        /// <summary>
        /// Kinect joint ids/
        /// </summary>
        public enum JointID
        {
            HipCenter,
            Spine,
            ShoulderCenter,
            Head,
            ShoulderLeft,
            ElbowLeft,
            WristLeft,
            HandLeft,
            ShoulderRight,
            ElbowRight,
            WristRight,
            HandRight,
            HipLeft,
            KneeLeft,
            AnkleLeft,
            FootLeft,
            HipRight,
            KneeRight,
            AnkleRight,
            FootRight,
            Count,
        }
    }

    public static class Extensions
    {
        /// <summary>
        /// Get the minimum value in the array.
        /// </summary>
        /// <param name="values"></param>
        /// <returns>Index of the smallest value.</returns>
        public static int Min(this float[] values)
        {
            int index = 0;
            float min = values[index];
            for (int i = 0; i < values.Length; i++)
                if (values[i] < min)
                {
                    min = values[i];
                    index = i;
                }
            return index;
        }

        /// <summary>
        /// Get the minimum value in the array.
        /// </summary>
        /// <param name="values"></param>
        /// <returns>Index of the biggest value.</returns>
        public static int Max(this float[] values)
        {
            int index = 0;
            float max = values[index];
            for (int i = 0; i < values.Length; i++)
                if (values[i] > max)
                {
                    max = values[i];
                    index = i;
                }
            return index;
        }
    }

}
