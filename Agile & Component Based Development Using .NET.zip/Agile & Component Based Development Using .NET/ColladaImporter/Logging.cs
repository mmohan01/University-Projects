﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace ColladaImporter
{
    public static class Logging
    {
        public static StreamWriter logFile;
        public static string logFileName;
        private static bool logInintialized;

        #region Create Log File
        /// <summary>
        /// Creates a new empty log file.
        /// </summary>
        [Conditional("DEBUG")] //Means the log file will only run if the project is in debug mode
        static public void CreateErrorLogFile(string modelFileName = "")
        {
            string timeStamp = DateTime.Now.ToString();
            if (!string.IsNullOrEmpty(modelFileName))
                modelFileName = "- " + modelFileName; //Adds the DAE filename to the log file name
            else
                modelFileName = "(" + timeStamp + ")"; //Adds the time to the log file name if the DAE filename can't be found

            logFileName = "Log " + modelFileName + ".html"; //Creates a HTML file
            logFileName = logFileName.Replace("/", "-");
            logFileName = logFileName.Replace(":", "-");
            logFile = new StreamWriter(new FileStream(logFileName, FileMode.Create, FileAccess.ReadWrite)); // Creates a .html file for storing errors
            logFile.WriteLine("<span style=\"font-family: Kootenay; color: #000000;\">");
            logFile.WriteLine("<center><b>GD2 Collada Wizard's Log File<b /><center /><br />"); //Writes the title for the log file
            logFile.WriteLine("This log file was created at: " + System.DateTime.Now.ToLocalTime() + "</span><br />"); //Writes a line to the file also containing the date and time
            logFile.WriteLine("<span style=\"font-family: Kootenay; color: #FF0000;\">" + "Error messages are displayed in RED" + "</span><br />");
            logFile.WriteLine("<span style=\"font-family: Kootenay; color: #009900;\">" + "Successful messages are displayed in GREEN" + "</span><br />");
            logFile.WriteLine("<span style=\"font-family: Kootenay; color: #0000FF;\">" + "Unsupported messages are displayed in BLUE" + "</span><br /><hr />");
            logFile.Close(); //Closes the StreamWriter
            logInintialized = true; //Sets to true so only one log file is made
        }
        #endregion

        #region Error Messages
        /// <summary>
        /// Log an error message.
        /// </summary>
        /// <param name="errorInformation">Message to be written.</param>
        [Conditional("DEBUG")]
        static public void LogError(String errorInformation) //Method for adding error messages to the error log
        {
            errorInformation = System.Security.SecurityElement.Escape(errorInformation);
            if (!logInintialized) //If no log file has been made yet CreateErrorLogFile() will be called
                CreateErrorLogFile();
            logFile = new StreamWriter(new FileStream(logFileName, FileMode.Append, FileAccess.Write)); //Reopens the file so messages can be wrote onto the end of the file.
            logFile.WriteLine("<span style=\"font-family: Kootenay; color: #FF0000;\">"); //sets the font style and the sets the colour to red
            logFile.WriteLine(System.DateTime.Now.ToLocalTime() + "  -  " + errorInformation + "<hr />");
            logFile.Close(); //closes the stream writer
        }
        #endregion

        #region Successful Messages
        /// <summary>
        /// Log a successful import message.
        /// </summary>
        /// <param name="successfulInformation">Message to be written</param>
        [Conditional("DEBUG")]
        static public void LogSuccessful(String successfulInformation)
        {
            successfulInformation = System.Security.SecurityElement.Escape(successfulInformation);
            if (!logInintialized) //If no log file has been made yet CreateErrorLogFile() will be called
                CreateErrorLogFile();
            logFile = new StreamWriter(new FileStream(logFileName, FileMode.Append, FileAccess.Write)); //Reopens the file so messages can be wrote onto the end of the file.
            logFile.WriteLine("<span style=\"font-family: Kootenay; color: #009900;\">"); //Sets the font style and sets the colour to green
            logFile.WriteLine(System.DateTime.Now.ToLocalTime() + " - " + successfulInformation + "</span><hr />");
            logFile.Close(); //closes the stream writer
        }
        #endregion

        #region Unsupported Messages
        /// <summary>
        /// Log an unsupported feature message.
        /// </summary>
        /// <param name="unsupportedInformation">Message to be written</param>
        [Conditional("DEBUG")]
        static public void LogUnsupported(String unsupportedInformation)
        {
            unsupportedInformation = System.Security.SecurityElement.Escape(unsupportedInformation);
            if (!logInintialized) //If no log file has been made yet CreateErrorLogFile() will be called
                CreateErrorLogFile();
            logFile = new StreamWriter(new FileStream(logFileName, FileMode.Append, FileAccess.Write)); //Reopens the file so messages can be wrote onto the end of the file.
            logFile.WriteLine("<span style=\"font-family: Kootenay; color: #0000FF;\">"); //Sets the font style and sets the colour to blue
            logFile.WriteLine(System.DateTime.Now.ToLocalTime() + " - " + unsupportedInformation + "</span><hr />");
            logFile.Close(); //closes the stream writer
        }
        #endregion
    }
}
