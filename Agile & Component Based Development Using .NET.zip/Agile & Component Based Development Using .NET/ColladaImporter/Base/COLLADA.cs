﻿using System;
using System.Text;
using System.Collections.Generic;
using ColladaImporter.Base.Animation;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content.Pipeline.Graphics;
using Microsoft.Xna.Framework;
using System.IO;
using Microsoft.Xna.Framework.Content.Pipeline;
using ColladaImporter.Base.Animation.Skeleton;


namespace ColladaImporter.Base
{
    /// <summary>
    /// Solution to text import problem.
    /// http://code4k.blogspot.com/2010/08/import-and-export-3d-collada-files-with.html 
    /// </summary>
    public partial class COLLADA
    {
        private NodeContent rootNode;

        private Dictionary<string, BasicMaterialContent> materials = new Dictionary<string, BasicMaterialContent>();

        /// <summary>
        /// Parse the collada file into an XNA content node for processing by ModelProcessor.
        /// </summary>
        /// <param name="file"></param>
        /// <returns></returns>
        public NodeContent Build(FileInfo file)
        {
            rootNode = new NodeContent { Identity = new ContentIdentity(file.Name) };

            //Build up common items
            var textures = BuildTextures(file.Directory.FullName);
            this.materials = BuildMaterials(textures);

            BuildScene();
            var animations = AnimationBuild();
            string[] keys = new string[animations.Keys.Count];
            animations.Keys.CopyTo(keys, 0);

            AnimationContent aniC = new AnimationContent();

            int seconds = (int)animations[keys[0]][animations[keys[0]].Count - 1].time;
            int milliseconds =
                (int) ((animations[keys[0]][animations[keys[0]].Count - 1].time % 1) * 1000 + (animations[keys[0]][1].time % 1) * 1000);

            TimeSpan time = new TimeSpan(0, 0, 0, seconds, milliseconds);
            for (int i = 0; i < animations.Keys.Count; i++)
            {
                AnimationChannel aniCh = new AnimationChannel();
                for (int j = 0; j < animations[keys[i]].Count; j++)
                {
                    int secondsFrame = (int)animations[keys[i]][j].time;
                    int millisecondsFrame =
                        (int)((animations[keys[i]][j].time % 1) * 1000);
                    TimeSpan tFrame = new TimeSpan(0, 0, 0, secondsFrame, millisecondsFrame);
                    AnimationKeyframe aniK = new AnimationKeyframe(tFrame, animations[keys[i]][j].transform);
                    aniCh.Add(aniK);
                }
                aniC.Channels.Add(keys[i], aniCh);
                aniC.Duration = time;
            }

            rootNode.Animations.Add("animation", aniC);

            //Build up skeleton information first.
            //var visualScenes = BuildSkeleton();
            //foreach (var v in visualScenes.Values)
            //    foreach (var boneNodeInfo in v)
            //    {
            //        rootNode.Children.Add((NodeContent)boneNodeInfo);
            //    }

            ////build geometries, materials and image sources
            //var geometries = BuildGeometries(file.Directory.FullName);
            //foreach (var meshContent in geometries)
            //    rootNode.Children.Add(meshContent););

            return rootNode;
        }

        private Dictionary<String, List<AnimationInfo>> AnimationBuild()
        {
            var animationInfo = Utils.FindItemOfType<library_animations>(this.Items);
            if (animationInfo != null)
            {
                var ani = animationInfo.BuildAnimation();
                return ani;
            }
            return new Dictionary<String, List<AnimationInfo>>();

        }

        public void BuildScene()
        {
            //Find the visual scene name
            var instanceVisualScene = this.scene.instance_visual_scene;
            if (!string.IsNullOrEmpty(instanceVisualScene.url))
            {
                //Find the visual scene with the id url
                var scene = FindVisualScene(instanceVisualScene.url);
                //Find the node within scene that has instance_controller
                foreach (var node in scene.node)
                {
                    if (node.instance_controller != null && node.type == NodeType.NODE)
                    {
                        //Found the instance controller
                        var controllerId = node.instance_controller[0].url;
                        var controller = FindController(controllerId);
                        //TODO Check this array
                        //Build the skeleton
                        var skeletonId = node.instance_controller[0].skeleton[0];
                        var skeleton = BuildSkeleton(scene, skeletonId);
                        if (skeleton != null)
                        {
                            rootNode.Children.Add(skeleton);
                        }

                        //In the controller find the source url for the skin as the geometry
                        if (controller.Item.GetType() == typeof(skin))
                        {
                            var skin = (skin)controller.Item;
                            //skin.bind_shape_matrix
                            var geometryId = skin.source1;
                            //Build the geometry
                            MeshBuilder meshBuilder = MeshBuilder.StartMesh(geometryId);

                            //Build up vertex weights
                            if (skeleton != null)
                            {
                                var boneWeights = skin.Build( /*meshBuilder*/);
                                meshBuilder = BuildGeometry(meshBuilder, geometryId, boneWeights, skeleton);
                            }else
                                meshBuilder = BuildGeometry(meshBuilder, geometryId);
                            rootNode.Children.Add(meshBuilder.FinishMesh());
                        }
                        else
                        {
                            Logging.LogUnsupported("<morph> is not supported within <controller>");
                        }
                    }//If an instance controller is found
                }//For each node in instance visual scene
            }//If instance visual scene found.
        }

        /// <summary>
        /// Find a visual scene within library_visual_scenes.
        /// </summary>
        /// <param name="id">Id to find.</param>
        /// <returns>The scene or null if not found.</returns>
        private visual_scene FindVisualScene(string id)
        {
            if (id.StartsWith("#"))
                id = id.Remove(0, 1);

            var libraryVisualScenes = Utils.FindItemOfType<library_visual_scenes>(this.Items);
            if (libraryVisualScenes != null)
            {
                foreach (var visualScene in libraryVisualScenes.visual_scene)
                {
                    if (visualScene.id == id)
                        return visualScene;
                }
            }
            Logging.LogError("Cannot find visual_scene '" + id + "'");
            return null;
        }

        /// <summary>
        /// Find a controller within library_controllers.
        /// </summary>
        /// <param name="id">Id to find.</param>
        /// <returns>The controller or null if not found.</returns>
        private controller FindController(string id)
        {
            if (id.StartsWith("#"))
                id = id.Remove(0, 1);

            var libraryControllers = Utils.FindItemOfType<library_controllers>(this.Items);
            if (libraryControllers != null)
            {
                foreach (var controller in libraryControllers.controller)
                {
                    if (controller.id == id)
                        return controller;
                }
            }
            Logging.LogError("Cannot find controller '" + id + "'");
            return null;
        }

        /// <summary>
        /// Build a skeletal hierarchy with the given id within the scene.
        /// </summary>
        /// <param name="scene">Scene to find id in.</param>
        /// <param name="id">Name of the root sibling to start at.</param>
        /// <returns>Skeletal hierarchy or null if the root cannot be found.</returns>
        private static BoneNodeInfo BuildSkeleton(visual_scene scene, string id)
        {
            if (id.StartsWith("#"))
                id = id.Remove(0, 1);

            foreach (var node in scene.node)
            {
                if (node.id == id)
                {
                    //Build up the skeleton hierarchy
                    return node.Build();
                }
            }
            Logging.LogError("Cannot find skeleton node '" + id + "'");
            return null;
        }

        /// <summary>
        /// Build a mesh that is found within library_geometries with the name.
        /// </summary>
        /// <param name="id">Geomtry id.</param>
        /// <returns>MeshBuilder containing all supported channels present in the geometry sources or null if the geometry cannot be found.</returns>
        public MeshBuilder BuildGeometry(MeshBuilder meshBuilder, string id, BoneWeightCollection[] boneWeights = null, BoneNodeInfo skeleton = null)
        {
            if (id.StartsWith("#"))
                id = id.Remove(0, 1);

            var geometries = Utils.FindItemOfType<library_geometries>(this.Items);
            if (geometries != null)
            {
                foreach (var geo in geometries.geometry)
                {
                    if (geo.id == id)
                        return geo.Build(meshBuilder, materials, boneWeights,skeleton);
                }
            }
            
            Logging.LogError("Cannot find geometry '" + id + "'");
            return null;
        }

        ///// <summary>
        ///// Parse each geomtry to build up meshes.
        ///// </summary>
        //public MeshContent[] BuildGeometries(string directory)
        //{
        //    var textures = BuildTextures(directory);
        //    var materials = BuildMaterials(textures);
        //    var geometries = Utils.FindItemOfType<library_geometries>(this.Items);
        //    if (geometries != null)
        //    {
        //        return geometries.Build(materials);
        //    }
        //    return new MeshContent[0];
        //}

        /// <summary>
        /// Build up materials list.
        /// </summary>
        /// <param name="texContent"></param>
        /// <returns></returns>
        public Dictionary<string, BasicMaterialContent> BuildMaterials(Dictionary<string, ExternalReference<TextureContent>> texContent)
        {
            var materials = Utils.FindItemOfType<library_materials>(this.Items);
            if (materials != null)
            {
                var materialEffects = materials.BuildMaterials(texContent);
                return materialEffects;
            }


            //Return empty incase of error
            return new Dictionary<string, BasicMaterialContent>();
        }

        /// <summary>
        /// Build up textures list.
        /// </summary>
        /// <param name="directory"></param>
        /// <returns></returns>
        public Dictionary<string, ExternalReference<TextureContent>> BuildTextures(string directory)
        {
            var textures = Utils.FindItemOfType<library_images>(this.Items);
            if (textures != null)
            {
                var texContent = textures.GetTextures(directory);
                return texContent;
            }
            //Return an empty 1 incase of error
            return new Dictionary<string, ExternalReference<TextureContent>>();
        }

        /// <summary>
        /// Build up joint/node information.
        /// </summary>
        /// <returns></returns>
        public Dictionary<String, List<BoneNodeInfo>> BuildSkeleton()
        {
            var libraryVisualScenes = Utils.FindItemOfType<library_visual_scenes>(this.Items);
            if (libraryVisualScenes != null)
            {
                return libraryVisualScenes.Build();
            }
            //Return empty incase of error.
            return new Dictionary<string, List<BoneNodeInfo>>();
        }

        #region Helpers

        internal static string ConvertDoubleArrayToString(double[] values)
        {
            var sb = new StringBuilder();
            foreach (var v in values)
                sb.Append(v);
            return sb.ToString();
        }

        internal static double[] ConvertStringToDoubleArray(string value)
        {
            var values = value.Split(new string[] { " ", "\n" }, StringSplitOptions.RemoveEmptyEntries);
            var ret = new double[values.Length];
            for (int i = 0; i < values.Length; i++)
            {
                ret[i] = Double.Parse(values[i]);
            }
            return ret;
        }

        internal static string ConvertFloatArrayToString(float[] values)
        {
            var sb = new StringBuilder();
            foreach (var v in values)
                sb.Append(v);
            return sb.ToString();
        }

        internal static float[] ConvertStringToFloatArray(string value)
        {
            var values = value.Split(new string[] { " ", "\n" }, StringSplitOptions.RemoveEmptyEntries);
            var ret = new float[values.Length];
            for (int i = 0; i < values.Length; i++)
            {
                ret[i] = float.Parse(values[i]);
            }
            return ret;
        }

        internal static string ConvertBoolArrayToString(bool[] values)
        {
            var sb = new StringBuilder();
            foreach (var v in values)
                sb.Append(v);
            return sb.ToString();
        }

        internal static bool[] ConvertStringToBoolArray(string value)
        {
            var values = value.Split(new string[] { " ", "\n" }, StringSplitOptions.RemoveEmptyEntries);
            var ret = new bool[values.Length];
            for (int i = 0; i < values.Length; i++)
            {
                ret[i] = Boolean.Parse(values[i]);
            }
            return ret;
        }

        internal static string ConvertLongArrayToString(long[] values)
        {
            var sb = new StringBuilder();
            foreach (var v in values)
                sb.Append(v);
            return sb.ToString();
        }

        internal static long[] ConvertLongStringToArray(string value)
        {
            var values = value.Split(new string[] { " ", "\n" }, StringSplitOptions.RemoveEmptyEntries);
            var ret = new long[values.Length];
            for (int i = 0; i < values.Length; i++)
            {
                ret[i] = Int64.Parse(values[i]);
            }
            return ret;
        }

        internal static ulong[] ConvertStringToUlongArray(string value)
        {
            var values = value.Split(new string[] { " ", "\n" }, StringSplitOptions.RemoveEmptyEntries);
            var ret = new ulong[values.Length];
            for (int i = 0; i < values.Length; i++)
            {
                ret[i] = ulong.Parse(values[i]);
            }
            return ret;
        }

        internal static string ConvertStringArrayToString(string[] values)
        {
            var sb = new StringBuilder();
            foreach (var v in values)
                sb.Append(v);
            return sb.ToString();
        }

        internal static string[] ConvertStringToStringArray(string value)
        {
            //TODO check this is correct
            var values = value.Split(new string[] { " ", "\n" }, StringSplitOptions.RemoveEmptyEntries);
            return values;
        }

        #endregion
    }
}
