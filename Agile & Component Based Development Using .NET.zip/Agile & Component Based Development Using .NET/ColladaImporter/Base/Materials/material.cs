﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Content.Pipeline;
using Microsoft.Xna.Framework.Content.Pipeline.Graphics;
using Microsoft.Xna.Framework;


namespace ColladaImporter.Base
{
    /// <summary>
    /// Checks if there are any instance_effects in materials
    /// </summary>
    public partial class material
    {
        public BasicMaterialContent Build(Dictionary<string, ExternalReference<TextureContent>> texContent)
        {
            var instance = this.instance_effect;
            if (instance != null)
            {
                Logging.LogSuccessful("Found an instance_effect in library_materials.");
                return instance.Build(texContent);
            }
            else
            {
                Logging.LogError("No instance_effects found in library_materials.");
                return null;
            }
        }
    }
}
