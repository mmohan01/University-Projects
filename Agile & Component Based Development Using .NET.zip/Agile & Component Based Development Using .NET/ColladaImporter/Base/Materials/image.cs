﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Microsoft.Xna.Framework.Content.Pipeline;
using Microsoft.Xna.Framework.Content.Pipeline.Graphics;
using Microsoft.Xna.Framework;

namespace ColladaImporter.Base
{
    public partial class image
    {
        /// <summary>
        /// Reads the file path of the texture from the Collada file and grabs the texture file from the given path, assigning it to a texture reference var.
        /// </summary>
        /// <param name="name">Is needed to create the full path for file name</param>
        /// <returns>A texture reference var containing the found texture or a null texture reference if the datatype is not supported</returns>
        public ExternalReference<TextureContent> Retrieve(string name)
        {
            string textureFilename = "";
            
            //checks the data stucture of Item
            if (this.Item.GetType() == typeof(string))
            {
                Logging.LogSuccessful("String data structure for texture path found.");
                //gets the value of the Item
                textureFilename = this.Item.ToString();
            }
            else if (this.Item.GetType() == typeof(byte[]))
            {
                Logging.LogUnsupported("Byte Arrays are not supported in this model.");
                return null;
            }
            else
            {
                Logging.LogUnsupported("This type of data structure is not supported.");
                return null;  
            }

            //removes the preceeding '.' character from the retrieved string
            if (textureFilename.StartsWith("."))
                textureFilename = textureFilename.TrimStart('.');

            if (textureFilename.StartsWith("/"))
                textureFilename = textureFilename.TrimStart('/');

            //replaces any forward slashes with a backslash
            textureFilename = textureFilename.Replace("/", "\\");
            
            //a check to see if the filepth exists
            var path = Path.Combine(name, textureFilename);
            FileInfo t = new FileInfo(path);

            if (t.Directory.Exists)
            {
                Logging.LogSuccessful("Texture was found and filepath exists.");
                return new ExternalReference<TextureContent>(path);
            }
            Logging.LogError("Texture was found but filepath does not exist.");
            return null;

        }
    }
}
