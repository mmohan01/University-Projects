﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Content.Pipeline;
using Microsoft.Xna.Framework.Content.Pipeline.Graphics;
using Microsoft.Xna.Framework;

namespace ColladaImporter.Base
{
    public partial class library_images
    {
        /// <summary>
        /// For every instance of an image tag in the library_images section of the collada file, it calls a method to try and retrieve the given image/texture
        /// </summary>
        /// <param name="name">Is needed to create the full file path name. It is not used in this class, it is only brought in to be transferred to other classes</param>
        /// <returns>A dictionary of BasicMaterialContent containing the found textures. If there are no textures, it remains empty</returns>
        public Dictionary<string, ExternalReference<TextureContent>> GetTextures(string name)
        {
            Dictionary<string, ExternalReference<TextureContent>> textures = new Dictionary<string, ExternalReference<TextureContent>>();

            if (this.image != null)
            {
                foreach (var img in this.image)
                {
                    Logging.LogSuccessful("Found an instance of texture in library_images.");
                    var myTexture = img.Retrieve(name);
                    //if a texture is found it is added to the dictionary
                    if (myTexture != null)
                    {
                        textures.Add(img.id, myTexture);
                    }
                }
            }
            else
            {
                Logging.LogError("No instances of textures found in library_images.");
            }

            return textures;

        }
    }
}
