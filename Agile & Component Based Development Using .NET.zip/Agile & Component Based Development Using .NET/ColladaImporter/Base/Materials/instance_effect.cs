﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Content.Pipeline;
using Microsoft.Xna.Framework.Content.Pipeline.Graphics;
using Microsoft.Xna.Framework;

namespace ColladaImporter.Base
{
    /// <summary>
    /// Checks if there are any setparams in instance_effects
    /// </summary>
    public partial class instance_effect
    {
        public BasicMaterialContent Build(Dictionary<string, ExternalReference<TextureContent>> texContent)
        {
            BasicMaterialContent matEffects = new BasicMaterialContent();

            if (this.setparam != null)
            {
                foreach (var setparam in this.setparam) //Goes through every setparam in the library_materials section of the DAE file and posts a successful message to the DAE file
                {
                    Logging.LogSuccessful("Found an instance of setparam.");
                    setparam.Build(ref matEffects, texContent);
                }
            }
            else
            {
                Logging.LogError("No instances of setparam were found.");
            }

            return matEffects;
        }
    }

}
