﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Content.Pipeline;
using Microsoft.Xna.Framework.Content.Pipeline.Graphics;
using Microsoft.Xna.Framework;

namespace ColladaImporter.Base
{
    /// <summary>
    /// Checks if there are any materials in the library_materials
    /// </summary>
    public partial class library_materials
    {
        public Dictionary<string, BasicMaterialContent> BuildMaterials(Dictionary<string, ExternalReference<TextureContent>> texContent)
        {
            Dictionary<string, BasicMaterialContent> materials = new Dictionary<string, BasicMaterialContent>(); //Creates a dictionary to store the found data

            if (this.material != null) //Gets called if material is found in the DAE file
            {
                Logging.LogSuccessful("Found an instance of material in library_materials."); //Writes a successful message to the log file
                foreach (var mat in this.material)
                {
                    var matEffects = mat.Build(texContent);
                    if (matEffects != null)
                        materials.Add(mat.id, matEffects); //Adds to the dictionary
                }
            }
            else
            {
                Logging.LogError("No instances of materials found in library_materials."); //Writes an error message to the log file
            }
            return materials;
        }

    }
}
