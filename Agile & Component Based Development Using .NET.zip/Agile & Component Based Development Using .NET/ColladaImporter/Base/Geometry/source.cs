﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

namespace ColladaImporter.Base
{
    public partial class source
    {
        /// <summary>
        /// Build up a source of valid values.
        /// </summary>
        /// <returns>Array of values of the correct type or null if there was an error.</returns>
        public BuiltSource Build()
        {
            //Parse technique common
            if (this.technique_common != null)
            {
                var accessor = ParseAccessor(this.technique_common.accessor);
                if (accessor != null)
                {
                    //TODO Check accessor name == data array name???

                    if (Item.GetType() == typeof(IDREF_array))
                        Logging.LogUnsupported("IDREF_array was not imported as it's not supported within <source>.");
                    else if (Item.GetType() == typeof(Name_array))
                    {
                        var nameArray = (Name_array)Item;
                        return new BuiltSource(nameArray.Values, BuiltSource.ValueType.Name);
                    }
                    else if (Item.GetType() == typeof(bool_array))
                        Logging.LogUnsupported("Bool_array was not imported as it's not supported within <source>.");
                    else if (Item.GetType() == typeof(float_array))
                    {
                        var floats = (float_array)Item;
                        switch (this.technique_common.accessor.stride)
                        {
                            case 1:
                                return new BuiltSource(floats.Values, BuiltSource.ValueType.FloatArray);
                            case 2:
                                List<Vector2> vector2s = new List<Vector2>();
                                for (ulong i = 0; i < floats.count; i += this.technique_common.accessor.stride)
                                {
                                    //Check that the param exists for each item in the stride
                                    var vector2 = new Vector2(
                                        (accessor.Item2[0] ? floats.Values[i] : 0),
                                        (accessor.Item2[1] ? floats.Values[i + 1] : 0)
                                        );
                                    vector2s.Add(vector2);
                                }

                                return new BuiltSource(vector2s.ToArray(), BuiltSource.ValueType.Vector2);
                            case 3:
                                List<Vector3> vector3s = new List<Vector3>();
                                for (ulong i = 0; i < floats.count; i += this.technique_common.accessor.stride)
                                {
                                    var vector3 = new Vector3(
                                        (accessor.Item2[0] ? floats.Values[i] : 0),
                                        (accessor.Item2[1] ? floats.Values[i + 1] : 0),
                                        (accessor.Item2[2] ? floats.Values[i + 2] : 0)
                                        );
                                    vector3s.Add(vector3);
                                }
                                return new BuiltSource(vector3s.ToArray(), BuiltSource.ValueType.Vector3);
                            case 4:
                                List<Vector4> vector4s = new List<Vector4>();
                                for (ulong i = 0; i < floats.count; i += this.technique_common.accessor.stride)
                                {
                                    var vector4 = new Vector4(
                                        (accessor.Item2[0] ? floats.Values[i] : 0),
                                        (accessor.Item2[1] ? floats.Values[i + 1] : 0),
                                        (accessor.Item2[2] ? floats.Values[i + 2] : 0),
                                        (accessor.Item2[3] ? floats.Values[i + 3] : 0)
                                        );
                                    vector4s.Add(vector4);
                                }
                                return new BuiltSource(vector4s.ToArray(), BuiltSource.ValueType.Vector4);
                        }
                    }
                    else if (Item.GetType() == typeof(int_array))
                        Logging.LogUnsupported("int_array was not imported as it's not supported within <source>.");
                }//IF valid accessor
            }//IF technique_common
            return null;
        }

        /// <summary>
        /// Checks for a valid accessor and checks for any params to skip.
        /// </summary>
        /// <param name="accessor"></param>
        /// <returns>Null if the accessor is invalid or a Tupple<string, bool[]>.</returns>
        private Tuple<string, bool[]> ParseAccessor(accessor accessor)
        {
            var paramNameExists = new bool[accessor.stride];

            //Check missing param names
            for (int i = 0; i < accessor.param.Length; i++)
            {
                paramNameExists[i] = !string.IsNullOrEmpty(accessor.param[i].name);
            }

            //Get source name
            return Tuple.Create(accessor.source, paramNameExists);
        }
    }

    /// <summary>
    /// Parsed source information.
    /// </summary>
    public class BuiltSource
    {
        public enum ValueType
        {
            FloatArray,
            Vector2,
            Vector3,
            Vector4,

            Matrix,

            Id,
            Name
        }

        #region Properties

        /// <summary>
        /// The source values.
        /// </summary>
        public object Values { get; private set; }

        /// <summary>
        /// The type of array contained within the source
        /// </summary>
        public ValueType ValuesType { get; set; }

        #endregion

        public BuiltSource(object values, ValueType type)
        {
            Values = values;
            ValuesType = type;
        }
    }
}
