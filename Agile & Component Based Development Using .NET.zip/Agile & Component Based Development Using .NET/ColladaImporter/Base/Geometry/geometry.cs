﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ColladaImporter.Base.Animation.Skeleton;
using Microsoft.Xna.Framework.Content.Pipeline.Graphics;
using Microsoft.Xna.Framework;

namespace ColladaImporter.Base
{
    public partial class geometry
    {
        /// <summary>
        /// Builds a new mesh based on the verticies
        /// </summary>
        /// <returns></returns>
        public MeshBuilder Build(MeshBuilder meshBuilder, Dictionary<string, BasicMaterialContent> textures, BoneWeightCollection[] boneWeights = null, BoneNodeInfo skeleton = null )
        {
            //Get the type of the mesh
            if (this.Item.GetType() == typeof(convex_mesh))
            {
                Logging.LogUnsupported("Convex mesh was not imported as it is not supported in this model.");
                return null;
            }

            else if (this.Item.GetType() == typeof(spline))
            {
                Logging.LogUnsupported("Spline was not imported as it is not supported in this model.");
                return null;
            }

            else if (this.Item.GetType() == typeof(mesh))
            {
                var mesh = (mesh)this.Item;
                Logging.LogSuccessful("Mesh was successfully imported.");
                return mesh.Build(meshBuilder, this.id, textures, boneWeights,skeleton);
            }
            else
                Logging.LogError("No mesh was found in the .DAE file.");

            return null;
        }
    }
}
