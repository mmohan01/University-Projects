﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ColladaImporter.Base.Geometry
{
    //creates the bone class to store data for each bone in the skeleton heirarchy
    class Bone
    {
        #region Bone Properties
        private int ID;
        private int parentID;
        //bind pose matrix
        private matrix jointMatrix;
        private matrix inverseBindMatrix;
        private matrix worldMatrix;
        //this is the matrix used for calculations
        private matrix skinningMatrix;
        private int childCount;
        private List<int> children;
        private int numberOfKeyFrames;
        private Keyframe keyframes;
        #endregion
    }
}