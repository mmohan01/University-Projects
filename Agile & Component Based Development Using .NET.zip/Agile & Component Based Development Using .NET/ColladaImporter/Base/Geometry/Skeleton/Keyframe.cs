﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ColladaImporter.Base.Geometry
{
    //createsa a Keyframe class to store data for animation
    class Keyframe
    {
        #region Keyframe Properties
        private float time;
        private matrix transform;
        #endregion
    }
}
