﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ColladaImporter.Base.Animation.Skeleton;
using Microsoft.Xna.Framework.Content.Pipeline.Graphics;
using Microsoft.Xna.Framework;


namespace ColladaImporter.Base
{
    public partial class mesh
    {
        #region Fields

        private MeshBuilder meshBuilder;
        private Dictionary<string, BuiltSource> sources;

        private Vector3[] parsedVertices;
        private Vector3[] textureCoords;
        private Vector2[] uvCoords;
        private Vector3[] normals;
        public bool[] taco = { true, true };
        public int bbz = 0;

        // Indices of vertex channels for the current mesh
        private int textureCoordinateDataIndex;
        private int normalDataIndex;

        #endregion

        private BoneWeightCollection[] boneWeights;
        private BoneNodeInfo skeleton;
        /// <summary>
        /// Build a geometry mesh.
        /// </summary>
        /// <param name="name">Mesh name.</param>
        /// <returns></returns>
        public MeshBuilder Build(MeshBuilder meshBuilder, string name, Dictionary<string, BasicMaterialContent> textures, BoneWeightCollection[] boneWeights = null,BoneNodeInfo skeleton = null)
        {
            this.boneWeights = boneWeights;
            this.skeleton = skeleton;
            #region Setup

            this.meshBuilder = meshBuilder;
            this.meshBuilder.SwapWindingOrder = true;

            #endregion

            #region Create mesh sources dictionary

            sources = new Dictionary<string, BuiltSource>();
            foreach (var src in this.source)
            {
                var values = src.Build();
                if (values != null)
                    sources.Add(src.id, values);
            }

            #endregion

            BuildVertices();

            #region Build correct mesh type (triangles)

            foreach (object item in this.Items)
            {
                if (item.GetType() == typeof(lines))
                {
                    Logging.LogUnsupported("Lines were not imported as it is not supported in this model.");
                    return null;
                }
                else if (item.GetType() == typeof(linestrips))
                {
                    Logging.LogUnsupported("Line strips were not imported as it is not supported in this model.");
                    return null;
                }
                else if (item.GetType() == typeof(polygons))
                {
                    Logging.LogUnsupported("Polygons were not imported as it is not supported in this model.");
                    return null;
                }
                else if (item.GetType() == typeof(polylist))
                {
                    Logging.LogUnsupported("Polylist was not imported as it is not supported in this model.");
                    return null;
                }
                else if (item.GetType() == typeof(triangles))
                {
                    var triangles = (triangles)item;
                    if (!string.IsNullOrEmpty(triangles.material))
                    {
                        BasicMaterialContent materialContent = null;
                        if (textures.TryGetValue(triangles.material, out materialContent))
                            meshBuilder.SetMaterial(materialContent);
                        else
                            Logging.LogError("Could not find material '" + triangles.material + "'");
                    }
                    BuildTriangles(triangles);

                }
                else if (item.GetType() == typeof(trifans))
                {
                    Logging.LogUnsupported("Trifans were not imported as it is not supported in this model.");
                    return null;
                }
                else if (item.GetType() == typeof(tristrips))
                {
                    Logging.LogUnsupported("Tristrips were not imported as it is not supported in this model.");
                    return null;
                }
            }

            #endregion

            return meshBuilder;
        }

        /// <summary>
        /// Create a source for the vertices
        /// </summary>
        private void BuildVertices()
        {
            foreach (var input in this.vertices.input)
            {
                switch (input.semantic)
                {
                    case "POSITION":
                        BuiltSource src = GetSource(input.source);
                        if (src != null)
                            //Add the source again with the vertices id
                            sources.Add(this.vertices.id, src);
                        else
                            Logging.LogError("There is no source of that name in the file.");
                        break;
                    case "NORMAL":
                        Logging.LogUnsupported("Normals were not imported as they're not supported within <verticies>.");
                        break;
                    case "TEXCOORD":
                        Logging.LogUnsupported("Texcoords were not imported as they're not supported within <verticies>.");
                        break;
                    case "COLOR":
                        Logging.LogUnsupported("Color was not imported as it's not supported within <verticies>.");
                        break;
                    case "TANGENT":
                        Logging.LogUnsupported("Tangents were not imported as they're not supported within <verticies>.");
                        break;
                    case "BINORMAL":
                        Logging.LogUnsupported("Binormals were not imported as they're not supported within <verticies>.");
                        break;
                    case "UV":
                        Logging.LogUnsupported("UV was not imported as it's not supported within <verticies>.");
                        break;
                }
            }
        }

        private List<Matrix> bindPose = new List<Matrix>();
        private List<Matrix> inverseBindPose = new List<Matrix>();
        private Dictionary<string, int> nameIndex = new Dictionary<string, int>();
        private int currentIndex = 0;

        private void BuildBindPose(BoneNodeInfo bone)
        {
            bindPose.Add(bone.AbsoluteTransform);
            inverseBindPose.Add(Matrix.Invert(bone.AbsoluteTransform));
            nameIndex.Add(bone.Name, currentIndex);
            currentIndex++;
            if(bone.Children != null)
            {
                foreach (var child in bone.Children)
                {
                    BuildBindPose((BoneNodeInfo)child);
                }
            }
        }

        /// <summary>
        /// Build a triangle mesh.
        /// </summary>
        /// <param name="triangles"></param>
        private void BuildTriangles(triangles triangles)
        {
            var inputs = ParsedInput.ParseInputs(triangles.input);

            //Find the number of unique offsets in the input list
            long uniqueInputPositions = ParsedInput.UniqueInputPositions(inputs);

            //Get the indicies
            var p = COLLADA.ConvertStringToUlongArray(triangles.p);

            #region Create channels

            int boneWeightChannel = -1;
            if (boneWeights != null)
                boneWeightChannel = meshBuilder.CreateVertexChannel<BoneWeightCollection>(VertexChannelNames.Weights(0));

            foreach (var input in inputs)
            {
                long arrayIndex = 0 + (long)input.Offset;
                var pValue = p[arrayIndex];

                var src = GetSource(input.SourceName);
                //Add the vertices to the source channel of mesh builder
                if (input.Type == ParsedInput.InputType.Vertex)
                {
                    this.parsedVertices = (Vector3[])src.Values;
                }
                else if (input.Type == ParsedInput.InputType.Normal)
                {
                    this.normals = (Vector3[])src.Values;
                    normalDataIndex = meshBuilder.CreateVertexChannel<Vector3>(VertexChannelNames.Normal(0));
                    meshBuilder.SetVertexChannelData(normalDataIndex, normals[pValue]);
                }
                else if (input.Type == ParsedInput.InputType.TextCoord)
                {
                    //Texture can be vector2 or vector3
                    if (src.ValuesType == BuiltSource.ValueType.Vector2)
                    {
                        this.uvCoords = (Vector2[])src.Values;
                        textureCoordinateDataIndex = meshBuilder.CreateVertexChannel<Vector2>(VertexChannelNames.TextureCoordinate(0));
                        meshBuilder.SetVertexChannelData(textureCoordinateDataIndex, uvCoords[pValue]);
                    }
                    else
                    {
                        this.textureCoords = (Vector3[])src.Values;
                        textureCoordinateDataIndex = meshBuilder.CreateVertexChannel<Vector3>(VertexChannelNames.TextureCoordinate(0));
                        Vector3 newV = new Vector3(textureCoords[pValue].X, 1 - textureCoords[pValue].Y, textureCoords[pValue].Z);
                        meshBuilder.SetVertexChannelData(textureCoordinateDataIndex, newV);
                    }
                }
            }

            #endregion

            #region Add data to channels

            

            #region Fix vertex positions & weights
         //   System.Diagnostics.Debugger.Launch();
            if (boneWeights != null)
            {
                BuildBindPose(this.skeleton);
                for (int i = 0; i < boneWeights.Length; i++)
                {
                    Vector3 outv = Vector3.Zero;
                    for (int j = 0; j < boneWeights[i].Count; j++)
                    {
                        int index = nameIndex[boneWeights[i][j].BoneName];
                        Matrix BSM = Matrix.Identity;

                        outv +=
                            Vector3.Transform((Vector3.Transform(parsedVertices[i], BSM)), (inverseBindPose[index]) * bindPose[index]) *boneWeights[i][j].Weight;
                       
                    }
                    parsedVertices[i] = outv;
                }
            }

            #endregion


            var positions = new List<int>();
            for (long i = 0; i < parsedVertices.LongLength; i++)
            {
                positions.Add(meshBuilder.CreatePosition(parsedVertices[i]));
            }
            int k = 0;

            for (long i = 0; i < p.LongLength; i += (long)uniqueInputPositions)
            {
                //if (boneWeightChannel != -1 && k < parsedVertices.LongLength)
                //{
                //    meshBuilder.SetVertexChannelData(boneWeightChannel, boneWeights[k]);
                //    k++;
                //}
                //Create triangles based on vertex ofset.);
                foreach (var input in inputs)
                {
                    if (input.Type == ParsedInput.InputType.Unsuported)
                        continue;

                    long arrayIndex = i + (long)input.Offset;
                    var pValue = p[arrayIndex];
                    switch (input.Type)
                    {
                        case ParsedInput.InputType.Vertex:
                            if(boneWeights != null)
                                meshBuilder.SetVertexChannelData(boneWeightChannel, boneWeights[(int)pValue]);
                            meshBuilder.AddTriangleVertex((int)pValue);
                            break;
                        case ParsedInput.InputType.Normal:
                            //Emmett's hack to get the normals to work :P
                            if (p.Length - arrayIndex > uniqueInputPositions)
                            {
                                arrayIndex = i + uniqueInputPositions + (long)input.Offset;
                                pValue = p[arrayIndex];
                                meshBuilder.SetVertexChannelData(normalDataIndex, normals[pValue]);
                            }
                            break;
                        case ParsedInput.InputType.TextCoord:
                            if (textureCoords != null)
                            {
                                if (p.Length - arrayIndex > uniqueInputPositions)
                                {
                                    arrayIndex = i + uniqueInputPositions + (long)input.Offset;
                                    pValue = p[arrayIndex];
                                    Vector3 newV = new Vector3(textureCoords[pValue].X, 1 - textureCoords[pValue].Y,
                                                               textureCoords[pValue].Z);
                                    meshBuilder.SetVertexChannelData(textureCoordinateDataIndex, newV);
                                }
                            }
                            else if (uvCoords != null)
                                if (p.Length - arrayIndex > uniqueInputPositions)
                                {
                                    arrayIndex = i + uniqueInputPositions + (long)input.Offset;
                                    pValue = p[arrayIndex];
                                    meshBuilder.SetVertexChannelData(textureCoordinateDataIndex, uvCoords[pValue]);
                                }
                            break;
                    }
                }
            }
            #endregion
        }

        /// <summary>
        /// Get the input source for the name.
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        private BuiltSource GetSource(string name)
        {
            if (name.StartsWith("#"))
                name = name.Replace("#", "");

            BuiltSource ret = null;
            if (sources.TryGetValue(name, out ret))
                return ret;
            return null;
        }
    }
}
