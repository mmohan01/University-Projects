﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content.Pipeline.Processors;
using Microsoft.Xna.Framework.Content.Pipeline.Graphics;
using Microsoft.Xna.Framework.Content.Pipeline;

namespace ColladaImporter.Base
{
    public partial class library_geometries
    {
        //public MeshContent[] Build(Dictionary<string, BasicMaterialContent> textures)
        //{
        //    //rootNode = new NodeContent();
        //    //rootNode.Identity = new ContentIdentity(/*filename*/ this.id); 
        //    var geometries = new List<MeshContent>();
        //    foreach (var geo in this.geometry)
        //    {
        //        var meshContent = geo.Build(textures);
        //        if (meshContent != null)
        //            geometries.Add(meshContent);
        //    }

        //    return geometries.ToArray();
        //}
    }
}
