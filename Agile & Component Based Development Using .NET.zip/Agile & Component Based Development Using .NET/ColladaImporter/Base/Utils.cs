﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ColladaImporter.Base
{
    public static class Utils
    {
        /// <summary>
        /// Find a top level library object.
        /// </summary>
        /// <typeparam name="T">Type of library to find.</typeparam>
        /// <param name="objs">Array to search for type T.</param>
        /// <returns>The library instance or null if not found.</returns>
        public static T FindItemOfType<T>(object[] objs)
            where T : class
        {
            for (int i = 0; i < objs.Length; i++)
                if (objs[i].GetType() == typeof(T))
                {
                    return (T)objs[i];
                }
            return null;
        }
    }
}
