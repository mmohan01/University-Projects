﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Content.Pipeline.Graphics;

namespace ColladaImporter.Base
{
    public partial class skin
    {
        private Dictionary<string, BuiltSource> sources;
        private BuiltSource inverseBindMatrix;
        private BuiltSource joint;

        private string[] boneNames;
        private float[] boneWeights;

        /// <summary>
        /// Add the vertex weights into the mesh.
        /// </summary>
        /// <param name="meshBuilder">A mesh that already contains its geomtry etc.</param>
        /// <returns>The mesh builder containing the weights channel.</returns>
        public BoneWeightCollection[] Build(/*MeshBuilder meshBuilder*/)
        {
            //Create built sources to use
            sources = new Dictionary<string, BuiltSource>();
            foreach (var src in this.source)
            {
                var values = src.Build();
                if (values != null)
                    sources.Add(src.id, values);
            };

            //Read <joints> to create the extra inputs
            BuildJoints();

            //Read vertex_weights
            return BuildVertexWeights(/*meshBuilder*/);
        }

        private void BuildJoints()
        {
            foreach (var input in this.joints.input)
            {
                switch (input.semantic)
                {
                    case "JOINT":
                        joint = GetSource(input.source);
                        if (joint == null)
                            Logging.LogError("Could not find source '" + input.source + "' for <joints> JOINT");
                        break;
                    case "INV_BIND_MATRIX":
                        inverseBindMatrix = GetSource(input.source);
                        if (joint == null)
                            Logging.LogError("Could not find source '" + input.source + "' for <joints> INV_BIND_MATRIX");
                        break;
                    default:
                        Logging.LogUnsupported(input.semantic + " was not imported as it's not supported within <joints>.");
                        break;
                }
            }
        }

        private BoneWeightCollection[] BuildVertexWeights(/*MeshBuilder meshBuilder*/)
        {
            ParsedInput[] inputs = ParsedInput.ParseInputs(this.vertex_weights.input);
            //Find the number of unique offsets in the input list
            long uniqueInputPositions = ParsedInput.UniqueInputPositions(inputs);

            //Get the indicies
            var v = COLLADA.ConvertStringToUlongArray(this.vertex_weights.v);
            var vcount = COLLADA.ConvertStringToUlongArray(this.vertex_weights.vcount);

            var ret = new List<BoneWeightCollection>();

            foreach (var input in inputs)
            {
                var src = GetSource(input.SourceName);
                switch (src.ValuesType)
                {
                    case BuiltSource.ValueType.Name:
                        boneNames = (string[])src.Values;
                        break;
                    case BuiltSource.ValueType.FloatArray:
                        boneWeights = (float[])src.Values;
                        break;
                }
            }

            //And each value from the <vcount> is the number of Joints affecting that particular vertex, 
            //on which we are currently iterating. So we iterate nested for that specific value in the <vcount> (number of joints time) 
            //and read pairs of indices from <v> (Here I assume we have only two <input> nodes in <vertex_weight>).)));
            ulong t = 0;
            for (ulong i = 0; i < vertex_weights.count; i++)
            {
                var weights = new BoneWeightCollection();
                //number of Joints affecting this vertex
                var count = vcount[i];
                //t += count*(ulong) uniqueInputPositions;
                //Read count times into v
                for (ulong j = 0; j < count * (ulong)uniqueInputPositions; j += (ulong)uniqueInputPositions)
                {
                    string boneName = string.Empty;
                    float boneWeight = 0;
                    //Read through the inputs
                    foreach (var input in inputs)
                    {
                        if (input.Type == ParsedInput.InputType.Unsuported)
                            continue;

                        ulong arrayIndex = t;
                        var vValue = v[arrayIndex];
                        switch (input.Type)
                        {
                            case ParsedInput.InputType.Joint:
                                boneName = boneNames[vValue];
                                break;
                            case ParsedInput.InputType.Weight:
                                boneWeight = boneWeights[vValue];
                                break;
                        }
                        t++;
                    }
                    weights.Add(new BoneWeight(boneName, boneWeight));
                }
                //weights.NormalizeWeights(4);
                ret.Add(weights);
            }

            //return meshBuilder;
            return ret.ToArray();
        }

        /// <summary>
        /// Get the input source for the name.
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        private BuiltSource GetSource(string name)
        {
            if (name.StartsWith("#"))
                name = name.Replace("#", "");

            BuiltSource ret = null;
            if (sources.TryGetValue(name, out ret))
                return ret;
            return null;
        }
    }
}
