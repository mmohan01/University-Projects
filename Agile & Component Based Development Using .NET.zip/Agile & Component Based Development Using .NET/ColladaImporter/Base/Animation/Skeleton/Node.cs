﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ColladaImporter.Base.Animation.Skeleton;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content.Pipeline.Graphics;


namespace ColladaImporter.Base
{
    public partial class node
    {

        public BoneNodeInfo Build()
        {
            //CHECK INSTANCE THING
            if (this.Items != null)
            {
                matrix transformMatrix = Utils.FindItemOfType<matrix>(this.Items);

                foreach (object item in this.Items)
                {
                    if (item.GetType() == typeof (lookat))
                    {
                        Logging.LogUnsupported("Lookats were not imported as it is not supported in this model.");
                        return null;
                    }
                    else if (item.GetType() == typeof (rotate))
                    {
                        Logging.LogUnsupported("Rotations were not imported as it is not supported in this model.");
                        return null;
                    }
                    else if (item.GetType() == typeof (skew))
                    {
                        Logging.LogUnsupported("Skews were not imported as it is not supported in this model.");
                        return null;
                    }
                    else if (item.GetType() == typeof (matrix))
                    {
                        //variable used to transfer the collada matrix to an xna matrix
                        Matrix mat = new Matrix();
                        
                        //transfering the collada matrix to the xna matrix
                        mat.M11 = ((float) transformMatrix.Values[0]);
                        mat.M21 = ((float) transformMatrix.Values[1]);
                        mat.M31 = ((float) transformMatrix.Values[2]);
                        mat.M41 = ((float) transformMatrix.Values[3]);
                        mat.M12 = ((float) transformMatrix.Values[4]);
                        mat.M22 = ((float) transformMatrix.Values[5]);
                        mat.M32 = ((float) transformMatrix.Values[6]);
                        mat.M42 = ((float) transformMatrix.Values[7]);
                        mat.M13 = ((float) transformMatrix.Values[8]);
                        mat.M23 = ((float) transformMatrix.Values[9]);
                        mat.M33 = ((float) transformMatrix.Values[10]);
                        mat.M43 = ((float) transformMatrix.Values[11]);
                        mat.M14 = ((float) transformMatrix.Values[12]);
                        mat.M24 = ((float) transformMatrix.Values[13]);
                        mat.M34 = ((float) transformMatrix.Values[14]);
                        mat.M44 = ((float) transformMatrix.Values[15]);

                        //sets the information of each node
                        var joint = new BoneNodeInfo(this.sid, BoneType.Joint, mat);

                        //looks at each node in the hierarchy and sets their child and parent nodes
                        if (this.node1 != null)
                        {
                            foreach (var node in this.node1)
                            {
                                var built = node.Build();
                                if (built != null)
                                {
                                    joint.Children.Add(built);
                                }
                            }
                        }
                        return joint;
                    }

                    else if (item.GetType() == typeof (TargetableFloat3))
                    {
                        Logging.LogUnsupported("Scales and translations were not imported as it is not supported in this model.");
                        return null;
                    }
                }
            }

            return null;
            //firstly checks if their is a valid matrix
            //if there isn't we get an error to the log file
            //if the data is valid they get assigned to an xna matrix

        }
    }
}
