﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ColladaImporter.Base.Animation.Skeleton;
using Microsoft.Xna.Framework;

namespace ColladaImporter.Base
{
    public class AnimationData
    {
        private Keyframe Frame { get; set; }
        public int NumberOfFrames { get; set; } 
        public Matrix TransformInput { get; set; }
        public Matrix TransformOutput { get; set; }
        public BoneNodeInfo StaticInfo { get; set; }

        public AnimationData(Keyframe frame, int numberOfFrames, Matrix transformInput, Matrix transformOutput, BoneNodeInfo staticInfo)
        {
            Frame = frame;
            NumberOfFrames = numberOfFrames;
            TransformInput = transformInput;
            TransformOutput = transformOutput;
            StaticInfo = staticInfo;
        } 
    }
}
*/