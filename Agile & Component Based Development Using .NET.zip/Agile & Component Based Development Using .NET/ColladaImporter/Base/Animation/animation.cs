﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ColladaImporter.Base.Animation;
using Microsoft.Xna.Framework;

namespace ColladaImporter.Base
{
    /// <summary>
    /// Checks if there are any instances of item in the animation partial class in the collada schema
    /// </summary>
    public partial class animation
    {
        public List<AnimationInfo> BuildAnimation()
        {
            //Creates lists to store the animation information
            List<List<AnimationInfo>> aniList = new List<List<AnimationInfo>>();
            List<AnimationInfo> returnedList = new List<AnimationInfo>();

            //Goes through each of the different items in the schema and either 
            foreach (object item in this.Items)
            {
                if (item.GetType() == typeof(animation))
                {
                    Logging.LogUnsupported("Animations were not imported as it is not supported in this model."); //Writes an unsupported message to the log file
                }
                else if (item.GetType() == typeof(channel))
                {
                    Logging.LogUnsupported("Channels were not imported as it is not supported in this model.");
                }
                else if (item.GetType() == typeof(sampler))
                {
                    Logging.LogUnsupported("Samplers were not imported as it is not supported in this model.");
                }
                else if (item.GetType() == typeof(source))
                {
                    Logging.LogSuccessful("Found an instance of source in animation."); //Writes a successful message to the log file
                    var source = (source) item;
                    aniList.Add(source.BuildAnimation());
                }
            }
            
            //This loop merges all lists so they contain matching data for name, transform and time
            if (aniList.Count > 0)
            {
                for (int i = 0; i < aniList[0].Count; i++)
                {
                    AnimationInfo singleAni = new AnimationInfo();
                    for (int j = 0; j < aniList.Count; j++)
                    {
                        List<AnimationInfo> a = aniList[j];
                        if (!a[i].name.Equals("#@"))
                        {
                            if (a[i].name.EndsWith("-transform")) //Removes transform so name of animation transform matches the name of the bone
                            {
                                a[i].name.Replace("-transform", ""); 
                            }
                            singleAni.name = aniList[j][i].name;
                        }
                        if (!a[i].time.Equals(new float()))
                        {
                            singleAni.time = aniList[j][i].time;
                        }
                        if (!a[i].transform.Equals(new Matrix()))
                        {
                            singleAni.transform = aniList[j][i].transform;
                        }
                    }
                    returnedList.Add(singleAni);
                }
                return returnedList;
            }

            return null;
        }
    }
}
