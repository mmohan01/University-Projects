﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ColladaImporter.Base
{
    class Keyframe
    {
        public int Bone { get; set; }
        public TimeSpan StartTime { get; set; }
        public TimeSpan EndTime { get; set; }

        public Keyframe(int bone, TimeSpan startTime, TimeSpan endTime)
        {
            Bone = bone;
            StartTime = startTime;
            EndTime = endTime;
        } 
    }
}
