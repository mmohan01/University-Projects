﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ColladaImporter.Base.Animation;
using Microsoft.Xna.Framework;

namespace ColladaImporter.Base
{
    /// <summary>
    /// This class checks the partial class source in the collada schema and checks the different items
    /// </summary>
    public partial class source
    {
        public List<AnimationInfo> BuildAnimation()
        {
            List<AnimationInfo> aniList = new List<AnimationInfo>();

                if (Item.GetType() == typeof (IDREF_array))
                {
                    Logging.LogUnsupported("IDREF_array was not imported as it is not supported in this model."); //Writes an unsupported message to the log file
                    return null;
                }
                else if (Item.GetType() == typeof (Name_array))
                {
                    Logging.LogSuccessful("Name_array was imported from the DAE file."); //Writes a successful message to the log file
                    var ar = (Name_array) Item;
                    //Iterates through the values in Name_array and adds them to a list
                    for (int i = 0; i < ar.Values.Length; i++ )
                    {
                        var s = ar.Values[i];
                        AnimationInfo ani = new AnimationInfo();
                        ani.name = s;
                        aniList.Add(ani);
                    }
                    return aniList;
                }
                else if (Item.GetType() == typeof (bool_array))
                {
                    Logging.LogUnsupported("Bool_array were not imported as it is not supported in this model.");
                    return null;
                }
                else if (Item.GetType() == typeof (int_array))
                {
                    Logging.LogUnsupported("Int_array were not imported as it is not supported in this model.");
                    return null;
                }
                else if (Item.GetType() == typeof (float_array))
                {
                    Logging.LogSuccessful("Float_array was imported from the DAE file.");
                    if (this.technique_common.accessor.param[0].name.Equals("TIME")) //Checks to see if name is TIME then adds the values to a list if true
                    {
                        Logging.LogSuccessful("Input array was imported from the DAE file.");
                        var ar = (float_array)Item;
                        for (int i = 0; i < ar.Values.Length; i++)
                        {
                            var s = ar.Values[i];
                            AnimationInfo ani = new AnimationInfo();
                            ani.time = s;
                            aniList.Add(ani);
                        }
                        return aniList;
                    }
                    if (this.technique_common.accessor.param[0].name.Equals("TRANSFORM")) //Checks to see if name is TRANSFORM
                    {
                        Logging.LogSuccessful("Output array was imported from the DAE file.");
                        var ar = (float_array)Item;
                        //Transforms are stored in 16 items so it puts all 16 together into the 1 matrix and stores a list of matrices 
                        for (int i = 0; i < ar.Values.Length; i+=16)
                        {
                            Matrix s = new Matrix(ar.Values[i], ar.Values[i+1], ar.Values[i+2], ar.Values[i+3], ar.Values[i+4],
                                                  ar.Values[i+5], ar.Values[i+6], ar.Values[i+7], ar.Values[i+8], ar.Values[i+9],
                                                  ar.Values[i+10], ar.Values[i+11], ar.Values[i+12], ar.Values[i+13], ar.Values[i+14], ar.Values[i+15]);
                            AnimationInfo ani = new AnimationInfo();
                            ani.transform = s;
                            aniList.Add(ani);
                        }
                        return aniList;
                    }
                }
            return null;
        }
    }
}

