﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content.Pipeline;
using Microsoft.Xna.Framework.Content.Pipeline.Graphics;

namespace ColladaImporter.Base
{
    public enum AnimationType
    {
        Float,
        Float4X4,
        Name
    }

    public class AnimationInfo : AnimationContent
    {
        public AnimationType Type { get; set; }
        public float time;
        public String name = "#@";
        public Matrix transform;

        public AnimationInfo(String sid, AnimationType z, Matrix w)
        {
            this.Name = sid;
            Type = z;
            //Transform = w;
        }

    public AnimationInfo()
    {
        //Don't remove
    }
    }
}
