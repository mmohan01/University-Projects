﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ColladaImporter.Base
{
    /// <summary>
    /// Helper class to store inputs.
    /// </summary>
    public class ParsedInput
    {
        public enum InputType
        {
            Unsuported,
            //Geometry
            Vertex,
            Normal,
            TextCoord,
            //Skeletal/vertex weights
            Joint,
            Weight
        }

        #region Properties

        /// <summary>
        /// Input type.
        /// </summary>
        public InputType Type { get; set; }

        /// <summary>
        /// Offset in the primitive tag.
        /// </summary>
        public ulong Offset { get; set; }

        /// <summary>
        /// Source to retrieve values from.
        /// </summary>
        public string SourceName { get; set; }

        #endregion

        public ParsedInput(ulong offset, string source)
        {
            this.Offset = offset;
            this.SourceName = source;
        }

        /// <summary>
        /// Creates an easy to use list of inputs for the mesh.
        /// </summary>
        /// <param name="inputs">Collada input items.</param>
        /// <returns></returns>
        public static ParsedInput[] ParseInputs(InputLocalOffset[] inputs)
        {
            var list = new List<ParsedInput>();
            foreach (var input in inputs)
            {
                var parsedInput = new ParsedInput(input.offset, input.source);
                switch (input.semantic)
                {
                    //Geometry
                    case "VERTEX":
                        parsedInput.Type = ParsedInput.InputType.Vertex;
                        break;
                    case "NORMAL":
                        parsedInput.Type = ParsedInput.InputType.Normal;
                        break;
                    case "TEXCOORD":
                        parsedInput.Type = ParsedInput.InputType.TextCoord;
                        break;
                    //Skeletal/Vertex weights
                    case "JOINT":
                        parsedInput.Type = ParsedInput.InputType.Joint;
                        break;
                    case "WEIGHT":
                        parsedInput.Type = ParsedInput.InputType.Weight;
                        break;

                    default:
                        Logging.LogUnsupported(input.semantic + " are not imported as they are not supported in this model.");
                        parsedInput.Type = ParsedInput.InputType.Unsuported;
                        break;
                }
                list.Add(parsedInput);
            }
            return list.ToArray();
        }

        /// <summary>
        /// Counts the number of unique offsets within the inputs.
        /// </summary>
        /// <param name="inputs"></param>
        /// <returns></returns>
        public static long UniqueInputPositions(ParsedInput[] inputs)
        {
            //Find the number of unique offsets in the input list
            var uniqueInputPositions = new List<ulong>();
            for (var i = 0; i < inputs.Length; i++)
                if (!uniqueInputPositions.Contains(inputs[i].Offset))
                    uniqueInputPositions.Add(inputs[i].Offset);

            return uniqueInputPositions.Count;
        }
    }
}
