﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using Microsoft.Xna.Framework.Content.Pipeline;
using Microsoft.Xna.Framework.Content.Pipeline.Graphics;
using NUnit.Framework;
using ColladaImporter.Base;

namespace UnitTests
{
    [TestFixture]
    class MaterialsTest
    {
        private COLLADA collada;
        string filename = "Goblin.dae";

    public MaterialsTest()
    {
        FileStream fs = null;
        var serializer = new XmlSerializer(typeof (COLLADA));
        fs = new FileStream(filename, FileMode.Open);
        var reader = new XmlTextReader(fs);
        collada = (COLLADA) serializer.Deserialize(reader);

        if (collada != null)
        {
            
        }
    }

    [Test]
    public void TestMaterials()
    {
        var materials = collada.BuildMaterials(new Dictionary<string, ExternalReference<TextureContent>>());
        Assert.AreEqual("m", materials["_3_-_Default"].Name, "ERROR!");
        //    Assert.AreEqual("LightDir", materials["_3_-_Default"], "Incorrect name of material effect. It should be LightDir.");
        //    Assert.AreEqual("ambientColor", materials[1].Name, "Incorrect name of material effect. It should be ambientColor.");
        //    Assert.AreEqual("diffuseColor", materials[2].Name, "Incorrect name of material effect. it should be diffuseColor.");
        //    Assert.AreEqual("specularColor", materials[3].Name, "Incorrect name of material effect. It should be specularColor.");
        //    Assert.AreEqual("shininess", materials[4].Name, "Incorrect name of material effect. It should be shininess.");
        //    Assert.AreEqual("diffuseTexture", materials[5].Name, "Incorrect name of material effect. It should be diffuseTexture.");
        //    Assert.AreEqual("normalTexture", materials[6].Name, "Incorrect name of material effects. It should be normalTexture.");
    }
    }
}
