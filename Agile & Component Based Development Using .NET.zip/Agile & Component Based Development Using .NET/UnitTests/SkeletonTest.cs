﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using NUnit.Framework;
using ColladaImporter.Base;


namespace UnitTests
{

    /// <summary>
    /// Testing skeleton bones hierarchy  and names 
    /// </summary>
    [TestFixture]
    class SkeletonTest
    {
        private COLLADA collada;
        string filename = "Goblin.dae";
        FileStream fs = null;

        public SkeletonTest()
        {
            var serializer = new XmlSerializer(typeof(COLLADA));
            fs = new FileStream(filename, FileMode.Open);
            var reader = new XmlTextReader(fs);
            collada = (COLLADA)serializer.Deserialize(reader);
        }


        //Testing root Node 
        [Test]
        public void TestRootNode()
        {

            var skeleton = collada.BuildSkeleton();
           
            //Checking the proper root node 
            Assert.IsNull(skeleton["goblin_max"][0].Parent, "This is the root node, should NOT have any parents!");

            //Checking the correct name of the root node
            Assert.AreEqual("AlienPelvis-node", skeleton["goblin_max"][0].Name, "WRONG NAME OF THE ROOT NODE!");
            

            //Testing number of children nodes for the root node 
            Assert.AreEqual(3, skeleton["goblin_max"][0].Children.Count, "INCORRECT NUMBER OF ROOT NODE'S CHILDREN");

            //Checking root node children's indices and their corresponding names 


            Assert.AreEqual("AlienSpine1-node", skeleton["goblin_max"][0].Children[0].Name, "WRONG NAME!");
            Assert.AreEqual("AlienLLeg1-node", skeleton["goblin_max"][0].Children[1].Name, "WRONG NAME!");
            Assert.AreEqual("AlienRLeg1-node", skeleton["goblin_max"][0].Children[2].Name, "WRONG NAME!");
         
        }

        //Testing Root Node --->  Spine Node
        [Test]
        public void TestSpineNode()
        {
            var skeleton = collada.BuildSkeleton();
           
            //Testing child and parent of Spine Node 
            Assert.AreEqual("AlienPelvis-node", skeleton["goblin_max"][0].Children[0].Parent.Name, "WRONG NAME OF PARENT NODE!");
            Assert.AreEqual(1, skeleton["goblin_max"][0].Children[0].Children.Count, "WRONG NUMBER OF CHILDREN!");
            Assert.AreEqual("AlienSpine2-node",skeleton["goblin_max"][0].Children[0].Children[0].Name, "WRONG NAME OF THE CHILD NODE!");
            

            
        }


        //Testing Root Node ---> Spine Node ---> Spine Node2
        [Test]
        public void TestSpineNodeChildNode()
        {
            var skeleton = collada.BuildSkeleton();
            
            //Testing Spine Node's child - Spine Node 2 that should have further children...
            //Checking parent's name 
            Assert.AreEqual("AlienSpine1-node", skeleton["goblin_max"][0].Children[0].Children[0].Parent.Name, "WRONG NAME OF PARENT NODE!");

            //Checking number of children
            Assert.AreEqual(1, skeleton["goblin_max"][0].Children[0].Children[0].Parent.Children.Count, "WRONG NUMBER OF CHILDREN NODE!");

            //Checking the name of child node
            Assert.AreEqual("AlienRibcage-node", skeleton["goblin_max"][0].Children[0].Children[0].Children[0].Name, "WRONG NAME OF CHILDREN NODE!");

        }

        //Testing Root Node ---> Spine Node ---> Spine Node2 ---> RibcageNode
        [Test]
        public void TestRibcageNode()
        {
            var skeleton = collada.BuildSkeleton();

            //Testing Spine Node 2's child - Ribcage Node that should have further children...

            //Checking parent's name 
            Assert.AreEqual("AlienSpine2-node", skeleton["goblin_max"][0].Children[0].Children[0].Children[0].Parent.Name, "WRONG NAME OF PARENT NODE!");

            //Checking number of children
            Assert.AreEqual(3, skeleton["goblin_max"][0].Children[0].Children[0].Children[0].Children.Count, "WRONG NUMBER OF CHILDREN NODES!");

            //Testing names and indices of children nodes 
            Assert.AreEqual("AlienLArmCollarbone-node", skeleton["goblin_max"][0].Children[0].Children[0].Children[0].Children[0].Name, "WRONG NAME!");
            Assert.AreEqual("AlienSpine1-node2", skeleton["goblin_max"][0].Children[0].Children[0].Children[0].Children[1].Name, "WRONG NAME!");
            Assert.AreEqual("AlienRArmCollarbone-node", skeleton["goblin_max"][0].Children[0].Children[0].Children[0].Children[2].Name, "WRONG NAME!");


        }

        //Testing Root Node ---> Spine Node ---> Spine Node2 ---> RibcageNode ---> Spine1Nod
        [Test]
        public void TestRibcageChildSpine1Nod()
        {
            var skeleton = collada.BuildSkeleton();

            //Testing Ribcage Node's child - Spine1Nod that should have further children...

            //Checking parent's name 
            Assert.AreEqual("AlienRibcage-node", skeleton["goblin_max"][0].Children[0].Children[0].Children[0].Children[0].Parent.Name, "WRONG NAME OF PARENT NODE!");

            //Checking number of children
            Assert.AreEqual(1, skeleton["goblin_max"][0].Children[0].Children[0].Children[0].Children[0].Children.Count);

            //Checking the name of children
            Assert.AreEqual("AlienSpine2-node2", skeleton["goblin_max"][0].Children[0].Children[0].Children[0].Children[1].Children[0].Name);
        }

        //Testing Root Node ---> Spine Node ---> Spine Node2 ---> RibcageNode ---> LArmCollarbone
       [Test]
       public void TestRibcageChildLeftArmCollarbone()
       {
           var skeleton = collada.BuildSkeleton();

           //Testing Ribcage Node's child - LArmCollar Node that should have further children...
           Assert.AreEqual("AlienRibcage-node",skeleton["goblin_max"][0].Children[0].Children[0].Children[0].Children[0].Parent.Name, "WRONG NAME OF PARENT NODE!");
           Assert.AreEqual(1, skeleton["goblin_max"][0].Children[0].Children[0].Children[0].Children[0].Children.Count, "WRONG NUMBER OF CHILDREN!");
           Assert.AreEqual("AlienLArm1-node", skeleton["goblin_max"][0].Children[0].Children[0].Children[0].Children[0].Children[0].Name, "WRONG NAME OF CHILD NODE!");
       }

       //Testing Root Node ---> Spine Node ---> Spine Node2 ---> RibcageNode ---> LArmCollarbone ---> AlienLArm1-node
       [Test]
       public void TestLArmCollarboneChildLArm()
       {    
           var skeleton = collada.BuildSkeleton();


           //Testing LArmCollarbone's child - LArm1Node that should have further children
           Assert.AreEqual("AlienLArmCollarbone-node",
               skeleton["goblin_max"][0].Children[0].Children[0].Children[0].Children[0].Children[0].Parent.Name,
               "WRONG NAME OF PARENT NODE!");

           Assert.AreEqual(1, 
               skeleton["goblin_max"][0].Children[0].Children[0].Children[0].Children[0].Children[0].Children.Count,
               "WRONG NUMBER OF CHILDREN!");

           Assert.AreEqual("AlienLArm2-node", 
               skeleton["goblin_max"][0].Children[0].Children[0].Children[0].Children[0].Children[0].Children[0].Name, 
               "WRONG NAME OF CHILD NODE!");
           
       }

        //Comparing two model arms by their tree hierarchy 
       [Test]
       public void TestComparingTwoCollars()
       {
           var skeleton = collada.BuildSkeleton();

           //TODO: Write comparison

           
       }
       #region TearDown
       [TearDown]
       public void StopTest()
       {
           fs.Close();
       }

       #endregion

    }
}
