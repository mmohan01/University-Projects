﻿using System;
using System.Text;
using System.Collections.Generic;
using ColladaImporter;
using ColladaImporter.Base.Animation;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content.Pipeline.Graphics;
using Microsoft.Xna.Framework;
using System.IO;
using Microsoft.Xna.Framework.Content.Pipeline;
using ColladaImporter.Base.Animation.Skeleton;



using System.Xml;
using System.Xml.Serialization;
using ModelViewer;
using NUnit.Framework;
using ColladaImporter.Base;



namespace UnitTests
{
    /// <summary>
    /// Testing Number of meshes, name, number of vertices channels, number of vertices.
    /// 
    /// </summary>
    [TestFixture]
    public class GeometryTest
    {
        
        private COLLADA collada;
        string filename = "Goblin.dae";
        FileStream fs = null;
        

        public GeometryTest()
        {
            var serializer = new XmlSerializer(typeof(COLLADA));
            fs = new FileStream(filename, FileMode.Open);
            var reader = new XmlTextReader(fs);
            collada = (COLLADA)serializer.Deserialize(reader);
            
    
        }
       
        
        // Testing Number of meshes, name, number of vertices channels, number of vertices.
        [Test]
        public void TestMeshes()
        {

            string meshName = "objgoblin_1-mesh-skin";
            MeshBuilder meshBuilder = MeshBuilder.StartMesh(meshName);
            var meshes = collada.BuildGeometry(meshBuilder, meshName,null);

         
            
                //Correct name of mesh imported?
            Assert.AreEqual("objgoblin_1-mesh-skin", meshes.Name, "Incorrect name of mesh has been imported!");
            
          

        }

        [Test]
        public void TestSources()
        {
            FileInfo file = new FileInfo(filename);
            var geo = collada.Build(file);

            Assert.AreEqual(2,geo.Children.Count, "Wrong number!");
            Assert.AreEqual("AlienPelvis-node", geo.Children[0].Name, "Wrong name!");
            Assert.AreEqual("#objgoblin_1-mesh-skin", geo.Children[1].Name, "Wrong name!");
            Assert.AreEqual(12, geo.Children[0].Transform, "Wrong!");
            

        }

        

        #region TearDown
        [TearDown]
        public void StopTest()
        {
            fs.Close();
        }

        #endregion

 
    }
}
