﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content.Pipeline.Graphics;
using NUnit.Framework;
using ColladaImporter.Base;

namespace UnitTests
{
    /// <summary>
    /// Testing the texture importer
    /// </summary>
    [TestFixture]
    class TextureTest
    {

        private COLLADA collada;
        string filename = "Goblin.dae";
        FileStream fs = null;

        public TextureTest()
        {
            var serializer = new XmlSerializer(typeof(COLLADA));
            fs = new FileStream(filename, FileMode.Open);
            var reader = new XmlTextReader(fs);
            collada = (COLLADA)serializer.Deserialize(reader);
        }

        #region Texture Path Test

        /// <summary>
        /// Tests to see if the texture files are grabbed from the collada importer
        /// </summary>
        [Test]
        public void TestTexturePath()
        {
            FileInfo f = new FileInfo(filename);
            string fPath = f.Directory.FullName;
            fPath = fPath.Replace("\\bin\\Debug", "");
            var texture = collada.BuildTextures(fPath);
            var fakeTexture = collada.BuildTextures("C:\\Fake\\Directory\\");

            //Checks that there are two textures
            Assert.AreEqual(texture.Count, 2);

            //Two texture files are mentioned in the goblin collada file, so both files must be tested to see if they have been retrieved
            Assert.AreEqual(texture["E__code_Xna_TestXnaQuest_ColladaModels_Textures_goblin_dds"].Filename, Path.Combine(fPath, "Textures\\goblin.dds"));
            Assert.AreEqual(texture["E__code_Xna_TestXnaQuest_ColladaModels_Textures_goblinNormal_dds"].Filename, Path.Combine(fPath, "Textures\\goblinNormal.dds"));

            //Test to make sure that the importer doesn't try to pass back a texture that has an incorrect filepath
            Assert.AreEqual(new Dictionary<string, TextureContent>(), fakeTexture);
            
        }
        #endregion

        #region Material Test

        /// <summary>
        /// Tests to see if the correct material data is grabbed from the collada importer
        /// </summary>
        [Test]
        public void TestMaterials()
        {
            FileInfo f = new FileInfo(filename);
            string fPath = f.Directory.FullName;
            fPath = fPath.Replace("\\bin\\Debug", "");
            var texture = collada.BuildTextures(fPath);
            var materials = collada.BuildMaterials(texture);

            //Checks that the correct amount of materials have been grabbed
            Assert.AreEqual(materials.Count, 1);

            //Checking the value of diffuse colour matches the value specified in the collada file
            Assert.AreEqual(materials["_3_-_Default"].DiffuseColor, new Vector3(0.564706f, 0.564706f, 0.564706f));
            
            //Checks that the correct textures are stored in the correct manner
            Assert.AreEqual(materials["_3_-_Default"].Textures["Texture"].Filename, Path.Combine(fPath, "Textures\\goblin.dds"));
            Assert.AreEqual(materials["_3_-_Default"].Textures["Normal"].Filename, Path.Combine(fPath, "Textures\\goblinNormal.dds"));

            //Checks that a value that shouldn't be read in from collada and stored to the material variable is null
            Assert.AreEqual(materials["_3_-_Default"].SpecularColor, null);
        }
        #endregion

        #region TearDown

        /// <summary>
        /// Needed to close down the file stream so more than one test can run without needing to reload the project on NUnit
        /// </summary>
        [TearDown]
        public void StopTest()
        {
            fs.Close();
        }
        #endregion

    }
}
