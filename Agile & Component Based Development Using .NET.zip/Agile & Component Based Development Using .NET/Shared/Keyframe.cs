﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

namespace Shared
{
    public class Keyframe
    {
        public int Bone { get; set; }
        public TimeSpan Time { get; set; }
        public Matrix Transform { get; set; }

        public Keyframe(int bone, TimeSpan time, Matrix transform)
        {
            Bone = bone;
            Time = time;
            Transform = transform;
        } 

        /// <summary>
        /// Parameterless constructor. DO NOT DELETE!
        /// </summary>
        public Keyframe()
        {
            
        }
    }
}
