﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using System.ComponentModel;
using System.IO;
using Microsoft.Xna.Framework.Graphics;
using Shared;

namespace Shared
{
    /// <summary>
    /// Combines all the data needed to render and animate a skinned object.
    /// This is typically stored in the Tag property of the Model being animated.
    /// </summary>
    [Serializable]
    public class SkeletonFormat
    {
        /// <summary>
        /// Constructs a new skinning data object.
        /// </summary>
        public SkeletonFormat(List<Matrix> bindPose, List<Matrix> inverseBindPose,
                            List<int> skeletonHierarchy, Dictionary<int, int> kinectMap, Dictionary<string, AnimationClip> aniClip)
        {
            BindPose = bindPose;
            InverseBindPose = inverseBindPose;
            SkeletonHierarchy = skeletonHierarchy;
            KinectMap= kinectMap;
            animationClip = aniClip;
        }


        /// <summary>
        /// Private constructor for use by the XNB deserializer.
        /// </summary>
        private SkeletonFormat()
        {
        }


        /// <summary>
        /// Bindpose matrices for each bone in the skeleton,
        /// relative to the parent bone.
        /// </summary>
        [ContentSerializer]
        public List<Matrix> BindPose { get; private set; }


        /// <summary>
        /// Vertex to bonespace transforms for each bone in the skeleton.
        /// </summary>
        [ContentSerializer]
        public List<Matrix> InverseBindPose { get; private set; }


        /// <summary>
        /// For each bone in the skeleton, stores the index of the parent bone.
        /// </summary>
        [ContentSerializer]
        public List<int> SkeletonHierarchy { get; private set; }

        /// <summary>
        /// Map model of the model skeleton onto the kinect skeleton.
        /// </summary>
        [ContentSerializer]
        public Dictionary<int, int> KinectMap { get; private set; }

        /// <summary>
        /// Map model of the model skeleton onto the kinect skeleton.
        /// </summary>
        [ContentSerializer]
        public Dictionary<string, AnimationClip> animationClip { get; private set; }
    }
}
