﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Content;

namespace Shared
{
    [Serializable]
    public class GroupedSkeletalHierarchy
    {
        /// <summary>
        /// Bone that is the parent to this box.
        /// </summary>
        [ContentSerializer]
        public int Parent { get; set; }

        /// <summary>
        /// List of child bones.
        /// </summary>
        [ContentSerializer]
        public List<int> Children { get; set; }

        [ContentSerializer]
        public List<GroupedSkeletalHierarchy> SubBoxes { get; set; }

        /// <summary>
        /// Return the sub group that's parent is parentBoneIndex.
        /// parentBoneIndex must be contained in this group's children.
        /// </summary>
        /// <param name="parentBoneIndex"></param>
        /// <returns></returns>
        public GroupedSkeletalHierarchy this[int parentBoneIndex]
        {
            get
            {
                if(!Children.Contains(parentBoneIndex))
                    throw new InvalidOperationException();

                foreach (var groupedSkeletalHierarchy in SubBoxes)
                {
                    if (groupedSkeletalHierarchy.Parent == parentBoneIndex)
                        return groupedSkeletalHierarchy;
                }
                return null;
            }
        }

        public GroupedSkeletalHierarchy()
        {
            Children = new List<int>();
            SubBoxes = new List<GroupedSkeletalHierarchy>();
        }
    }
}
