#include <stdlib.h>
#include <stdio.h>
#include <omp.h>
#include <string.h>
#include <math.h>
#include <time.h>

char *textData;
int textLength;

char *patternData;
int patternLength;

void outOfMemory()
{
	fprintf (stderr, "Out of memory\n");
	exit (0);
}

void readFromFile (FILE *f, char **data, int *length)
{
	int ch;
	int allocatedLength;
	char *result;
	int resultLength = 0;

	allocatedLength = 0;
	result = NULL;
	ch = fgetc (f);

	while (ch >= 0)
	{
		resultLength++;
		if (resultLength > allocatedLength)
		{
			allocatedLength += 10000;
			result = (char *) realloc (result, sizeof(char)*allocatedLength);
			if (result == NULL)
				outOfMemory();
		}

		result[resultLength-1] = ch;
		ch = fgetc(f);
	}

	*data = result;
	*length = resultLength;
}

int readData (int textNumber, int patternNumber)
{
	FILE *f;
	char fileName[1000];

	#ifdef DOS
		sprintf(fileName, "inputs\\text%d.txt", textNumber);
	#else
		sprintf(fileName, "inputs/text%d.txt", textNumber);
	#endif

	f = fopen (fileName, "r");
	if (f == NULL)
		return 0;
	readFromFile (f, &textData, &textLength);
	fclose (f);
	
	#ifdef DOS
		sprintf(fileName, "inputs\\pattern%d.txt", patternNumber);
	#else
		sprintf(fileName, "inputs/pattern%d.txt", patternNumber);
	#endif

	f = fopen (fileName, "r");
	if (f == NULL)
		return 0;
	readFromFile (f, &patternData, &patternLength);
	fclose (f);

	return 1;
}

int hostMatch(int textNumber, int patternNumber, int occurrence, FILE *fw)
{
	int i, j, k, lastI, position;
	j = 0;
	k = 0;
	lastI = textLength - patternLength;
	if (lastI < 0)
	lastI = 0;
	
	position = -1;
	omp_set_dynamic(0);
  
	#pragma omp parallel for default(none) num_threads(8) shared(position) firstprivate (i, j, k, lastI, patternLength, textData, patternData, textNumber, patternNumber, occurrence, fw)
	for (i = 0; i <= lastI; i++)
	{
		k = i;
		j = 0;
		
		if ((occurrence == 0) && (position != -1) && (i >= position))
			i = lastI;
		else
		{
			while ((textData[k] == patternData[j]) && (j < patternLength))
			{
				k++;
				j++;
			}

			if (j == patternLength)
			{
	
				if ((position == -1) || (i < position))
					position = i;

				if (occurrence == 1)
					fprintf(fw, "%d %d %d\n", textNumber, patternNumber, i);
				else
					i = lastI;
			}	
		
		}
	}

	return position;
}

int main(int argc, char **argv)
{
	int occurrence, textNumber, patternNumber;
	unsigned int result;
	char fileInput[1000];
	FILE *fr, *fw;

	#ifdef DOS
		sprintf(fileInput, "inputs\\control.txt");
	#else
		sprintf(fileInput, "inputs/control.txt");
	#endif

	fr = fopen(fileInput, "r");
	if (fr == NULL)
		return 0;

	sprintf(fileInput, "result_OMP.txt");

	fw = fopen(fileInput, "w");
	if (fw == NULL)
		return 0;

	fscanf(fr, "%d", &occurrence);

	while (!feof(fr))
	{
		fscanf(fr, "%d", &textNumber);
		fscanf(fr, "%d", &patternNumber);

		readData(textNumber, patternNumber);
		result = hostMatch(textNumber, patternNumber, occurrence, fw);
		if ((occurrence == 0) || ((occurrence == 1) && (result == -1)))
			fprintf(fw, "%d %d %d\n", textNumber, patternNumber, result);

		fscanf(fr, "%d", &occurrence);
	}

	fclose(fr);
	fclose(fw);
}
