#include <mpi.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <time.h>

char *textData, *textSplitData, *patternData;
int textLength, textSplitLength, patternLength, *multipleOccurrences;

void outOfMemory()
{
	fprintf (stderr, "Out of memory\n");
	exit (0);
}

void readFromFile (FILE *f, char **data, int *length)
{
	int ch;
	int allocatedLength;
	char *result;
	int resultLength = 0;

	allocatedLength = 0;
	result = NULL;
	ch = fgetc (f);

	while (ch >= 0)
	{
		resultLength++;
		if (resultLength > allocatedLength)
		{
			allocatedLength += 10000;
			result = (char *) realloc (result, sizeof(char)*allocatedLength);
			if (result == NULL)
				outOfMemory();
		}

		result[resultLength-1] = ch;
		ch = fgetc(f);
	}

	*data = result;
	*length = resultLength;
}

int readData(int textNumber, int patternNumber)
{
	FILE *f;
	char fileName[1000];

	#ifdef DOS
		sprintf(fileName, "inputs\\text%d.txt", textNumber);
	#else
		sprintf(fileName, "inputs/text%d.txt", textNumber);
	#endif

	f = fopen(fileName, "r");
	if (f == NULL)
		return 0;
	readFromFile(f, &textData, &textLength);
	fclose(f);

	#ifdef DOS
		sprintf(fileName, "inputs\\pattern%d.txt", patternNumber);
	#else
		sprintf(fileName, "inputs/pattern%d.txt", patternNumber);
	#endif

	f = fopen(fileName, "r");
	if (f == NULL)
		return 0;
	readFromFile(f, &patternData, &patternLength);
	fclose(f);

	return 1;
}

int hostMatch(int occurrence)
{
	int i, j, k, in, lastI;
	
	i=0;
	j=0;
	k=0;
	in = 0;
	lastI = textSplitLength - patternLength;

	if (occurrence == 1)
	{
		while (i <= lastI)
		{
			if (j == patternLength)
			{
				in = 1;
				multipleOccurrences[i] = 1;

				i++;
                		k = i;
               			j = 0;
			}

			if (textSplitData[k] == patternData[j])
			{
				k++;
				j++;
			}
			else
			{
				i++;
				k = i;
				j = 0;
			}
		}
	}
	else
	{
		while ((i <= lastI) && (j < patternLength))
		{
			if (textSplitData[k] == patternData[j])
			{
				k++;
				j++;
			}
			else
			{
				i++;
				k = i;
				j = 0;
			}
		}
	}

	if (((occurrence == 0) && (j == patternLength)) || ((occurrence == 1) && (in == 1)))
		return i;
	else
		return -1;
}

int main(int argc, char **argv)
{
	int npes, myrank, occurrence, textNumber, patternNumber, i;
	unsigned int result, mainResult, remainder, splitSize;
     
	MPI_Status Stat;
	MPI_Init(&argc, &argv);
	MPI_Comm_size(MPI_COMM_WORLD, &npes);
	MPI_Comm_rank(MPI_COMM_WORLD, &myrank);
	
	FILE *fr;
	char fileInput[1000];
        int sendcounts[npes], displacements[npes], receivecounts[npes];

	#ifdef DOS
		sprintf(fileInput, "inputs\\control.txt");
	#else
		sprintf(fileInput, "inputs/control.txt");
	#endif

	fr = fopen(fileInput, "r");
	if (fr == NULL)
		return 0;

	FILE *fw;
	sprintf(fileInput, "result_MPI.txt");

	fw = fopen(fileInput, "w");
	if (fw == NULL)
		return 0;

	fscanf(fr, "%d", &occurrence);

	while (!feof(fr))
	{
		fscanf(fr, "%d", &textNumber);
		fscanf(fr, "%d", &patternNumber);

		if (myrank == 0)
			readData(textNumber, patternNumber);

		MPI_Bcast(&textLength, 1, MPI_INT, 0, MPI_COMM_WORLD);
		MPI_Bcast(&patternLength, 1, MPI_INT, 0, MPI_COMM_WORLD);

		if ((npes > textLength) || (textLength == patternLength))
		{
			if (myrank == 0)
			{
				textSplitLength = textLength;
				textSplitData = textData;
				// multipleOccurrences = (int *)malloc(sizeof(int)*textLength);
				multipleOccurrences = calloc(textLength, sizeof(int));

				//for (i = 0; i < textLength; i++)
				//	multipleOccurrences[i] = 0;

				if (textLength < patternLength)
					result = -1;
				else
					result = hostMatch(occurrence);

				if ((occurrence == 0) || (result == -1))
					fprintf(fw, "%d %d %d\n", textNumber, patternNumber, result);

				for (i = 0; i < textLength; i++)
				{
					if (multipleOccurrences[i] == 1)
						fprintf(fw, "%d %d %d\n", textNumber, patternNumber, i);
				}
			}
		}
		else
		{
			remainder = textLength%npes;
			
			for (i = 0; i < npes; i++)
			{
				if (i == (npes - 1))
					sendcounts[i] = textLength / npes;
				else
					sendcounts[i] = (textLength / npes) + patternLength - 1;

				receivecounts[i] = textLength / npes;
				displacements[i] = (textLength / npes)*i;

				if (remainder != 0) 
				{ 
					if (i < remainder)
					{
						sendcounts[i] += 1;
						receivecounts[i] += 1;
					}

					if ((i-1) < remainder)
						displacements[i] += i;
					else
						displacements[i] += remainder;
				}


			}
			
			textSplitLength = sendcounts[myrank];
			splitSize = receivecounts[myrank];
			textSplitData = (char *)malloc(sizeof(char)*textSplitLength);
			//multipleOccurrences = (int *)malloc(sizeof(int)*splitSize);
			multipleOccurrences = calloc(splitSize, sizeof(int));

			//for (i = 0; i < splitSize; i++)
			//	multipleOccurrences[i] = 0;

			MPI_Scatterv(textData, sendcounts, displacements, MPI_CHAR, textSplitData, textSplitLength, MPI_CHAR, 0, MPI_COMM_WORLD);

			if (myrank != 0)
				patternData = (char *)malloc(sizeof(char)*patternLength);

			int receiveMultipleOccurrences[textLength];

			MPI_Bcast(&patternData[0], patternLength, MPI_CHAR, 0, MPI_COMM_WORLD);

			if (((myrank == (npes - 1)) && (sendcounts[myrank] < patternLength)) || (textLength < patternLength))
				result = -1;
			else
				result = hostMatch(occurrence);

			MPI_Gatherv(&multipleOccurrences[0], splitSize, MPI_INT, receiveMultipleOccurrences, receivecounts, displacements, MPI_INT, 0, MPI_COMM_WORLD);

			if ((occurrence == 0) && (result != -1))
				result += displacements[myrank];

			MPI_Reduce(&result, &mainResult, 1, MPI_UNSIGNED, MPI_MIN, 0, MPI_COMM_WORLD);

			if ((myrank == 0) && ((occurrence == 0) || (mainResult == -1)))
				fprintf(fw, "%d %d %d\n", textNumber, patternNumber, mainResult);

			if (myrank == 0)
			{
				for (i = 0; i < textLength; i++)
				{
					if (receiveMultipleOccurrences[i] == 1)
						fprintf(fw, "%d %d %d\n", textNumber, patternNumber, i);
				}
			}
		}

		fscanf(fr, "%d", &occurrence);
	}

	fclose(fr);
	fclose(fw);
	MPI_Finalize();
}
