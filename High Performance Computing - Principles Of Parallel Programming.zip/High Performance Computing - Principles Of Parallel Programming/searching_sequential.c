#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <time.h>

char *textData;
int textLength;

char *patternData;
int patternLength;

clock_t c0, c1;
time_t t0, t1;

void outOfMemory()
{
	fprintf (stderr, "Out of memory\n");
	exit (0);
}

void readFromFile (FILE *f, char **data, int *length)
{
	int ch;
	int allocatedLength;
	char *result;
	int resultLength = 0;

	allocatedLength = 0;
	result = NULL;
	ch = fgetc (f);

	while (ch >= 0)
	{
		resultLength++;
		if (resultLength > allocatedLength)
		{
			allocatedLength += 10000;
			result = (char *) realloc (result, sizeof(char)*allocatedLength);
			if (result == NULL)
				outOfMemory();
		}

		result[resultLength-1] = ch;
		ch = fgetc(f);
	}
	
	*data = result;
	*length = resultLength;
}

int readData (int textNumber, int patternNumber)
{
	FILE *f;
	char fileName[1000];

	#ifdef DOS
        	sprintf (fileName, "small-inputs\\text%d.txt", textNumber);
	#else
		sprintf (fileName, "small-inputs/text%d.txt", textNumber);
	#endif
	
	f = fopen (fileName, "r");
	if (f == NULL)
		return 0;
	readFromFile (f, &textData, &textLength);
	fclose (f);

	#ifdef DOS
        	sprintf (fileName, "small-inputs\\pattern%d.txt", patternNumber);
	#else
		sprintf (fileName, "small-inputs/pattern%d.txt", patternNumber);
	#endif
	
	f = fopen (fileName, "r");
	if (f == NULL)
		return 0;
	readFromFile (f, &patternData, &patternLength);
	fclose (f);

	return 1;
}

void hostMatch(int textNumber, int patternNumber, int occurrence, FILE *fw)
{
	int i,j,k, lastI;
	
	i=0;
	j=0;
	k=0;
	lastI = textLength-patternLength;
	int in = 0;

	if (occurrence == 1)
	{
		while (i <= lastI)
		{
			if (j == patternLength)
			{
				in = 1;
				fprintf(fw, "%d %d %d\n", textNumber, patternNumber, i);
			}

			if (textData[k] == patternData[j])
			{
				k++;
				j++;
			}
			else
			{
				i++;
				k = i;
				j = 0;
			}
		}

		if (in == 0)
			fprintf(fw, "%d %d -1\n", textNumber, patternNumber);
	}
	else
	{
		while ((i <= lastI) && (j < patternLength))
		{
			if (textData[k] == patternData[j])
			{
				k++;
				j++;
			}
			else
			{
				i++;
				k = i;
				j = 0;
			}
		}

		if (j == patternLength)
			fprintf(fw, "%d %d %d\n", textNumber, patternNumber, i);
		else
			fprintf(fw, "%d %d -1\n", textNumber, patternNumber);
	}

	//if (j == patternLength)
	//	return i;
	//else
	//	return -1;
}

int main(int argc, char **argv)
{
	FILE *fr;
	char fileInput[1000];

	#ifdef DOS
		sprintf(fileInput, "small-inputs\\control.txt");
	#else
		sprintf(fileInput, "small-inputs/control.txt");
	#endif

	fr = fopen(fileInput, "r");
	if (fr == NULL)
		return 0;

	FILE *fw;
	sprintf(fileInput, "result.txt");

	fw = fopen(fileInput, "w");
	if (fw == NULL)
		return 0;

	int occurrence, textNumber, patternNumber;
	unsigned int result;
	
	fscanf(fr, "%d", &occurrence);

	while (!feof(fr))
	{
		fscanf(fr, "%d", &textNumber);
		fscanf(fr, "%d", &patternNumber);

		readData(textNumber, patternNumber);
		hostMatch(textNumber, patternNumber, result, fw);
		//fprintf(fw, "%d %d %d\n", textNumber, patternNumber, result);

		fscanf(fr, "%d", &occurrence);
	}

	fclose(fr);
	fclose(fw);
}
