﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace MultiFrogger
{
    /// <Summary>
    /// Controls the movement of the second row of logs. They move from
    /// right to left across the screen
    /// </Summary>
    class Log2
    {
        /// <Summary>
        /// Here the Rectangles for drawing the images are declared in 
        /// an array. Also the Rectangle which is to handle collision 
        /// is declared here as well. They are declared as public static
        /// so that they can be accesed in any other class easily. The
        /// Texture2D Log is the sprite image that will be drew.
        /// </Summary>
        public static Rectangle[] position = new Rectangle[7];
        public static Rectangle[] collision = new Rectangle[7];
        private Texture2D Log;

        /// <Summary>
        /// This method instigates a random variable where random numbers
        /// are able to be called.
        /// </Summary>
        /// <returns></returns>
        public static int Randomise()
        {
            Random r = new Random();
            int b = r.Next(200, 400);
            return b;
        }


        /// <Summary>
        /// This method allows four parameters to be passed into into it.
        /// These parameters control the co-ordintates of the log on the
        /// screen. Also being set here is the position of the collision
        /// Rectangle. The Collision Rectangle moves proportionally to the
        /// log rectangle to detect when an intersect occurs. The for loop
        /// will loop through all of the positions by using the parameters
        /// that where passed in as a starting point, it will create positions
        /// on the x - axis for where the logs are supposed to appear.
        /// </Summary>
        /// <param name="i"></param>
        /// <param name="j"></param>
        /// <param name="x"></param>
        /// <param name="y"></param>
        public void Position(int i, int j, int x, int y)
        {
            position[0] = new Rectangle(i, j, x, y);
            collision[0] = new Rectangle(i + 18, j, x - 36, y);

            for (int n = 0; n < position.Length; n++)
            {
                if (n < 6)
                {
                    position[n + 1] = new Rectangle((position[n].X + Randomise()), j, x, y);
                    collision[n + 1] = new Rectangle((position[n].X + Randomise()+18), j, x-36, y);
                }
            }
        }

        /// <Summary>
        /// This method loads in the sprite image to be used in this class
        /// </Summary>
        /// <param name="theContentManager"></param>
        /// <param name="theAssetName"></param>
        public void LoadContent(ContentManager theContentManager, string theAssetName)
        {
            Log = theContentManager.Load<Texture2D>(theAssetName);
        }

        /// <Summary>
        /// This method draws out each of the image by using a for loop and 
        /// looping through the array of the log positions. The log position
        /// also gets incremented by 2 here, so that it appears that its moving
        /// across the screen. Also if a bus achieves an x position of less 
        /// than 1920 then the logs x position will be reset to -200. The 
        /// Collision Rectangle is also being moved across the screen here 
        /// too. This is done with relation to the image. Again the collision
        /// Rectangle will move in if the image of the log leaves the screen
        /// </Summary>
        /// <param name="theSpriteBatch"></param>
        public void Draw(SpriteBatch theSpriteBatch)
        {
            for (int j = 0; j < position.Length; j++)
            {
                theSpriteBatch.Draw(Log, position[j], Color.White);
                if (Switch.logSwitch == true)
                {
                    position[j].X = position[j].X + 2;
                    collision[j].X = collision[j].X + 2;
                    
                    if (position[j].X == 1920)
                    {
                        position[j].X = -200;
                        collision[j].X = -200 + 18;
                    }
                }
            }
        }
    }
}
