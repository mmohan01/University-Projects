﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace MultiFrogger
{
    /// <Summary>
    /// Controls the switch for level three. This class will animate
    /// the switch to show when it is being pressed. The switch will
    /// activate the logs moving in the river. Also in this level 
    /// two switches get drew to get the player across the screen. 
    /// To get the player across when a player enters the first switch
    /// they will then have generatered the second switch and will not 
    /// be able to move until someone activates the second switch. As 
    /// soon as someone enters the first switch the controls will also
    /// get repeatedly changed around. 
    /// </Summary>
    class Switchlvl3
    {
        /// <Summary>
        /// These variables are declared to enable the sprite image to be drew
        /// The logSwitch variable controls whether or not the logs are moving, 
        /// the switchPlace variable controls when the switch moving to a new 
        /// place. The two point variables control the position that the frame 
        /// is being drew from and the size of the image being drew. frogmovement 
        /// and frogmovement2 controls whether or not the respective frog can 
        /// move and change, determines whether or not the second image gets 
        /// drew. Controls determines whether or not the controls are normal 
        /// or backwards. This value gets set and relates back to the frog classes 
        /// to control the movement. 
        /// </Summary>
        Texture2D Button;
        Rectangle ButtonRect;
        Rectangle ButtonRect2;
        int ax, bx, cx, dx, ex, fx, ay, by, cy, dy, ey, fy;
        public static int switchPlace = 0;
        public static int change = 0;
        public static int frogmovement = 0;
        public static int frogmovement2 = 0;
        public static int controls = 0;
        Point frameSize = new Point(50, 50);
        Point currentFrame = new Point(0, 0);

        /// <summary>
        /// This method generates new random values within a specific
        /// range so that we can generate random positions of the 
        /// switches on the map.
        /// </summary>
        public void Randomise()
        {
        Random r = new Random();
            ay = r.Next(390, 700);
            ax = r.Next(0, 1320);
            by = r.Next(390, 700);
            bx = r.Next(0, 1320);
            cy = r.Next(390, 700);
            cx = r.Next(0, 1320);
            dy = r.Next(390, 700);
            dx = r.Next(0, 1320);
            ey = r.Next(390, 700);
            ex = r.Next(0, 1320);
            fy = r.Next(390, 700);
            fx = r.Next(0, 1320);
        }

        /// <summary>
        /// Initialises the Rectangles positions and sizes, also controls which
        /// co-ordinates the image is being drew in. An if statement is in place
        /// to determine whether or not the second image should be drew or not.
        /// This also changes the controls in the game so that the player is now
        /// controlling the character backwards
        /// </summary>
        public void initialise()
        {
            
            switch (switchPlace)
            {
                case 0:
                    ButtonRect = new Rectangle(ax, 470, 30, 35);
                    if (change == 1)
                    {
                        ButtonRect2 = new Rectangle(cx, ay, 30, 35);
                        
                            controls = 1;
                    }
                    break;
                case 1:
                    ButtonRect = new Rectangle(bx, 360, 30, 35);
                    if (change == 1)
                    {
                        ButtonRect2 = new Rectangle(dx, by, 30, 35);
                        
                            controls = 2;  
                    }
                    break;
                case 2:
                    ButtonRect = new Rectangle(cx, 470, 30, 35);
                    if (change == 1)
                    {
                        ButtonRect2 = new Rectangle(dx, cy, 30, 35);
                        
                            controls = 3;   
                    }
                    break;
                case 3:
                    ButtonRect = new Rectangle(dx, 580, 30, 35);
                    if (change == 1)
                    {
                        ButtonRect2 = new Rectangle(dx, dy, 30, 35);
                        
                            controls = 4;
                    }
                    break;
                case 4:
                    ButtonRect = new Rectangle(ex, 690, 30, 35);
                    if (change == 1)
                    {
                        ButtonRect2 = new Rectangle(ax, ey, 30, 35);

                            controls = 5;
                    }
                    break;
                case 5:
                    ButtonRect = new Rectangle(fx, 360, 30, 35);
                    if (change == 1)
                    {
                        ButtonRect2 = new Rectangle(dx, fy, 30, 35);
                        
                            controls = 6;
                    }
                    break;
            }
        }

        /// <Summary>
        /// This method loads in the sprite image to be used in this class
        /// </Summary>
        /// <param name="theContentManager"></param>
        /// <param name="theAssetName"></param>
        public void LoadContent(ContentManager theContentManager, string theAssetName)
        {
            Button = theContentManager.Load<Texture2D>(theAssetName);
        }

        /// <summary>
        /// allows the logs to move if the players frog intersects
        /// the sprite image. It also moves the currentFrame, to allow
        /// the image to animate. Also in this is the change variable 
        /// which tells the game to draw the second switch
        /// </summary>
        public void state()
        {

            if (Frog.collisionRect.Intersects(ButtonRect))
            {
                currentFrame.X = 1;
                change = 1;
                frogmovement = 1;
            }
            else if (Frog2.collisionRect.Intersects(ButtonRect))
            {
                currentFrame.X = 1;
                change = 1;
                frogmovement2 = 1;
            }
            else
            {
                currentFrame.X = 0;
            }

            if (Frog2.collisionRect.Intersects(ButtonRect2))
            {
                currentFrame.X = 1;
                Switch.logSwitch = true;
                frogmovement = 0;
            }

            else if (Frog.collisionRect.Intersects(ButtonRect2))
            {
                currentFrame.X = 1;
                Switch.logSwitch = true;
                frogmovement2 = 0;
            }
            else
            {
                Switch.logSwitch = false;
                currentFrame.X = 0;
            }     
            
        }

        /// <summary>
        /// This method draws the image on the screen and controls the
        /// frame of the image being drew. it will also draw the second 
        /// switch only if the first one has been intersected. This is 
        /// done through the change value. 
        /// </summary>
        /// <param name="theSpriteBatch"></param>
        public void Draw(SpriteBatch theSpriteBatch)
        {
            Rectangle x = new Rectangle(currentFrame.X * frameSize.X, currentFrame.Y * frameSize.Y, frameSize.X, frameSize.Y);
            theSpriteBatch.Draw(Button, ButtonRect, x, Color.White);
            if (change == 1)
            {
                theSpriteBatch.Draw(Button, ButtonRect2, x, Color.White);
            }        
        }
    }
}
