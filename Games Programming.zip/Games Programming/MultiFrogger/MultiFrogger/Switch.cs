﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace MultiFrogger
{
    /// <Summary>
    /// Controls the switch for level one. This class will animate
    /// the switch to show when it is being pressed. The switch will
    /// activate the logs moving in the river.
    /// </Summary>
    class Switch
    {
        /// <Summary>
        /// These variables are declared to enable the sprite image to be drew
        /// The logSwitch variable controls whether or not the logs are moving, 
        /// the switchPlace variable controls when the switch moving to a new 
        /// place. The two point variables control the position that the frame 
        /// is being drew from and the size of the image being drew.
        /// </Summary>
        Texture2D Button;
        Rectangle ButtonRect;
        
        public static bool logSwitch = false;
        int ax, bx, cx, dx, ex, fx, ay, by, cy, dy, ey, fy;
        public static int switchPlace = 0;
       
        Point frameSize = new Point(45, 25);
        Point currentFrame = new Point(0, 0);

        /// <Summary>
        /// This method generates new random values within a specific
        /// range so that we can generate random positions of the 
        /// switches on the map.
        /// </Summary>
        public void Randomise()
        {
        Random r = new Random();
            ay = r.Next(390, 700);
            ax = r.Next(0, 1320);
            by = r.Next(390, 700);
            bx = r.Next(0, 1320);
            cy = r.Next(390, 700);
            cx = r.Next(0, 1320);
            dy = r.Next(390, 700);
            dx = r.Next(0, 1320);
            ey = r.Next(390, 700);
            ex = r.Next(0, 1320);
            fy = r.Next(390, 700);
            fx = r.Next(0, 1320);
        }

        /// <Summary>
        /// Initialises the Rectangles positions and sizes, also controls which
        /// co-ordinates the image is being drew in.
        /// </Summary>
        public void initialise()
        {
            
            switch (switchPlace)
            {
                case 0:
                    ButtonRect = new Rectangle(ax, ay, 30, 35);
                    
                    break;
                case 1:
                    ButtonRect = new Rectangle(bx, by, 30, 35);
                 
                    break;
                case 2:
                    ButtonRect = new Rectangle(cx, cy, 30, 35);
                    break;
                case 3:
                    ButtonRect = new Rectangle(dx, dy, 30, 35);
                    break;
                case 4:
                    ButtonRect = new Rectangle(ex, ey, 30, 35);
                    break;
                case 5:
                    ButtonRect = new Rectangle(fx, fy, 30, 35);
                    break;
            }
        }

        /// <Summary>
        /// This method loads in the sprite image to be used in this class
        /// </Summary>
        /// <param name="theContentManager"></param>
        /// <param name="theAssetName"></param>
        public void LoadContent(ContentManager theContentManager, string theAssetName)
        {
            Button = theContentManager.Load<Texture2D>(theAssetName);
        }

        /// <summary>
        /// allows the logs to move if the players frog intersects
        /// the sprite image. It also moves the currentFrame, to allow
        /// the image to animate.
        /// </summary>
        public void state()
        {
            if (Frog.collisionRect.Intersects(ButtonRect))
            {
                logSwitch = true;
                currentFrame.X = 1;
            }
            else if (Frog2.collisionRect.Intersects(ButtonRect))
            {
                logSwitch = true;
                currentFrame.X = 1;
            }
            else
            {
                currentFrame.X = 0;
                logSwitch = false;
            }
        }

        /// <summary>
        /// This method draws the image on the screen and controls the
        /// frame of the image being drew.
        /// </summary>
        /// <param name="theSpriteBatch"></param>
        public void Draw(SpriteBatch theSpriteBatch)
        {
            Rectangle x = new Rectangle(currentFrame.X * frameSize.X, currentFrame.Y * frameSize.Y, frameSize.X, frameSize.Y);
            theSpriteBatch.Draw(Button, ButtonRect, x, Color.White);    
        }
    }
}
