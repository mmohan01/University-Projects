using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

namespace MultiFrogger
{
    /// <summary>
    /// This is the main class of our xna frogger game. This
    /// where everything gets called from and controlled
    /// </summary>
    public class MultiFrogger : Microsoft.Xna.Framework.Game
    {
        /// <Summary>
        /// This is where all of the variables are being declared in this class. 
        /// </Summary>
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        

        // the sprites that will be used for the game getting declared as textures
        Texture2D roads, lilly, frogLife, startGameBackground, water, startPlay, startHighScores, startInstructions, startExit, winlose;

        Rectangle BackgroundRect;
        public static Rectangle[] lillyrect = new Rectangle[6];
        public static Rectangle waterRect;

        // ints relating to the timer
        int timerMinutes = 0;
        int timerSeconds = 0;
        double timerCounter = 0;
     
        //objects that will be used in the game
        Lane1 Bus;
        Lane2 Van;
        Lane3 Car;

        Log1 firstLog;
        Log2 thirdLog;
        Log3 secondLog;

        Frog froglvl1, froglvl2, froglvl3;
        Frog2 frog2lvl1, frog2lvl2, frog2lvl3;

        Switch switchButton;
        Switchlvl2 switchlvl2;
        Switchlvl3 switchlvl3;

        // setting up the gamestates
        enum GameState { StartPlay, StartHighScores, StartInstructions, StartExit, Instructions, HighScores, Level1, Level2, Level3, Pause, GameWon, GameLost };
        GameState currentGameState = GameState.StartPlay;

        SpriteFont frogsPassed, frogsPassed2;
        public static int numberLivesRemaining = 3;
        public static int currentFrogs  = 0;
        public static int statechanger = 0;
        int scoreStore = 0;
        String text;
        
        KeyboardState previousState;

        // declaring the sound effects
        public static SoundEffect hop, squish, plunk, time;

        /// <Summary>
        /// Declares the graphicsDeviceManger and sets up where the content for the file is stored. 
        /// Sets the hieght of the screen for display. Also sets the screen to be full size.
        /// </Summary>
        public MultiFrogger()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            graphics.PreferredBackBufferHeight = 780;
            graphics.PreferredBackBufferWidth = 1360;
            graphics.IsFullScreen = true;
        }

        /// <Summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well. Used for initialising some variables
        /// </Summary>
        protected override void Initialize()
        {
            BackgroundRect = new Rectangle(0, 0, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height);
            waterRect = new Rectangle(0, 0, GraphicsDevice.Viewport.Width, (GraphicsDevice.Viewport.Height / 2)-60);
            
            lillyrect[0] = new Rectangle(60, 0, 100, 100);
            lillyrect[1] = new Rectangle(290, 0, 100, 100);
            lillyrect[2] = new Rectangle(520, 0, 100, 100);
            lillyrect[3] = new Rectangle(750, 0, 100, 100);
            lillyrect[4] = new Rectangle(980, 0, 100, 100);
            lillyrect[5] = new Rectangle(1210, 0, 100, 100);
            
            Bus = new Lane1();
            Bus.Position(40,620,100,60);
            Car = new Lane3();
            Car.Position(1920/9, 420, 90, 60);
            Van = new Lane2();
            Van.Position(20, 510, 80, 60);
           
            firstLog = new Log1();
            firstLog.Position(10, 265, 100, 40);
            secondLog = new Log3();
            secondLog.Position(10, 120, 100, 40);
            thirdLog = new Log2();
            thirdLog.Position(10, 190, 100, 40);

            froglvl2 = new Frog();
            froglvl2.initialise();
            frog2lvl2 = new Frog2();
            frog2lvl2.initialise();
            froglvl3 = new Frog();
            froglvl3.initialise();
            frog2lvl3 = new Frog2();
            frog2lvl3.initialise();
            froglvl1 = new Frog();
            froglvl1.initialise();
            frog2lvl1 = new Frog2();
            frog2lvl1.initialise();

            switchButton = new Switch();
            switchButton.Randomise();
            switchlvl2 = new Switchlvl2();
            switchlvl2.Randomise();
            switchlvl3 = new Switchlvl3();
            switchlvl3.Randomise();

            text = "Highscores";

            base.Initialize();
        }

        /// <Summary>
        /// This is where all of our content is getting loaded into the game. This includes
        /// all of the images and sounds used throughout our game. In this method, the images 
        /// get passed on to different classes to handle what to do with them.
        /// </Summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            startPlay = this.Content.Load<Texture2D>(@"Images/Background/Start Game Play");
            startHighScores = this.Content.Load<Texture2D>(@"Images/Background/Start Game High Scores");
            startInstructions = this.Content.Load<Texture2D>(@"Images/Background/Start Game Instructions");
            startExit = this.Content.Load<Texture2D>(@"Images/Background/Start Game Exit");
            winlose = this.Content.Load<Texture2D>(@"Images/Background/Game Win-Lose");
            startGameBackground = this.Content.Load<Texture2D>(@"Images/Background/Start Game Background");

            roads = this.Content.Load<Texture2D>(@"Images/Background/Background");
            water = this.Content.Load<Texture2D>(@"Images/Background/blue");
            lilly = this.Content.Load<Texture2D>("Images/Background/lilly pad");
            
            froglvl1.LoadContent(this.Content, "Images/Frog/Frog Sprite Sheet");
            frog2lvl1.LoadContent(this.Content, "Images/Frog/Frog Sprite Sheet 2");
            froglvl2.LoadContent(this.Content, "Images/Frog/Frog Sprite Sheet");
            frog2lvl2.LoadContent(this.Content, "Images/Frog/Frog Sprite Sheet 2");
            froglvl3.LoadContent(this.Content, "Images/Frog/Frog Sprite Sheet");
            frog2lvl3.LoadContent(this.Content, "Images/Frog/Frog Sprite Sheet 2");

            frogsPassed = this.Content.Load<SpriteFont>("Fonts/Arial");
            frogsPassed2 = this.Content.Load<SpriteFont>("Fonts/Castellar");

            frogLife = this.Content.Load<Texture2D>(@"Images/Frog/Frog");
  
            Bus.LoadContent(this.Content,"Images/Vehicles/bus");
            Car.LoadContent(this.Content, "Images/Vehicles/Car2");
            Van.LoadContent(this.Content, "Images/Vehicles/van");

            firstLog.LoadContent(this.Content, "Images/Background/log2");
            secondLog.LoadContent(this.Content, "Images/Background/log2");
            thirdLog.LoadContent(this.Content, "Images/Background/log2");

            switchButton.LoadContent(this.Content, "Images/Background/switch");
            switchlvl2.LoadContent(this.Content, "Images/Background/switch");
            switchlvl3.LoadContent(this.Content, "Images/Background/switch");

            hop = Content.Load<SoundEffect>("Sounds/dp_frogger_hop");
            squish = Content.Load<SoundEffect>("Sounds/dp_frogger_squash");
            plunk = Content.Load<SoundEffect>("Sounds/dp_frogger_plunk");
            time = Content.Load<SoundEffect>("Sounds/dp_frogger_time");
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <Summary>
        /// In the update the current game screen is selected and constantly changed if
        /// needed. It also adds code allowing you to exit at any time via the press of 
        /// the escape button. In addition it now plays a sound whenever the timer is 
        /// getting closer to 0, the closer it gets the more often it sounds. 
        /// </Summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {

            switch (currentGameState)
            {
                case GameState.StartPlay:
                    {
                        if (keyClicked(Keys.Down))
                        {
                            currentGameState = GameState.StartHighScores;
                        }
                        if (keyClicked(Keys.Enter))
                        {
                            currentGameState = GameState.Level1;
                        }
                        previousState = Keyboard.GetState();

                        break;
                    }

                case GameState.StartHighScores:
                    {
                        if (keyClicked(Keys.Down))
                        {
                            currentGameState = GameState.StartInstructions;
                        }
                        else if (keyClicked(Keys.Up))
                        {
                            currentGameState = GameState.StartPlay;
                        }
                        else if (keyClicked(Keys.Enter))
                        {
                            currentGameState = GameState.HighScores;
                        }
                        previousState = Keyboard.GetState();

                        break;
                    }

                case GameState.StartInstructions:
                    {
                        if (keyClicked(Keys.Down))
                        {
                            currentGameState = GameState.StartExit;
                        }
                        else if (keyClicked(Keys.Up))
                        {
                            currentGameState = GameState.StartHighScores;
                        }
                        else if (keyClicked(Keys.Enter))
                        {
                            currentGameState = GameState.Instructions;
                        }
                        previousState = Keyboard.GetState();

                        break;
                    }

                case GameState.StartExit:
                    {
                        if (keyClicked(Keys.Up))
                        {
                            currentGameState = GameState.StartInstructions;
                        }
                        else if (Keyboard.GetState().IsKeyDown(Keys.Enter))
                        {
                            Exit();
                        }
                        previousState = Keyboard.GetState();

                        break;
                    }

                case GameState.Instructions:
                    {
                        if (keyClicked(Keys.Enter))
                        {
                            currentGameState = GameState.StartInstructions;
                        }
                        previousState = Keyboard.GetState();

                        break;
                    }

                case GameState.HighScores:
                    {
                        if (keyClicked(Keys.Enter))
                        {
                            currentGameState = GameState.StartHighScores;
                        }
                        previousState = Keyboard.GetState();

                        break;
                    }

                case GameState.Level1:
                    {
                        statechanger = 0;
                        timerCounter += gameTime.ElapsedGameTime.Milliseconds;
                        timerSeconds = (int)(timerCounter / 1000);
                       
                        if (timerSeconds == 60)
                        {
                            timerMinutes = timerMinutes + 1;
                            timerCounter = 0;
                            timerSeconds = 0;
                        }

                        if ((numberLivesRemaining == 0) || (timerMinutes == 3))
                        {
                            currentGameState = GameState.GameLost;
                            timerCounter = 0;
                            timerMinutes = 0;
                            timerSeconds = 0;
                        }
                        if (currentFrogs == 6)
                        {
                            currentGameState = GameState.Level2;
                            timerCounter = 0;
                            timerMinutes = 0;
                            timerSeconds = 0;
                            Collision x = new Collision();
                            x.Frog1Reset();
                            x.Frog2Reset();
                        }
                        else if (Keyboard.GetState().IsKeyDown(Keys.P))
                        {
                            currentGameState = GameState.Pause;
                        }
                       
                        Collision one = new Collision();
                        one.inCollision();
                        one.logCollision();
                        one.frogCollision();
                        
                        switchButton.state();
                        switchButton.initialise();

                        froglvl1.update(gameTime);
                        frog2lvl1.update(gameTime);

                        break;
                    }
                case GameState.Level2:
                    {
                        statechanger = 1;
                        timerCounter += gameTime.ElapsedGameTime.Milliseconds;
                        timerSeconds = (int)(timerCounter / 1000);
 
                        if (timerSeconds >= 60)
                        {
                            timerMinutes++;
                            timerCounter = 0;
                            timerSeconds = 0;
                        }
                        if ((numberLivesRemaining == 0) || (timerMinutes >= 3))
                        {
                            currentGameState = GameState.GameLost;
                            timerCounter = 0;
                            timerMinutes = 0;
                            timerSeconds = 0;
                        
                        }
                        else if (currentFrogs == 12)
                        {
                            currentGameState = GameState.Level3;
                        }
                        else if (Keyboard.GetState().IsKeyDown(Keys.P))
                        {
                            currentGameState = GameState.Pause;
                        }

                        Collision one = new Collision();
                        one.inCollision();
                        one.logCollision();
                        one.frogCollision();
                        
                        switchlvl2.state();
                        switchlvl2.initialise();

                        froglvl2.update(gameTime);
                        frog2lvl2.update(gameTime);

                        break;
                    }
                case GameState.Level3:
                    {
                        statechanger = 2;
                        timerCounter += gameTime.ElapsedGameTime.Milliseconds;
                        timerSeconds = (int)(timerCounter / 1000);
 
                        if (timerSeconds >= 60)
                        {
                            timerMinutes++;
                            timerCounter = 0;
                            timerSeconds = 0;
                        }
                        if ((numberLivesRemaining == 0) || (timerMinutes >= 2))
                        {
                            currentGameState = GameState.GameLost;
                            timerCounter = 0;
                            timerMinutes = 0;
                            timerSeconds = 0;
                        
                        }
                        else if (currentFrogs == 18)
                        {
                            currentGameState = GameState.GameWon;
                        }
                        else if (Keyboard.GetState().IsKeyDown(Keys.P))
                        {
                            currentGameState = GameState.Pause;
                        }

                        Collision one = new Collision();
                        one.inCollision();
                        one.logCollision();
                        one.frogCollision();

                        switchlvl3.state();
                        switchlvl3.initialise();

                        froglvl3.update(gameTime);
                        frog2lvl3.update(gameTime);

                        break;
                    }

                case GameState.Pause:
                    {
                        if (Keyboard.GetState().IsKeyDown(Keys.Enter))
                        {
                            currentGameState = GameState.Level1;
                        }
                        break;
                    }

                case GameState.GameLost:
                    {
                        timerMinutes = 0;
                        timerSeconds = 0;
                        timerCounter = 0;
                        statechanger = 0;
                        numberLivesRemaining = 3;

                        if (keyClicked(Keys.Enter))
                        {
                            currentGameState = GameState.StartPlay;
                            scoreStore = currentFrogs;
                            currentFrogs = 0;
                            Frog.currentFrog = 0;
                            Frog2.currentFrog = 0;
                            froglvl1.tempory();
                            frog2lvl1.tempory();
                        }
                        previousState = Keyboard.GetState();
                        
                        break;
                    }

                case GameState.GameWon:
                    {
                        timerMinutes = 0;
                        timerSeconds = 0;
                        timerCounter = 0;
                        statechanger = 0;
                        numberLivesRemaining = 3;

                        if (keyClicked(Keys.Enter))
                        {
                            currentGameState = GameState.StartPlay;
                            scoreStore = currentFrogs;
                            currentFrogs = 0;
                            Frog.currentFrog = 0;
                            Frog2.currentFrog = 0;
                            froglvl1.tempory();
                            frog2lvl1.tempory();
                        }
                        previousState = Keyboard.GetState();

                        break;
                    }
            }
            if (timerMinutes == 2)
            {
                switch (timerSeconds)
                {
                    case 30:
                        MultiFrogger.time.Play();
                        break;
                    case 45:
                        MultiFrogger.time.Play();
                        break;
                    case 50:
                        MultiFrogger.time.Play();
                        break;
                    case 55:
                        MultiFrogger.time.Play();
                        break;
                }
            }

            // Allows the game to exit
            if ((GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed) || (Keyboard.GetState().IsKeyDown(Keys.Escape)))
            {
                this.Exit();
            }

            base.Update(gameTime);
        }

        /// <Summary>
        /// Draws all of the different game screens and controls how they will 
        /// appear on screen
        /// </Summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            
            switch (currentGameState)
            {
                case GameState.StartPlay:
                        GraphicsDevice.Clear(Color.Green);

                        // Draw text for intro splash screen
                        spriteBatch.Begin();
                        spriteBatch.Draw(startPlay, Vector2.Zero, Color.White);
                        spriteBatch.End();
                        break;
                    

                case GameState.StartHighScores:
                        GraphicsDevice.Clear(Color.Green);

                        // Draw text for intro splash screen
                        spriteBatch.Begin();
                        spriteBatch.Draw(startHighScores, Vector2.Zero, Color.White);
                        spriteBatch.End();

                        break;
                    

                case GameState.StartInstructions:
                    {
                        GraphicsDevice.Clear(Color.Green);

                        // Draw text for intro splash screen
                        spriteBatch.Begin();
                        spriteBatch.Draw(startInstructions, Vector2.Zero, Color.White);
                        spriteBatch.End();
                        break;
                    }

                case GameState.StartExit:
                    {
                        GraphicsDevice.Clear(Color.Green);

                        // Draw text for intro splash screen
                        spriteBatch.Begin();
                        spriteBatch.Draw(startExit, Vector2.Zero, Color.White);
                        spriteBatch.End();
                        break;
                    }

                case GameState.HighScores:
                    {
                        GraphicsDevice.Clear(Color.Maroon);

                        // Draw text for intro splash screen
                        spriteBatch.Begin();

                        text = "USER SCORE";
                        spriteBatch.DrawString(frogsPassed, text, centreString(text, 0), Color.White);

                        text = "Your score: " + scoreStore;
                        spriteBatch.DrawString(frogsPassed, text, centreString(text, 30), Color.White);

                        text = "(Press Enter to return to the menu)";
                        spriteBatch.DrawString(frogsPassed, text, centreString(text, 60), Color.Green);

                        spriteBatch.End();

                        break;
                    }

                case GameState.Instructions:
                    {
                        GraphicsDevice.Clear(Color.Green);

                        // Draw text for intro splash screen
                        spriteBatch.Begin();

                        text = "Welcome to Multi Frogger!";
                        spriteBatch.DrawString(frogsPassed2, text, centreString(text, -120), Color.Black);

                        text = "2 control the frogs, use either the arrow buttons or the \"W\", \"A\", \"S\" or \"D\" buttons";
                        spriteBatch.DrawString(frogsPassed2, text, centreString(text, -90), Color.Black);

                        text = "The aim of each level is to get 6 frogs to the end of the level,";
                        spriteBatch.DrawString(frogsPassed2, text, centreString(text, -60), Color.Black);

                        text = "but you only have 3 lives.";
                        spriteBatch.DrawString(frogsPassed2, text, centreString(text, -30), Color.Black);

                        text = "You are also racing the clock.";
                        spriteBatch.DrawString(frogsPassed2, text, centreString(text, 0), Color.Black);

                        text = "If you have not completed the level in 3 minutes, you will die.";
                        spriteBatch.DrawString(frogsPassed2, text, centreString(text, 30), Color.Black);

                        text = "Press the P button during the level to pause the game.";
                        spriteBatch.DrawString(frogsPassed2, text, centreString(text, 60), Color.Black);

                        text = "Press Escape at any time to exit the game";
                        spriteBatch.DrawString(frogsPassed2, text, centreString(text, 90), Color.Black);

                        text = "Press Enter to return to the Menu";
                        spriteBatch.DrawString(frogsPassed2, text, centreString(text, 120), Color.Black);
                        
                        text = "Remember each player must get 3 frogs each on the lilly pad.";
                        spriteBatch.DrawString(frogsPassed2, text, centreString(text, 150), Color.Black);
                        
                        spriteBatch.End();
                        break;
                    }
                case GameState.Level1:
                    {
                        GraphicsDevice.Clear(Color.White);

                        // Draws the objects onto the screen.
                        spriteBatch.Begin();
                        spriteBatch.Draw(roads, BackgroundRect, Color.White);
                        spriteBatch.Draw(water, waterRect, Color.White);
                        
                        for (int i = 0; i < lillyrect.Length; i++)
                        {
                            spriteBatch.Draw(lilly, lillyrect[i], Color.White);
                        }
                       
                        switch (numberLivesRemaining)
                        {
                            case 1:
                                spriteBatch.Draw(frogLife, new Vector2(200, 10), Color.White);
                                break;
                            case 2:
                                spriteBatch.Draw(frogLife, new Vector2(200, 10), Color.White);
                                spriteBatch.Draw(frogLife, new Vector2(250, 10), Color.White);
                                break;
                            case 3:
                                spriteBatch.Draw(frogLife, new Vector2(200, 10), Color.White);
                                spriteBatch.Draw(frogLife, new Vector2(250, 10), Color.White);
                                spriteBatch.Draw(frogLife, new Vector2(300, 10), Color.White);
                                break;
                        }
                        
                        
                        switchButton.Draw(this.spriteBatch);
                        firstLog.Draw (this.spriteBatch);
                        secondLog.Draw(this.spriteBatch);
                        thirdLog.Draw (this.spriteBatch);
                        froglvl1.Draw    (this.spriteBatch);
                        frog2lvl1.Draw     (this.spriteBatch);
                        Bus.Draw     (this.spriteBatch);
                        Car.Draw     (this.spriteBatch);
                        Van.Draw    (this.spriteBatch);
                        
                        
                        // Draw fonts
                        spriteBatch.DrawString(frogsPassed, "Frogs: " + currentFrogs,
                                              new Vector2(10, 10), Color.DarkGreen,
                                              0, Vector2.Zero, 1, SpriteEffects.None, 1);

                        spriteBatch.DrawString(frogsPassed, "Time: " + timerMinutes,
                                               new Vector2(100, 10), Color.DarkGreen,
                                               0, Vector2.Zero, 1, SpriteEffects.None, 1);

                        spriteBatch.DrawString(frogsPassed, ". " + (timerSeconds),
                                               new Vector2(165, 10), Color.DarkGreen,
                                               0, Vector2.Zero, 1, SpriteEffects.None, 1);

                        spriteBatch.End();

                        break;
                    }
                case GameState.Level2:
                    {
                        GraphicsDevice.Clear(Color.White);

                        // Draws the objects onto the screen.
                        spriteBatch.Begin();
                        spriteBatch.Draw(roads, BackgroundRect, Color.White);
                        spriteBatch.Draw(water, waterRect, Color.White);
                       
                        for (int i = 0; i < lillyrect.Length; i++)
                        {
                            spriteBatch.Draw(lilly, lillyrect[i], Color.White);
                        }

                        switch (numberLivesRemaining)
                        {
                            case 1:
                                spriteBatch.Draw(frogLife, new Vector2(200, 10), Color.White);
                                break;
                            case 2:
                                spriteBatch.Draw(frogLife, new Vector2(200, 10), Color.White);
                                spriteBatch.Draw(frogLife, new Vector2(250, 10), Color.White);
                                break;
                            case 3:
                                spriteBatch.Draw(frogLife, new Vector2(200, 10), Color.White);
                                spriteBatch.Draw(frogLife, new Vector2(250, 10), Color.White);
                                spriteBatch.Draw(frogLife, new Vector2(300, 10), Color.White);
                                break;
                        }

                        switchlvl2.Draw(this.spriteBatch);
                        firstLog.Draw(this.spriteBatch);
                        secondLog.Draw(this.spriteBatch);
                        thirdLog.Draw(this.spriteBatch);
                        froglvl2.Draw(this.spriteBatch);
                        frog2lvl2.Draw(this.spriteBatch);
                        Bus.Draw(this.spriteBatch);
                        Car.Draw(this.spriteBatch);
                        Van.Draw(this.spriteBatch);


                        // Draw fonts
                        spriteBatch.DrawString(frogsPassed, "Frogs: " + currentFrogs,
                                              new Vector2(10, 10), Color.DarkGreen,
                                              0, Vector2.Zero, 1, SpriteEffects.None, 1);

                        spriteBatch.DrawString(frogsPassed, "Time: " + timerMinutes,
                                               new Vector2(100, 10), Color.DarkGreen,
                                               0, Vector2.Zero, 1, SpriteEffects.None, 1);

                        spriteBatch.DrawString(frogsPassed, ". " + (timerSeconds),
                                               new Vector2(165, 10), Color.DarkGreen,
                                               0, Vector2.Zero, 1, SpriteEffects.None, 1);
                        spriteBatch.End();

                        break;
                    }
                case GameState.Level3:
                    {
                        GraphicsDevice.Clear(Color.White);

                        // Draws the objects onto the screen.
                        spriteBatch.Begin();
                        spriteBatch.Draw(roads, BackgroundRect, Color.White);
                        spriteBatch.Draw(water, waterRect, Color.White);
                        
                        for (int i = 0; i < lillyrect.Length; i++)
                        {
                            spriteBatch.Draw(lilly, lillyrect[i], Color.White);
                        }

                        switch (numberLivesRemaining)
                        {
                            case 1:
                                spriteBatch.Draw(frogLife, new Vector2(200, 10), Color.White);
                                break;
                            case 2:
                                spriteBatch.Draw(frogLife, new Vector2(200, 10), Color.White);
                                spriteBatch.Draw(frogLife, new Vector2(250, 10), Color.White);
                                break;
                            case 3:
                                spriteBatch.Draw(frogLife, new Vector2(200, 10), Color.White);
                                spriteBatch.Draw(frogLife, new Vector2(250, 10), Color.White);
                                spriteBatch.Draw(frogLife, new Vector2(300, 10), Color.White);
                                break;
                        }

                        switchlvl3.Draw(this.spriteBatch);
                        firstLog.Draw(this.spriteBatch);
                        secondLog.Draw(this.spriteBatch);
                        thirdLog.Draw(this.spriteBatch);
                        froglvl3.Draw(this.spriteBatch);
                        frog2lvl3.Draw(this.spriteBatch);
                        Bus.Draw(this.spriteBatch);
                        Car.Draw(this.spriteBatch);
                        Van.Draw(this.spriteBatch);


                        // Draw fonts
                        spriteBatch.DrawString(frogsPassed, "Frogs: " + currentFrogs,
                                              new Vector2(10, 10), Color.DarkGreen,
                                              0, Vector2.Zero, 1, SpriteEffects.None, 1);

                        spriteBatch.DrawString(frogsPassed, "Time: " + timerMinutes,
                                               new Vector2(100, 10), Color.DarkGreen,
                                               0, Vector2.Zero, 1, SpriteEffects.None, 1);

                        spriteBatch.DrawString(frogsPassed, ". " + (timerSeconds),
                                               new Vector2(165, 10), Color.DarkGreen,
                                               0, Vector2.Zero, 1, SpriteEffects.None, 1);
                        spriteBatch.End();

                        break;
                    }
                case GameState.Pause:
                    {
                        GraphicsDevice.Clear(Color.White);

                        // Draw text for intro splash screen
                        spriteBatch.Begin();
                        spriteBatch.Draw(winlose, Vector2.Zero, Color.White);

                        text = "PAUSE";
                        spriteBatch.DrawString(frogsPassed2, text, centreString(text,180), Color.Black);

                        text = "Press Enter to continue";
                        spriteBatch.DrawString(frogsPassed2, text, centreString(text, 210), Color.Black);

                        text = "Press Escape at any time to exit the game";
                        spriteBatch.DrawString(frogsPassed2, text, centreString(text, 240), Color.Black);

                        spriteBatch.End();
                        break;
                    }

                case GameState.GameLost:
                    {
                        GraphicsDevice.Clear(Color.Black);
                        
                        //Draw game over text
                        spriteBatch.Begin();

                        spriteBatch.Draw(winlose, Vector2.Zero, Color.White);

                        text = "You Lose";
                        spriteBatch.DrawString(frogsPassed, text, centreString(text, 180), Color.Black);

                        text = "Your score: " + currentFrogs;
                        spriteBatch.DrawString(frogsPassed, text, centreString(text, 210), Color.Black);

                        text = "(Press Enter to return to the main menu)";
                        spriteBatch.DrawString(frogsPassed, text, centreString(text, 240), Color.Green);

                        if (currentFrogs > 6)
                        {
                            currentFrogs = 6;
                        }

                        spriteBatch.End();
                        break;
                    }

                case GameState.GameWon:
                    {
                        GraphicsDevice.Clear(Color.Green);

                        //Draw game over text
                        spriteBatch.Begin();

                        spriteBatch.Draw(winlose, Vector2.Zero, Color.White);

                        text = "You Won!";
                        spriteBatch.DrawString(frogsPassed, text, centreString(text, 180), Color.Black);

                        text = "Your score: " + currentFrogs;
                        spriteBatch.DrawString(frogsPassed, text, centreString(text, 210), Color.Black);

                        text = "(Press Enter to return to the main menu  )";
                        spriteBatch.DrawString(frogsPassed, text, centreString(text, 240), Color.Green);

                        if (currentFrogs > 6)
                        {
                            currentFrogs = 6;
                        }

                        spriteBatch.End();
                        break;
                    }
            }

            base.Draw(gameTime);

        }

        /// <Summary>
        /// This method returns the key pressed on the keyboard and the 
        /// key that was previously pressed on it.
        /// </Summary>
        /// <param name="key"></param>
        /// <returns></returns>
        protected bool keyClicked(Keys key)
        {
            return previousState.IsKeyUp(key) && Keyboard.GetState().IsKeyDown(key);
        }

        /// <Summary>
        /// This method gets a string and an int passed in. The string being 
        /// passed in is whats to be outputed onto the screen and the int is 
        /// a value that alters the y co-ordinate of the text when it is being 
        /// writen on the screen. The method works out how to display the code
        /// in the centre of the screen. 
        /// </Summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <returns></returns>
        public Vector2 centreString(String x, int y)
        {
            Vector2 textPosition = new Vector2((Window.ClientBounds.Width / 2) - (frogsPassed.MeasureString(x).X / 2), (Window.ClientBounds.Height / 2) - (frogsPassed.MeasureString(x).Y / 2)+ y);
            return textPosition;
        }
    }
}
