﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace MultiFrogger
{
    /// <Summary>
    /// This class controls whats happening in the second lane. This class
    /// controls the movement of a second bus from left to right across the screen. 
    /// </Summary>
    class Lane2
    {
        /// <Summary>
        /// The first variable declared is an array of Rectangles. Which are
        /// used to determine the position of each of the buses on lane 2 in 
        /// the game. The other variable declared here is the a texture2D one
        /// which allows me to draw the sprite image.
        /// </Summary>
        public static Rectangle[] position = new Rectangle[7];        
        private Texture2D Vechile;

        /// <Summary>
        /// This method instigates a random variable where random numbers
        /// are able to be called.
        /// </Summary>
        /// <returns></returns>
        public static int Randomise()
        {
            int b = 0;
            Random r = new Random();
            b = r.Next(200, 440);
            return b;
            
        }

        /// <Summary>
        /// This method accepts in the four intitial parameters getting passed into 
        /// it by the MultiFrogger method initialise. Here the game loops through 
        /// the vechiles positions in the class and adds on the new random number 
        /// to the previous positions x co-ordinate. This then allows for a space 
        /// between the vehicles allowing the frog space to move around.
        /// </Summary>
        /// <param name="i"></param>
        /// <param name="j"></param>
        /// <param name="x"></param>
        /// <param name="y"></param>
        public void Position(int i, int j, int x, int y)
        {
            position[0] = new Rectangle(i, j, x, y);
            
            for (int n = 0; n < position.Length; n++)
            {
                if(n<6)
                {
                position[n+1] = new Rectangle((position[n].X + Randomise()),j, x, y);
                }
            }
        }

        /// <Summary>
        /// This method loads in the sprite image to be used in this class
        /// </Summary>
        /// <param name="theContentManager"></param>
        /// <param name="theAssetName"></param>
        public void LoadContent(ContentManager theContentManager, string theAssetName)
        {
            Vechile = theContentManager.Load<Texture2D>(theAssetName);
        }

        /// <Summary>
        /// This method draws out each of the image by using a for loop and 
        /// looping through the array of the bus positions. The bus position
        /// also gets incremented by 1 here, so that it appears that its moving
        /// across the screen. Also if a bus achieves an x position greater 
        /// than 1920 then the buses x position will be reset to -200.
        /// </Summary>
        /// <param name="theSpriteBatch"></param>
        public void Draw(SpriteBatch theSpriteBatch)
        {
            for (int j = 0; j < position.Length; j++)
            {
                position[j].X = position[j].X + 1;
                theSpriteBatch.Draw(Vechile, position[j], Color.White);
                if (position[j].X == 1920)
                {
                    position[j].X = -200;
                }
            }
        }
    }
}
