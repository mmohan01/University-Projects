﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace MultiFrogger
{
    /// <Summary>
    /// This class controls whats happening in the first lane. This class
    /// controls the movement of the bus from right to left across the screen. 
    /// </Summary>
    class Lane1
    {
        /// <Summary>
        /// The first variable declared is an array of Rectangles. Which are
        /// used to determine the position of each of the buses on lane 1 in 
        /// the game. The other variable declared here is the a texture2D one
        /// which allows me to draw the sprite image.
        /// </Summary>
        public static Rectangle[] position = new Rectangle[7];

        private Texture2D Vechile;

        /// <Summary>
        /// This method allowed us to pass in the starting values of the Rectangles
        /// along with the size that they are to be drew. A random function is declared 
        /// and created allowing me to call a random number. The value which the random
        /// number has been is already set to be between to preset values. The random 
        /// values are then used to create the position on the x axis of the next Rectangle
        /// to be drew in the sequence
        /// </Summary>
        /// <param name="i"></param>
        /// <param name="j"></param>
        /// <param name="x"></param>
        /// <param name="y"></param>
        public void Position(int i, int j, int x, int y)
        {
            Random r = new Random();
            int b = r.Next(200, 440);
            int c = r.Next(200, 440);
            int d = r.Next(200, 440);
            int e = r.Next(200, 440);
            int f = r.Next(200, 440);

            position[0] = new Rectangle(i, j, x, y);
            position[1] = new Rectangle(i + b, j, x, y);
            position[2] = new Rectangle(i + b + c, j, x, y);
            position[3] = new Rectangle(i + b + c + d, j, x, y);
            position[4] = new Rectangle(i + b + c + d + e, j, x, y);
            position[5] = new Rectangle(i + b + c + d + e + f, j, x, y);

        }

        /// <Summary>
        /// This method loads in the sprite image to be used in this class
        /// </Summary>
        /// <param name="theContentManager"></param>
        /// <param name="theAssetName"></param>
        public void LoadContent(ContentManager theContentManager, string theAssetName)
        {
            Vechile = theContentManager.Load<Texture2D>(theAssetName);
        }

        /// <Summary>
        /// This method draws out each of the image by using a for loop and 
        /// looping through the array of the bus positions. The bus position
        /// also gets decremented by 2 here, so that it appears that its moving
        /// across the screen. Also if a bus achieves an x position of less 
        /// than - 200 then the buses x position will be reset to 1920.
        /// </Summary>
        /// <param name="theSpriteBatch"></param>
        public void Draw(SpriteBatch theSpriteBatch)
        {
            for (int j = 0; j < position.Length; j++)
            {
                position[j].X = position[j].X - 2;
                theSpriteBatch.Draw(Vechile, position[j], Color.White);
                if (position[j].X == -200)
                {
                    position[j].X = 1920;
                }
            }

        }
    }
}
