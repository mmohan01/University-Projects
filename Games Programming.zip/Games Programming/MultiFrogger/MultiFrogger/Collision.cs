﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace MultiFrogger
{
    /// <Summary>
    /// This class is where the different kinds of collisions are handled within the game.
    /// </Summary>
    class Collision
    {
        /// <Summary>
        /// These are the different variables being declared and used in this class. The frameSize
        /// variable is used for defing the size of the sprite being drew from the spritesheet. 
        /// The windowHeight is the height of the screen resolution and the windowWidth is the width
        /// of the screen resolution. The variables logIntersectFrog1 and logIntersectFrog2 are used
        /// to determine whether or not a collision taking place between a log and a frog is true.
        /// logIntersectfrog1 controls this for the first frog and logIntersectfrog2 for the second one.
        /// </Summary>
        Point frameSize = new Point(40, 50);
        int windowHeight = 780;
        int windowWidth = 1360;
        public bool logIntersectfrog1 = false;
        public bool logIntersectfrog2 = false;
        

        /// <Summary>
        /// The incollision Method is a method used for detecting whether or not a collision has
        /// taken place between one of the frogs and one of the vechiles. This works by looping 
        /// through the array of vechiles in each of the three lane classes checking to see if 
        /// either of the frogs collision Rectangles come into contact with them.
        /// </Summary>

        public void inCollision()
        {
            for (int i = 0; i < Lane2.position.Length; i++)
            {
                if (Frog.collisionRect.Intersects(Lane2.position[i])|| Frog.collisionRect.Intersects(Lane3.position[i]) || Frog.collisionRect.Intersects(Lane1.position[i]))
                {
                    Frog1Reset();
                    MultiFrogger.squish.Play();
                    MultiFrogger.numberLivesRemaining--;
                }
                if (Frog2.collisionRect.Intersects(Lane2.position[i]) || Frog2.collisionRect.Intersects(Lane3.position[i]) || Frog2.collisionRect.Intersects(Lane1.position[i]))
                {
                    Frog2Reset();
                    MultiFrogger.squish.Play();
                    MultiFrogger.numberLivesRemaining--;
                }
            }
        }
        /// <Summary>
        /// This method loops through each of the positions of each log in the three different log
        /// classes. As it loops through it checks for a collision between the logs and the collision 
        /// Rectangle of the frog. If a collision is detected, the frogs position gets attached to  
        /// the log. As the frogs position is attached to the log the frog will move in the same 
        /// direction as the log is moving in. However the log will only move if the switch is pressed. 
        /// This is controlled by the logSwitch boolean. Whenever a frog is over a switch this value 
        /// becomes true and allows the logs to move. In the class is a method for resetting both frogs 
        /// position, if they move off screen on a log. Also in this class is the statement that will 
        /// reset the frog if it collides with the water area.
        /// </Summary>
        public void logCollision()
        {
                for (int j = 0; j < Log1.position.Length; j++)
                {
                    if (Frog.collisionRect.Intersects(Log1.collision[j]))
                    {
                        {
                            logIntersectfrog1 = true;
                            Frog.position[Frog.currentFrog].Y = Log1.position[j].Y;
                            Frog.collisionRect.Y = Log1.position[j].Y + 10;
                            if (Frog.position[Frog.currentFrog].Y == (Log1.position[j].Y))
                            {
                                if (Switch.logSwitch == true )
                                {
                                    Frog.position[Frog.currentFrog].X = Frog.position[Frog.currentFrog].X - 1;
                                    Frog.collisionRect.X = Frog.collisionRect.X - 1;
                                }
                            }
                        }
                    }

                    else if (Frog.collisionRect.Intersects(Log3.collision[j]))
                    {
                        {
                            logIntersectfrog1 = true;
                            Frog.position[Frog.currentFrog].Y = Log3.position[j].Y;
                            Frog.collisionRect.Y = Log3.position[j].Y + 10;
                            if (Frog.position[Frog.currentFrog].Y == (Log3.position[j].Y))
                            {
                                if (Switch.logSwitch == true)
                                {
                                    Frog.position[Frog.currentFrog].X = Frog.position[Frog.currentFrog].X - 1;
                                    Frog.collisionRect.X = Frog.collisionRect.X - 1;
                                }
                            }
                        }
                    }
                    else if (Frog.collisionRect.Intersects(Log2.collision[j]))
                    {
                        {
                            logIntersectfrog1 = true;
                            Frog.position[Frog.currentFrog].Y = Log2.position[j].Y ;
                            Frog.collisionRect.Y = Log2.position[j].Y + 10;
                            if (Frog.position[Frog.currentFrog].Y == (Log2.position[j].Y))
                            {
                                if (Switch.logSwitch == true)
                                {
                                    Frog.position[Frog.currentFrog].X = Frog.position[Frog.currentFrog].X + 2;
                                    Frog.collisionRect.X = Frog.collisionRect.X + 2;
                                }
                            }
                        }
                    }
                    else if (Frog2.collisionRect.Intersects(Log1.collision[j]))
                    {
                        {
                            logIntersectfrog2 = true;
                            Frog2.position[Frog2.currentFrog].Y = Log1.position[j].Y;
                            Frog2.collisionRect.Y = Log1.position[j].Y + 10;
                            if (Frog2.position[Frog2.currentFrog].Y == (Log1.position[j].Y))
                            {
                                if (Switch.logSwitch == true)
                                {
                                    Frog2.position[Frog2.currentFrog].X = Frog2.position[Frog2.currentFrog].X - 1;
                                    Frog2.collisionRect.X = Frog2.collisionRect.X - 1;
                                }
                            }
                        }
                    }
                    else if (Frog2.collisionRect.Intersects(Log3.collision[j]))
                    {
                        {
                            logIntersectfrog2 = true;
                            Frog2.position[Frog2.currentFrog].Y = Log3.position[j].Y;
                            Frog2.collisionRect.Y = Log3.position[j].Y + 10;
                            if (Frog2.position[Frog2.currentFrog].Y == (Log3.position[j].Y))
                            {
                                if (Switch.logSwitch == true)
                                {
                                    Frog2.position[Frog2.currentFrog].X = Frog2.position[Frog2.currentFrog].X - 1;
                                    Frog2.collisionRect.X = Frog2.collisionRect.X - 1;
                                }
                            }
                        }
                    }
                    else if (Frog2.collisionRect.Intersects(Log2.collision[j]))
                    {
                        {
                            logIntersectfrog2 = true;
                            Frog2.position[Frog2.currentFrog].Y = Log2.position[j].Y;
                            Frog2.collisionRect.Y = Log2.position[j].Y + 10;
                            if (Frog2.position[Frog2.currentFrog].Y == (Log2.position[j].Y))
                            {
                                if (Switch.logSwitch == true)
                                {
                                    Frog2.position[Frog2.currentFrog].X = Frog2.position[Frog2.currentFrog].X + 2;
                                    Frog2.collisionRect.X = Frog2.collisionRect.X + 2;
                                }
                            }
                        }
                    }
                }

                // The if statements controlling the water collision. If a frog intersects the
                // water without being on a log, it gets reset to its starting position, a sound
                // plays and the players life gets decremented by one.
                if (logIntersectfrog1 == false)
                {
                    if (Frog.collisionRect.Intersects(MultiFrogger.waterRect))
                    {
                        Frog1Reset();
                        MultiFrogger.plunk.Play();
                        MultiFrogger.numberLivesRemaining--;
                    }
                }
                if (logIntersectfrog2 == false)
                {
                    if (Frog2.collisionRect.Intersects(MultiFrogger.waterRect))
                    {
                        Frog2Reset();
                        MultiFrogger.plunk.Play();
                        MultiFrogger.numberLivesRemaining--;
                    }
                }

                // If statements so that if the frog goes off the screen whilst on a log
                // then it will get reset to its starting position and lose a life. 
                if (Frog.position[Frog.currentFrog].X < - 50 || Frog.position[Frog.currentFrog].X > 1400)
                {
                    Frog1Reset();
                    MultiFrogger.numberLivesRemaining--;
                }
                if (Frog2.position[Frog2.currentFrog].X < -60 || Frog2.position[Frog2.currentFrog].X > 1400)
                {
                    Frog2Reset();
                    MultiFrogger.numberLivesRemaining--;
                }
            }


        /// <Summary>
        /// This method is in place to control what happens whenthe two frogs collide. The frogs 
        /// will get reset to their starting position and the players will lose one life. 
        /// </Summary>
        public void frogCollision()
        {
            if(Frog.collisionRect.Intersects(Frog2.collisionRect))
            {
                Frog1Reset();
                Frog2Reset();
                MultiFrogger.numberLivesRemaining--;
            }
        }

        /// <Summary>
        /// This method will set the respawn point of the first frog. It will reset both the 
        /// Rectangle which is drawing the frog image and the Rectangle which collisions are
        /// being checked for in. 
        /// </Summary>
        public void Frog1Reset()
        {
            Frog.position[Frog.currentFrog] = new Rectangle(((windowWidth * 3 / 4) - (frameSize.X / 2)), (windowHeight - frameSize.Y), 50, 50);
            Frog.collisionRect = new Rectangle(((windowWidth * 3 / 4) - (frameSize.X / 2)) + 13, (windowHeight - frameSize.Y) + 10, 20, 20);
        }

        /// <Summary>
        /// This method will set the respawn point of the first frog. It will reset both the 
        /// Rectangle which is drawing the frog image and the Rectangle which collisions are
        /// being checked for in. 
        /// </Summary>
        public void Frog2Reset()
        {
            Frog2.position[Frog2.currentFrog] = new Rectangle(((windowWidth / 4) - (frameSize.X / 2)), (windowHeight - frameSize.Y), 50, 50);
            Frog2.collisionRect = new Rectangle(((windowWidth / 4) - (frameSize.X / 2)) + 13, (windowHeight - frameSize.Y) + 10, 20, 20);
        }

        }

    }

