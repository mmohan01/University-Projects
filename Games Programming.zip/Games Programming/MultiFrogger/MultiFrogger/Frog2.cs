﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace MultiFrogger
{
    /// <Summary>
    /// This class is where the first frog is placed. It is where the frogs movement will
    /// update and its animation will take place. Also controlled here will be the frogs 
    /// landing on the lilly pads. 
    /// </Summary>
    class Frog2
    {
        /// <Summary>
        /// This is where the majority of variables are getting declared for this class. 
        /// The texture2D frog is there so the frog can be drew and the position Rectangle
        /// array will control the positin that this will be drew. This was done in an array
        /// so that the frog which landed on the lilly pad could be drew and the frog which
        /// is currently being controlled by the player can move around. The integer currentFrog
        /// controls which frog in the array is currently being moved around. The int temp 
        /// and max indicate the frogs which are being drew on the lilly pads. The windowHeight 
        /// is the height of the screen resolution and the windowWidth is the width of the 
        /// screen resolution. The timeSinceLastFrame float controls the time since the 
        /// last animation frame of the frog played. The frameSixe controls the size of 
        /// the frame to be drew from the sprite sheet. currentFrame controls the starting 
        /// point of the draw on the sprite sheet. sheetSize controls the amount of animation
        /// across and down on the sprite sheet. previousState gets the last state pressed 
        /// on the keyboard. the jump bool variable state whether movement will or will not 
        /// take place. If it is true some sort of movement will take place. An instance of 
        /// the collision class is also present here to allow us to call the frog reset 
        /// position in later methods
        /// </Summary>
        private Texture2D frog;

        public static Rectangle[] position = new Rectangle[7];
        public static Rectangle collisionRect;
        Rectangle stillFrame, spriteFrame;

        public static int currentFrog = 0;
        int temp;
        int max;
        int y = 0;
        int x = 0;
        int windowHeight = 780;
        int windowWidth = 1360;
        float timeSinceLastFrame = 0;

        Point frameSize = new Point(40, 50);
        Point currentFrame = new Point(0, 0);
        Point sheetSize = new Point(4, 1);

        KeyboardState previousState;
        bool jump;
        Collision respawn = new Collision();

        /// <Summary>
        /// This class derives what the temp and max values should be. This is done
        /// so that the game knows which of the frogs it should be drawing on the lilly 
        /// pad for each level. Also in this class we call our reset method in the 
        /// collision class so that the frogs position is reset to its default spawn 
        /// point at the start of the level.
        /// </Summary>
        public void tempory()
        {
            temp = currentFrog;
            max = currentFrog + 2;
            respawn.Frog2Reset();
        }

        /// <Summary>
        /// This method sets the position of the frog at the start of the game 
        /// and also calls the tempory method so that the temp and max are 
        /// initialised for the first time at the start of the game.
        /// </Summary>
        public void initialise()
        {
            respawn.Frog2Reset();
            tempory();
        }

        /// <Summary>
        /// This method passes in two parameters when it is called. Theses are gametime
        /// and millisecondsPerFrame. The gameTime parameter passes in the current state
        /// of the frog. The millisecondsPerFrame controls how fast the animation occurs. 
        /// If the boolean jump is true it tells the frog to go throught the sprite sheet
        /// animation sequence. At the end of the sequence it will reset the jump boolean
        /// to false to stop the animation and to allow it to be seen again later.
        /// </Summary>
        /// <param name="gameTime"></param>
        /// <param name="millisecondsPerFrame"></param>
        public virtual void Animate(GameTime gameTime, float millisecondsPerFrame)
        {
            //Update animation frame
            if (jump)
            {
                timeSinceLastFrame += gameTime.ElapsedGameTime.Milliseconds;
                if (timeSinceLastFrame > millisecondsPerFrame)
                {
                    timeSinceLastFrame = 0;
                    ++currentFrame.X;
                    if (currentFrame.X > sheetSize.X)
                    {
                        currentFrame.X = 0;
                        ++currentFrame.Y;
                        if (currentFrame.Y > sheetSize.Y)
                        {
                            currentFrame.Y = 0;
                            jump = false;
                        }
                    }
                }

            }
        }

        /// <Summary>
        /// This method loads in the image passed into it by the loadContent method in the 
        /// Multifrogger class. The Multifrogger class will pass in the content manager which
        /// controls the sprite images and the name of the sprite that is to be drawn.
        /// </Summary>
        /// <param name="theContentManager"></param>
        /// <param name="theAssetName"></param>
        public void LoadContent(ContentManager theContentManager, string theAssetName)
        {
            frog = theContentManager.Load<Texture2D>(theAssetName);
        }

        /// <Summary>
        /// The update method in the frog tells it when to move around and in
        /// which direction to move in. Also whenever it moves a sound will be 
        /// played. In this method are if statements telling the game which 
        /// control input method to use and whether or not the frog is allowed 
        /// to move in the game at all. It is also where the game is told to 
        /// run the animate method for the frog. The screen boundaries are also
        /// controlled in here. It also controls whether a frog has entered a 
        /// lilly pad at the end or not. 
        /// </Summary>
        /// <param name="gameTime"></param>
        public void update(GameTime gameTime)
        {
            // this if statement controls whether the frog moves in according to
            // the level 2 switch.
            if (Switchlvl2.frogmovement2 == 0)
            {
                // this if statement controls whether the frog moves in according to
                // the level 3 switch.
                if (Switchlvl3.frogmovement2 == 0) 
                {
                    // if statement controlling which control method should be used
                    if (Switchlvl3.controls == 0 || Switchlvl3.controls == 2 || Switchlvl3.controls == 4 || Switchlvl3.controls == 6)
                    {
                        if ((keyClicked(Keys.A)))
                        {
                            if (!jump)
                            {
                                jump = true;
                                MultiFrogger.hop.Play();
                                position[currentFrog].X -= frameSize.X;
                                collisionRect.X -= frameSize.X;
                            }
                        }
                        if ((keyClicked(Keys.D)))
                        {
                            if (!jump)
                            {
                                jump = true;
                                MultiFrogger.hop.Play();
                                position[currentFrog].X += frameSize.X;
                                collisionRect.X += frameSize.X;
                            }
                        }
                        if ((keyClicked(Keys.W)))
                        {
                            if (!jump)
                            {
                                jump = true;
                                MultiFrogger.hop.Play();
                                position[currentFrog].Y -= frameSize.Y;
                                collisionRect.Y -= frameSize.Y;
                            }
                        }
                        if ((keyClicked(Keys.S)))
                        {
                            if (!jump)
                            {
                                jump = true;
                                MultiFrogger.hop.Play();
                                position[currentFrog].Y += frameSize.Y;
                                collisionRect.Y += frameSize.Y;
                            }
                        }
                    }
                    // if statement controlling which control method should be used
                    if (Switchlvl3.controls == 1 || Switchlvl3.controls == 3 || Switchlvl3.controls == 5)
                    {
                        if ((keyClicked(Keys.D)))
                        {
                            if (!jump)
                            {
                                jump = true;
                                MultiFrogger.hop.Play();
                                position[currentFrog].X -= frameSize.X;
                                collisionRect.X -= frameSize.X;
                            }
                        }
                        if ((keyClicked(Keys.A)))
                        {
                            if (!jump)
                            {
                                jump = true;
                                MultiFrogger.hop.Play();
                                position[currentFrog].X += frameSize.X;
                                collisionRect.X += frameSize.X;
                            }
                        }
                        if ((keyClicked(Keys.S)))
                        {
                            if (!jump)
                            {
                                jump = true;
                                MultiFrogger.hop.Play();
                                position[currentFrog].Y -= frameSize.Y;
                                collisionRect.Y -= frameSize.Y;
                            }
                        }
                        if ((keyClicked(Keys.W)))
                        {
                            if (!jump)
                            {
                                jump = true;
                                MultiFrogger.hop.Play();
                                position[currentFrog].Y += frameSize.Y;
                                collisionRect.Y += frameSize.Y;
                            }
                        }
                    }
                }
            }

            // calls on the frogs animation
            Animate(gameTime, 15);

            // controls the boundaries of the frog on screen
            if (position[currentFrog].Y > 300)
            {
                if (position[currentFrog].X < 0)
                    position[currentFrog].X = 0;
                if (position[currentFrog].Y < 0)
                    position[currentFrog].Y = 0;
                if (position[currentFrog].X > windowWidth - frameSize.X)
                    position[currentFrog].X = windowWidth - frameSize.X;
                if (position[currentFrog].Y > windowHeight - frameSize.Y)
                    position[currentFrog].Y = windowHeight - frameSize.Y;
            }

            // controls the landing of the frog on a lillypad. Will set the position
            // of the frog onto a lilly pad and add a point to the currentFrogs, in the 
            // MultiFrogger class. Also allows the switch position to change once it has
            // landed on a lilly
            for (int i = 0; i < MultiFrogger.lillyrect.Length; i++)
            {
                if (position[currentFrog].Intersects(MultiFrogger.lillyrect[i]))
                {
                    position[currentFrog].Y = MultiFrogger.lillyrect[i].Y + 30;
                    position[currentFrog].X = MultiFrogger.lillyrect[i].X + 25;

                    Switchlvl2.frogmovement = 0;
                    Switchlvl2.frogmovement2 = 0;
                    Switchlvl3.frogmovement = 0;
                    Switchlvl3.frogmovement2 = 0;

                    if (currentFrog <= max)
                    {
                        MultiFrogger.currentFrogs++;
                    }
                    if (MultiFrogger.statechanger == 0)
                    {
                        Switch.switchPlace++;
                    }
                    else if (MultiFrogger.statechanger == 1)
                    {
                        Switchlvl2.switchPlace++;
                        Switchlvl2.change = 0;
                    }
                    else if (MultiFrogger.statechanger == 2)
                    {
                        Switchlvl3.switchPlace++;
                        Switchlvl3.change = 0;
                    }

                    currentFrog++;
                    respawn.Frog2Reset();
                }
            }
            previousState = Keyboard.GetState();
        }

        /// <Summary>
        /// This method draws out the sprite batch. This method also detetmines the 
        /// sprites which are meant to be drawn on screen at one time. 
        /// </Summary>
        /// <param name="spriteBatch"></param>
        public void Draw(SpriteBatch spriteBatch)
        {
            spriteFrame = new Rectangle(currentFrame.X * frameSize.X, currentFrame.Y * frameSize.Y, frameSize.X, frameSize.Y);
            stillFrame = new Rectangle(0, 0, 40, 50);

            if (y == 0)
            {
                if ((MultiFrogger.currentFrogs == 6 && MultiFrogger.statechanger == 1))
                {
                    tempory();
                    y = 1;
                }
            }
            if (x == 0)
            {
                if ((MultiFrogger.currentFrogs == 12 && MultiFrogger.statechanger == 2))
                {
                    tempory();
                    x = 1;
                }
            }
            if (temp == max - 2)
            {
                spriteBatch.Draw(frog, position[temp], stillFrame, Color.White);
                spriteBatch.Draw(frog, position[currentFrog], spriteFrame, Color.White);
            }
            else if (temp == max - 1)
            {
                spriteBatch.Draw(frog, position[temp], stillFrame, Color.White);
                spriteBatch.Draw(frog, position[temp + 1], stillFrame, Color.White);
                spriteBatch.Draw(frog, position[currentFrog], spriteFrame, Color.White);
            }
            else if (temp == max)
            {
                spriteBatch.Draw(frog, position[temp], stillFrame, Color.White);
                spriteBatch.Draw(frog, position[temp + 1], stillFrame, Color.White);
                spriteBatch.Draw(frog, position[temp + 2], stillFrame, Color.White);
                spriteBatch.Draw(frog, position[currentFrog], spriteFrame, Color.White);
            }
            if (currentFrog >= max)
            {
                spriteBatch.Draw(frog, position[temp], stillFrame, Color.White);
                spriteBatch.Draw(frog, position[temp + 1], stillFrame, Color.White);
                spriteBatch.Draw(frog, position[temp + 2], stillFrame, Color.White);
                spriteBatch.Draw(frog, position[currentFrog], spriteFrame, Color.White);

            }
        }

        /// <Summary>
        /// This method returns the key pressed on the keyboard and the 
        /// key that was previously pressed on it.
        /// </Summary>
        /// <param name="key"></param>
        /// <returns></returns>
        protected bool keyClicked(Keys key)
        {
            return previousState.IsKeyUp(key) && Keyboard.GetState().IsKeyDown(key);
        }
    }
}