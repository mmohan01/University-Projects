﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace MultiFrogger
{
    class FrogDistance
    {
        Point frameSize = new Point(40, 50);
        int windowHeight = 780;
        int windowWidth = 1360;

        public void distance()
        {

            int X = Frog.position[Frog.currentFrog].X - Frog2.position[Frog2.currentFrog].X;
            int Y = Frog.position[Frog.currentFrog].Y - Frog2.position[Frog2.currentFrog].Y;

            float z = (float)Math.Sqrt((X * X) + (Y * Y));

            if (z >= 700)
            {
                Frog.position[Frog.currentFrog] = new Rectangle(((windowWidth * 3 / 4) - (frameSize.X / 2)), (windowHeight - frameSize.Y), 50, 50);
                Frog.collisionRect = new Rectangle(((windowWidth * 3 / 4) - (frameSize.X / 2)) + 13, (windowHeight - frameSize.Y) + 10, 20, 20);
                MultiFrogger.numberLivesRemaining--;
                Frog2 reset = new Frog2();
                reset.initialise();
            }

        }
    }
}
