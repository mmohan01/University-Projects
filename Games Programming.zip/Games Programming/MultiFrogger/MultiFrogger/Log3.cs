﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace MultiFrogger
{
    /// <Summary>
    /// Controls the movement of the third row of logs. They move from
    /// left to right across the screen
    /// </Summary>
    class Log3
    {
        /// <Summary>
        /// Here the Rectangles for drawing the images are declared in 
        /// an array. Also the Rectangle which is to handle collision 
        /// is declared here as well. They are declared as public static
        /// so that they can be accesed in any other class easily. The
        /// Texture2D Log is the sprite image that will be drew.
        /// </Summary>
        public static Rectangle[] position = new Rectangle[7];
        public static Rectangle[] collision = new Rectangle[7];

        private Texture2D Log;

        /// <Summary>
        /// This method allowed us to pass in the starting values of the Rectangles
        /// along with the size that they are to be drew. A random function is declared 
        /// and created allowing me to call a random number. The value which the random
        /// number has been is already set to be between to preset values. The random 
        /// values are then used to create the position on the x axis of the next Rectangle
        /// to be drew in the sequence
        /// </Summary>
        /// <param name="i"></param>
        /// <param name="j"></param>
        /// <param name="x"></param>
        /// <param name="y"></param>
        public void Position(int i, int j, int x, int y)
        {
            Random r = new Random();
            int b = r.Next(200, 440);
            int c = r.Next(200, 440);
            int d = r.Next(200, 440);
            int e = r.Next(200, 440);
            int f = r.Next(200, 440);
            position[0] = new Rectangle(i, j, x, y);
            position[1] = new Rectangle(i + b, j, x, y);
            position[2] = new Rectangle(i + b + c, j, x, y);
            position[3] = new Rectangle(i + b + c + d, j, x, y);
            position[4] = new Rectangle(i + b + c + d + e, j, x, y);
            position[5] = new Rectangle(i + b + c + d + e + f, j, x, y);

            collision[0] = new Rectangle(i + 18, j, x - 36, y);
            collision[1] = new Rectangle(i + b + 18, j, x - 36, y);
            collision[2] = new Rectangle(i + b + c + 18, j, x - 36, y);
            collision[3] = new Rectangle(i + b + c + d + 18, j, x - 36, y);
            collision[4] = new Rectangle(i + b + c + d + e + 18, j, x - 36, y);
            collision[5] = new Rectangle(i + b + c + d + e + f + 18, j, x - 36, y);

        }

        /// <Summary>
        /// This method loads in the sprite image to be used in this class
        /// </Summary>
        /// <param name="theContentManager"></param>
        /// <param name="theAssetName"></param>
        public void LoadContent(ContentManager theContentManager, string theAssetName)
        {
            Log = theContentManager.Load<Texture2D>(theAssetName);
        }

        /// <Summary>
        /// This method draws out each of the image by using a for loop and 
        /// looping through the array of the log positions. The log position
        /// also gets decremented by 1 here, so that it appears that its moving
        /// across the screen. Also if a bus achieves an x position of less 
        /// than - 200 then the logs x position will be reset to 1920. The 
        /// Collision Rectangle is also being moved across the screen here 
        /// too. This is done with relation to the image. Again the collision
        /// Rectangle will move in if the image of the log leaves the screen
        /// </Summary>
        /// <param name="theSpriteBatch"></param>
        public void Draw(SpriteBatch theSpriteBatch)
        {
            for (int j = 0; j < position.Length; j++)
            {
                theSpriteBatch.Draw(Log, position[j], Color.White);
                if (Switch.logSwitch == true)
                {
                    position[j].X = position[j].X - 1;
                    collision[j].X = collision[j].X - 1;
                    
                    if (position[j].X == -200)
                    {
                        position[j].X = 1920;
                        collision[j].X = 1920 + 18;
                    }
                }
            }

        }
    }
}

