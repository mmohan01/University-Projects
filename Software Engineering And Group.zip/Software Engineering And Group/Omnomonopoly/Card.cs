﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Omnomonopoly
{
    class Card
    {
        public String type;
        public String description;
        public int money;
        public Space area;
        public int total = 0;

        public Card(String t, String d, int m, Space a)
        {
            type = t;
            description = d;
            money = m;
            area = a;
        }

        //picks up a card for the player and carries out its instructions returning the string that is the 
        //card's description to be printed on screen later
        public String pickupCard(Player p, int x)
        {
            String result = description;

            if (type.Equals("move")) //moves the player to a space
            {
                p.currentSpace = area;
                p.deposit(money); //needed for advance to go
            }
            else if (type.Equals("moveJ")) //moves the player to jail
            {
                p.currentSpace = area;
                p.inJail = true;
            }
            else if (type.Equals("gooj")) //gives the player a Get Out Of Jail Free card
            {
                if (x ==1)
                    p.jailCard1 = true;
                else if (x ==2)
                    p.jailCard2 = true;
            }
            else if (type.Equals("money")) //affects the player's money
            {
                p.deposit(money);
            }
            else if (type.Equals("prop")) //makes the player pay a bill according to the amount of buildings they own
            {
                total = 0;
                for (int i = 0; i < 28; i++)
                {
                    if (p.owned[i] != null)
                    {
                        if (!p.owned[i].type.Equals("Util") && !p.owned[i].type.Equals("Train"))
                        {
                            if (p.owned[i].hotels == 1)
                                total = total + 115;
                            else if (p.owned[i].hotels == 0 && p.owned[i].houses > 0)
                                total = total + 45;
                        }
                    }
                }
                p.withdraw(total);
            }

            return result;
        }
    }
}
