﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

namespace Omnomonopoly
{
    public class Space
    {
        public Texture2D building;
        public Vector2 buildPos;
        public Space nextSpace;
        public Space[] matchingSpace = new Space[3];
        public String name;
        public String type;
        public int playersOnSpace;
        public Player[] playersOccupying = new Player[6];
        public Rectangle rect;
	    public Player owner;
	    public int buyPrice;
	    public int propRent;
	    public int housePrice;
	    public int hotelPrice;
	    public int houseRent;
	    public int hotelRent;
	    public int houses = 0;
	    public int hotels = 0;
	    public int totalRent;
	    public bool buyable;
        public bool mortgage = false;

        //constructor for generic space (ie Jail, Go, Card, Fine and GoToJail
        public Space(String n, int i, int j, int w, int h, String t)
        {
            name = n;
            rect = new Rectangle(i, j, w, h);
            type = t;
            buyable = false;
        }

        //constructor for train and util
        public Space(String n, int i, int j, int w, int h, String t, int c, int r)
        {
            name = n;
            rect = new Rectangle(i, j, w, h);
            type = t;
            buyPrice = c;
            propRent = r;
            buyable = true;
            owner = null;
        }

        //constructor for a property
        public Space(String n, int i, int j, int w, int h, String t, int c, int r, int housep, int houser, int hotelr)
        {
            name = n;
            rect = new Rectangle(i, j, w, h);
            type = t;
            buyPrice = c;
            propRent = r;
            buyable = true;
            owner = null;
		    housePrice = housep;
		    houseRent = houser;
		    hotelRent = hotelr;
            if (rect.X < 80)
                buildPos = new Vector2(rect.X + 82, rect.Y + 3);
            if (rect.X > 630)
                buildPos = new Vector2(rect.X + 2, rect.Y + 3);
            if (rect.Y < 80)
                buildPos = new Vector2(rect.X + 2, rect.Y + 83);
            if (rect.Y > 630)
                buildPos = new Vector2(rect.X + 2, rect.Y + 3);
        }

        public void LoadContent(ContentManager theContentManager)
        {
            if (buyable && !type.Equals("Train") && !type.Equals("Util"))
            {
                //loads the building texture for the streets on the top and bottom row
                if (rect.X > 50 && rect.X < 610)
                {
                    if (houses > 0 && hotels == 0)
                        building = theContentManager.Load<Texture2D>("H Houses " + houses);
                    if (hotels == 1)
                        building = theContentManager.Load<Texture2D>("H Hotel");
                }
                else //loads the building texture for the streets on the left and right columns
                {
                    if (houses > 0 && hotels == 0)
                        building = theContentManager.Load<Texture2D>("V Houses " + houses);
                    if (hotels == 1)
                        building = theContentManager.Load<Texture2D>("V Hotel");
                }
            }
        }

        public void buyProperty(Player buyer)
        {
            if (buyable)
            {
                if (owner == null && buyer.money >= buyPrice)
                {
                    buyer.withdraw(buyPrice);
                    owner = buyer;
                }
            }
        }

        public String sellProperty(Player buyer)
        {
            String result = "";

            if (buyable)
            {
                if ((houses == 0 || hotels == 0) || type.Equals("Util") || type.Equals("Train"))
                {
                    if (owner == buyer)
                    {
                        buyer.deposit(buyPrice);
                        owner = null;
                        bool matchFound = false;
                        //this for loop removes the property from the owners property list
                        for (int i = 0; i < 28; i++)
                        {
                            if (buyer.owned[i] == this)
                            {
                                buyer.owned[i] = null;
                                matchFound = true;
                            }
                            else if (matchFound)
                            {
                                buyer.owned[i - 1] = buyer.owned[i];
                                if (i == 27)
                                    buyer.owned[i] = null;
                            }

                        }
                        result = "- You have sold " + name + " for £" + buyPrice;
                    }
                    else
                    {
                        result = "- You do not own " + name;
                    }
                }
                else
                {
                    result = "- You cannot sell this space while there are buldings on it";
                }
            }
            else
            {
                result = "- This space cannot be sold";
            }

            return result;
        }

        public String mortgageProperty(Player buyer)
        {
            String result = "";

            if (buyable && mortgage == false) //mortgages a property
            {
                if ((houses == 0 || hotels == 0) || type.Equals("Util") || type.Equals("Train"))
                {
                    if (owner == buyer)
                    {
                        buyer.deposit(buyPrice / 2);
                        mortgage = true;
                        result = "- You have mortgaged " + name + " for £" + buyPrice / 2;
                    }
                    else
                    {
                        result = "- You do not own " + name;
                    }
                }
                else
                {
                    result = "- You cannot mortgage this space while there are buldings on it";
                }
            }
            else if (mortgage) //unmortgages a property
            {
                if (owner == buyer)
                {
                    buyer.withdraw((buyPrice / 2) + (buyPrice / 10));
                    mortgage = false;
                    result = "- You have unmortgaged " + name + " for £" + ((buyPrice / 2) + (buyPrice / 10));
                }
                else
                    result = "- You do not own this space to unmortgage it";
            }
            else
            {
                result = "- This space cannot be mortgaged";
            }

            return result;
        }

	    public String buyHouse(Player buyer)
        {
            String result = "";
            //checks that the property can have houses on it
            if (!type.Equals("Util") && !type.Equals("Train"))
            {
                //checks if the owner owns the matching spaces
                if (buyer == owner && buyer == matchingSpace[0].owner && (matchingSpace[1] == null || buyer == matchingSpace[1].owner))
                {
                    //checks if the properties have eogh houses on them
                    if (houses <= matchingSpace[0].houses && (matchingSpace[1] == null || houses <= matchingSpace[1].houses))
                    {
                        //checks if the player has enough money to build
                        if (buyer.money >= housePrice)
                        {
                            //checks if they are building a house or hotel
                            if (houses < 4 && hotels == 0)
                            {
                                houses++;
                                buyer.withdraw(housePrice);
                                result = "- You have built a house on " + name;
                            }
                            else if (hotels == 0)
                            {
                                hotels++;
                                buyer.withdraw(hotelPrice);
                                result = "- You have built a hotel on " + name;
                            }
                            else
                            {
                                result = "- You can't build anymore buildings on " + name;
                            }
                        }
                        else
                        {
                            result = "- You don't have enough money to build on " + name;
                        }
                    }
                    else
                    {
                        result = "- You have to add properties to the matching spaces before building here again";
                    }
                }
                else
                {
                    result = "- You don't own the matching properties to build here";
                }
            }
            else
            {
                result = "- You cannot build on this property";
            }

            return result;
	    }

	    public String sellHouse(Player buyer)
        {
            String result = "";
            //checks that the property can have houses on it
            if (!type.Equals("Util") && !type.Equals("Train"))
            {
                //checks if the owner owns the matching spaces
                if (buyer == owner && buyer == matchingSpace[0].owner && (matchingSpace[1] == null || buyer == matchingSpace[1].owner))
                {
                    //checks if the properties have eogh houses on them
                    if (houses >= matchingSpace[0].houses && (matchingSpace[1] == null || houses >= matchingSpace[1].houses))
                    {
                       
                        //checks if they are building a house or hotel
                        if (houses > 0 && houses <= 4 && hotels == 0)
                        {
                            houses--;
                            buyer.deposit(housePrice);
                            result = "- You have sold a house on " + name;
                        }
                        else if (hotels == 1)
                        {
                            hotels--;
                            buyer.deposit(hotelPrice);
                            result = "- You have sold a hotel on " + name;
                        }
                        else
                        {
                            result = "- You don't have anymore buildings to sell on " + name;
                        }   
                    }
                    else
                    {
                        result = "- You have to sell properties on the matching spaces before selling here again";
                    }
                }
                else
                {
                    result = "- You don't own the matching properties to sell here";
                }
            }
            else
            {
                result = "- This property can't have buildings to sell";
            }

            return result;
	    }

	    public void payRent(Player renter, int n)
        {
		    if(owner != null)
            {
			    if(renter != owner)
                {
				    if(hotels > 0)
                    {
					    totalRent = hotelRent;
				    }
                    else if(houses > 0)
                    {
                        //calculates the rent for the properties when it has houses on it
                        //there are multiple if checks here as I tried to match the original rents and there isn't a common formula
                        if (houses == 4)
                        {
                            if (type.Equals("Brown"))
                                totalRent = (houseRent * 16);
                            else if (type.Equals("Blue") || type.Equals("Pink"))
                                totalRent = houseRent + (houseRent * 3) + (houseRent * 9);
                            else if (type.Equals("Orange"))
                                totalRent = (int)((houseRent * 3) + ((houseRent * 3) * 2.6));
                            else if (type.Equals("Yellow") || type.Equals("Green") || type.Equals("Red"))
                                totalRent = 210 + (houseRent * 7);
                            else
                                totalRent = (int)(((houseRent * 3) * 2.2) + (houseRent * 1.5));
                        }
                        if (houses == 3)
                        {
                            if (type.Equals("Brown") || type.Equals("Blue") || type.Equals("Pink"))
                                totalRent = (houseRent * 9);
                            else if (type.Equals("Orange") || type.Equals("Red"))
                                totalRent = (int)((houseRent * 3) * 2.6);
                            else if (type.Equals("Yellow") || type.Equals("Green"))
                                totalRent = (int)((houseRent * 3) * 2.4);
                            else
                                totalRent = (int)((houseRent * 3) * 2.2);
                        }
                        if (houses == 2)
                            totalRent = houseRent * 3;
                        if (houses == 1)
                            totalRent = houseRent;
				    }
                    else
                    {
                        if (type.Equals("Train"))
                        {
                            //checks how many other train stations the owner owns
                            int match = 0;
                            for (int i = 0; i < 3; i++)
                                if (matchingSpace[i].owner == owner)
                                    match++;

                            if (match == 3)
                                totalRent = 200;
                            else if (match == 2)
                                totalRent = 100;
                            else if (match == 1)
                                totalRent = 50;
                            else if (match == 0)
                                totalRent = 25;
                        }
                        else if (type.Equals("Util"))
                        {
                            //checks if the owner owns the other utility
                            if (matchingSpace[0].owner == owner)
                                totalRent = 10 * n;
                            else
                                totalRent = 4 * n;
                        }
                        else
                        {
                            totalRent = propRent;
                        }
				    }
                    renter.withdraw(totalRent);
                    owner.deposit(totalRent);
			    }
		    }
	    }

        public void Draw(SpriteBatch theSpriteBatch)
        {
            if (buyable && (houses > 0 || hotels > 0))
                theSpriteBatch.Draw(building, buildPos, Color.White);
        }
    }
}
