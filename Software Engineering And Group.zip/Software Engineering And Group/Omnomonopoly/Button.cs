﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

namespace Omnomonopoly
{
    public class Button
    {
        public Space prop;
        public ContentManager theContentManager;
        public Vector2 position;
        public Texture2D tex;
        public Rectangle rect;
        public String name;
        public String type;
        public String state;
        public bool visible;

        //constructor for a gameplay button
        public Button(Vector2 pos, String n, String t, ContentManager c)
        {
            position = pos;
            name = n;
            type = t;
            state = "Up";
            theContentManager = c;
            prop = null;
            visible = false;
        }

        //constructor for a button that is linked to a property
        public Button(Vector2 pos, String n, String t, ContentManager c, Space p)
        {
            position = pos;
            name = n;
            type = t;
            state = "Up";
            theContentManager = c;
            prop = p;
            visible = false;
        }

        //loads the texture for the button
        public void LoadContent()
        {
            
            if (type.Equals("Prop") || type.Equals("Util") || type.Equals("Train"))
                if (!prop.mortgage)
                    tex = theContentManager.Load<Texture2D>(name);
                else
                    tex = theContentManager.Load<Texture2D>("Mortgage Prop");
            else //code to load the appropiate texture for a gameplay button
                tex = theContentManager.Load<Texture2D>(name + " " + state);

            rect = new Rectangle((int)position.X, (int)position.Y, tex.Width, tex.Height);
        }

        //a method that handles property management, returning a string that is a descriptio of what happened
        public String Manage(string s, Player p)
        {
            String result = "";
            if (s.Equals("Add B"))
            {
                result = prop.buyHouse(p);
            }
            else if (s.Equals("Sell B"))
            {
                result = prop.sellHouse(p);
            }
            else if (s.Equals("Sell"))
            {
                result = prop.sellProperty(p);
                if (prop.owner == null)
                    visible = false;
            }
            else if (s.Equals("Mortgage"))
            {
                result = prop.mortgageProperty(p);
            }

            return result;
        }

        public void Update(GameTime gameTime)
        {
            //LoadContent();
        }

        //draws the button if it's visibilty is set to true
        public void Draw(SpriteBatch spriteBatch)
        {
            if (visible)
                spriteBatch.Draw(tex, position, Color.White); 
        }
    }
}
