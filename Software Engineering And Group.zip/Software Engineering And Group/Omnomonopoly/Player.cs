﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

namespace Omnomonopoly
{
    public class Player
    {
        public Texture2D token, jailChest, jailChance;
        public Vector2 pos;
        public String name;
        public int money;
        public bool jailCard1, jailCard2;
        public bool hasMoved;
        public bool inJail;
        public String image;
        public Space currentSpace;
        public Space[] owned = new Space[28];
        public int count = 0;

        public Player(String n, int m, String i)
        {
            name = n;
            money = m;
            image = i;
            jailCard1 = false;
            jailCard2 = false;
            if (image.Equals("Player 1"))
            {
                pos = new Vector2(680, 680);
            }
            if (image.Equals("Player 2"))
            {
                pos = new Vector2(680, 700);
            }
            if (image.Equals("Player 3"))
            {
                pos = new Vector2(700, 680);
            }
            if (image.Equals("Player 4"))
            {
                pos = new Vector2(700, 700);
            }
        }

        public void LoadContent(ContentManager theContentManager)
        {
            token = theContentManager.Load<Texture2D>(image + " piece");
            jailChance = theContentManager.Load<Texture2D>("jailChance");
            jailChest = theContentManager.Load<Texture2D>("jailChest");
        }
        
        /* Allows the player to buy the property they are currently on, if it isn't already owned.
         * Can only be performed after rolling the dice.
         */
        public void purchaseProperty(Space p)
        {
            p.buyProperty(this);
            if (this == p.owner)
            {
                count++;
                owned[count] = p;
            }
        }

        /*Rolls the dice to get a value and makes the player move that many spaces.
         If the player is in jail, they do not get to move unless a double has been rolled.
         If the player is in jail and has jailCard as true,
         they ignore the restrictions of jail and get to move, setting jailCard as false afterwards.
         */
        public void move()
        {
            currentSpace = currentSpace.nextSpace;
        }

        /*
         * Controls the different aspects of the jail function
         */
        public String setJail()
        {
            String result = " ";

            if (jailCard1 == false && jailCard2 == false)
                inJail = true;
            else if (jailCard1)
                jailCard1 = false;
            else if (jailCard2)
                jailCard2 = false;

            if (inJail == false)
                result = "- You have used a 'Get Out Of Jail Free' card";
            return result;
        }

        public void releaseJail()
        {
            inJail = false;
        }


        /* Used to subtract the money from the players kitty/bank.
         * Will be called on purchases, fines, etc.
         */
        public void withdraw(int amount)
        {
            money -= amount;
        }

        /* Used to add money into the players kitty/bank.
         * Will be called on Passing Go, Rent, Free Parking, etc.
         */
        public void deposit(int amount)
        {
            money += amount;
        }

        public void Draw(SpriteBatch theSpriteBatch)
        {
            theSpriteBatch.Draw(token, pos, Color.White);
        }

        public void DrawCurrent(SpriteBatch theSpriteBatch)
        {
            if (jailCard1)
                theSpriteBatch.Draw(jailChest, new Vector2(1020, 645), Color.White);
            if (jailCard2)
                theSpriteBatch.Draw(jailChance, new Vector2(1070, 645), Color.White);
        }
    }
}
