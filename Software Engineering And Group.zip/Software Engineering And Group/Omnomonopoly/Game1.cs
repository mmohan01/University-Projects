﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

namespace Omnomonopoly
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch theSpriteBatch;
        Player[] players = new Player[4]; 
        Player currentPlayer;
        Dice die;
        OurMouse gameMouse;
        SpriteFont font, infoFont, menuFont;
        Space go, jail, freePark, goToJail, chance1, chance2, chance3;
        Space chest1, chest2, chest3, fine100, fine200;
        Space train1, train2, train3, train4, elecUtil, waterUtil;
        Space brown1, brown2, blue1, blue2, blue3, pink1, pink2, pink3;
        Space orange1, orange2, orange3, red1, red2, red3, yellow1;
        Space yellow2, yellow3, green1, green2, green3, dark1, dark2;
        Button roll, buy, sell, mortgage, endGo, bBuy, bSell;
        Button[] propButton = new Button[28];
        Button bTwo, bThree, bFour, bEnd;
        Button[] bAlphabet = new Button[28];
        Card[] comChestCard = new Card[14];
        Card[] chanceCard = new Card[14];

        public Texture2D playingBoard, playerArea, title, nameArea;
        public Texture2D dice1, dice2;
        public Texture2D buildBr1, buildBr2, buildBl1, buildBl2, buildBl3, buildPi1, buildPi2, buildPi3;
        public Texture2D buildOr1, buildOr2, buildOr3, buildRe1, buildRe2, buildRe3, buildYe1, buildYe2, buildYe3;
        public Texture2D buildGr1, buildGr2, buildGr3, buildDr1, buildDr2;
        public Vector2[] infoPos = new Vector2[6];
        public Vector2 namePos, moneyPos;

        public int windowHeight = 740;
        public int windowWidth = 1200;
        public int chestNum, chanceNum;
        public int currentNum = 0;
        public int noOfPlayers;
        public bool inGame = false;
        public bool nameEntry = false;
        public bool setUpDone = false;
        public bool winner = false;
        public Random cardGen = new Random();
        public String[] info = new String[6];
        public String name, money;
        public String curName, name1, name2, name3, name4;
        public String propManage = "None"; 

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            graphics.PreferredBackBufferWidth = windowWidth;
            graphics.PreferredBackBufferHeight = windowHeight;
            
        }

        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            die = new Dice(Content);
            gameMouse = new OurMouse(new Vector2(0, 0));
            for (int i = 1; i < 6; i++)
                info[i] = "-";
            info[0] = "- The latest information will be displayed here";
            infoPos[0] = new Vector2(135, 500);
            infoPos[1] = new Vector2(135, 520);
            infoPos[2] = new Vector2(135, 540);
            infoPos[3] = new Vector2(135, 560);
            infoPos[4] = new Vector2(135, 580);
            infoPos[5] = new Vector2(135, 600);
            namePos = new Vector2(870, 100);
            moneyPos = new Vector2(870, 130);

            roll = new Button(new Vector2(750, 90), "Roll Dice", "gameplay", Content);
            buy = new Button(new Vector2(750, 180), "Buy", "gameplay", Content);
            sell = new Button(new Vector2(750, 270), "Sell", "gameplay", Content);
            mortgage = new Button(new Vector2(750, 360), "Mortgage", "gameplay", Content);
            bBuy = new Button(new Vector2(750, 450), "Add Building", "gameplay", Content);
            bSell = new Button(new Vector2(750, 540), "Sell Building", "gameplay", Content);
            endGo = new Button(new Vector2(750, 630), "End Go", "gameplay", Content);

            bTwo = new Button(new Vector2(425, 400), "Two", "", Content);
            bThree = new Button(new Vector2(425, 470), "Three", "", Content);
            bFour = new Button(new Vector2(425, 540), "Four", "", Content);

            bAlphabet[0] = new Button(new Vector2(350, 450), "Q", "q", Content);
            bAlphabet[1] = new Button(new Vector2(400, 450), "W", "w", Content);
            bAlphabet[2] = new Button(new Vector2(450, 450), "E", "e", Content);
            bAlphabet[3] = new Button(new Vector2(500, 450), "R", "r", Content);
            bAlphabet[4] = new Button(new Vector2(550, 450), "T", "t", Content);
            bAlphabet[5] = new Button(new Vector2(600, 450), "Y", "y", Content);
            bAlphabet[6] = new Button(new Vector2(650, 450), "U", "u", Content);
            bAlphabet[7] = new Button(new Vector2(700, 450), "I", "i", Content);
            bAlphabet[8] = new Button(new Vector2(750, 450), "O", "o", Content);
            bAlphabet[9] = new Button(new Vector2(800, 450), "P", "p", Content);
            bAlphabet[10] = new Button(new Vector2(375, 510), "A", "a", Content);
            bAlphabet[11] = new Button(new Vector2(425, 510), "S", "s", Content);
            bAlphabet[12] = new Button(new Vector2(475, 510), "D", "d", Content);
            bAlphabet[13] = new Button(new Vector2(525, 510), "F", "f", Content);
            bAlphabet[14] = new Button(new Vector2(575, 510), "G", "g", Content);
            bAlphabet[15] = new Button(new Vector2(625, 510), "H", "h", Content);
            bAlphabet[16] = new Button(new Vector2(675, 510), "J", "j", Content);
            bAlphabet[17] = new Button(new Vector2(725, 510), "K", "k", Content);
            bAlphabet[18] = new Button(new Vector2(775, 510), "L", "l", Content);
            bAlphabet[19] = new Button(new Vector2(350, 570), "Z", "z", Content);
            bAlphabet[20] = new Button(new Vector2(400, 570), "X", "x", Content);
            bAlphabet[21] = new Button(new Vector2(450, 570), "C", "c", Content);
            bAlphabet[22] = new Button(new Vector2(500, 570), "V", "v", Content);
            bAlphabet[23] = new Button(new Vector2(550, 570), "B", "b", Content);
            bAlphabet[24] = new Button(new Vector2(600, 570), "N", "n", Content);
            bAlphabet[25] = new Button(new Vector2(650, 570), "M", "m", Content);
            bAlphabet[26] = new Button(new Vector2(700, 570), "Delete", " ", Content);
            bAlphabet[27] = new Button(new Vector2(350, 630), "Space", " ", Content);
            bEnd = new Button(new Vector2(700, 630), "End", "", Content);
            

            //assigns the spaces with their variable values
            go = new Space("Go", 640, 640, 100, 100, "Go");
            jail = new Space("Jail", 0, 640, 100, 100, "Jail");
            freePark = new Space("Free Parking", 0, 0, 100, 100, "Free Park");
            goToJail = new Space("Go To Jail", 640, 0, 100, 100, "Go To Jail");
            brown1 = new Space("Old Kent Road", 580, 640, 60, 100, "Brown", 60, 2, 50, 10, 250);
            chest1 = new Space("Community Chest 1", 520, 640, 60, 100, "CChest");
            brown2 = new Space("Whitechapel Road", 460, 640, 60, 100, "Brown", 60, 4, 50, 30, 450);
            fine200 = new Space("Super Tax", 400, 640, 60, 100, "F 200");
            train1 = new Space("King's Cross Station", 340, 640, 60, 100, "Train", 200, 25);
            blue1 = new Space("The Angel Islington", 280, 640, 60, 100, "Blue", 100, 6, 50, 30, 550);
            chance1 = new Space("Chance 1", 220, 640, 60, 100, "Chance");
            blue2 = new Space("Euston Road", 160, 640, 60, 100, "Blue", 100, 6, 50, 30, 550);
            blue3 = new Space("Pentonville Road", 100, 640, 60, 100, "Brown", 120, 8, 50, 40, 600);
            pink1 = new Space("Pall Mall", 0, 580, 100, 60, "Pink", 140, 10, 100, 50, 750);
            elecUtil = new Space("Electric Company", 0, 520, 100, 60, "Util", 150, 0);
            pink2 = new Space("Whitehall", 0, 460, 100, 60, "Pink", 140, 10, 100, 50, 750);
            pink3 = new Space("Northumberland Avenue", 0, 400, 100, 60, "Pink", 160, 12, 100, 60, 800);
            train2 = new Space("Marylebone Station", 0, 340, 100, 60, "Train", 200, 25);
            orange1 = new Space("Bow Street", 0, 280, 100, 60, "Orange", 180, 14, 100, 70, 950);
            chest2 = new Space("Community Chest 2", 0, 220, 100, 60, "CChest");
            orange2 = new Space("Marlborough Street", 0, 160, 100, 60, "Orange", 180, 14, 100, 70, 950);
            orange3 = new Space("Vine Street", 0, 100, 100, 60, "Orange", 200, 16, 100, 80, 1000);
            red1 = new Space("Strand", 100, 0, 60, 100, "Red", 220, 18, 150, 90, 1050);
            chance2 = new Space("Chance 2", 160, 0, 60, 100, "Chance");
            red2 = new Space("Fleet Street", 220, 0, 60, 100, "Red", 220, 18, 150, 90, 1050);
            red3 = new Space("Trafalgar Square", 280, 0, 60, 100, "Red", 240, 20, 150, 100, 1100);
            train3 = new Space("Fenchurch Street Station", 340, 0, 60, 100, "Train", 200, 25);
            yellow1 = new Space("Leicester Square", 400, 0, 60, 100, "Yellow", 260, 22, 150, 110, 1150);
            yellow2 = new Space("Coventry Street", 460, 0, 60, 100, "Yellow", 260, 22, 150, 110, 1150);
            waterUtil = new Space("Water Works", 520, 0, 60, 100, "Util", 150, 0);
            yellow3 = new Space("Piccadilly", 580, 0, 60, 100, "Yellow", 280, 24, 150, 120, 1200);
            green1 = new Space("Regent Street", 640, 100, 100, 60, "Green", 300, 26, 200, 130, 1275);
            green2 = new Space("Oxford Street", 640, 160, 100, 60, "Green", 300, 26, 200, 130, 1275);
            chest3 = new Space("Community Chest 3", 640, 220, 100, 60, "CChest");
            green3 = new Space("Bond Street", 640, 280, 100, 60, "Green", 320, 28, 200, 150, 1400);
            train4 = new Space("Liverpool Street Station", 640, 340, 100, 60, "Train", 200, 25);
            chance3 = new Space("Chance 3", 640, 400, 100, 60, "Chance");
            dark1 = new Space("Park Lane", 640, 460, 100, 60, "Dark", 350, 35, 200, 175, 1500);
            fine100 = new Space("Tax", 640, 520, 100, 60, "F 100");
            dark2 = new Space("Mayfair", 640, 580, 100, 60, "Dark", 400, 50, 200, 200, 2000);

            //initializes the cards
            chanceCard[0] = new Card("move", "- Go back to Old Kent Road", 0, brown1);
            chanceCard[1] = new Card("money", "- You have come second in a beauty contest. You won £10", 10, null);
            chanceCard[2] = new Card("money", "- You have won £100 in a crossword competition", 100, null);
            chanceCard[3] = new Card("money", "- Speeding fine. Pay £15", -15, null);
            chanceCard[4] = new Card("money", "- Tax income in your favour. Receive £50", 50, null);
            chanceCard[5] = new Card("move", "- Advance to Go! Collect £200!", 200, go);
            chanceCard[6] = new Card("prop", "- Make repairs on your properties. £45 for houses, £115 for hotels", 0, null);
            chanceCard[7] = new Card("moveJ", "- Go To Jail! Directly to Jail! Do not pass Go!", 0, jail);
            chanceCard[8] = new Card("money", "- Pay school fees of £150", -150, null);
            chanceCard[9] = new Card("money", "- Your building loan matures. Collect £150", 150, null);
            chanceCard[10] = new Card("move", "- Advance to Mayfair", 0, dark2);
            chanceCard[11] = new Card("money", "- Drunk in charge fine. Pay £20", -20, null);
            chanceCard[12] = new Card("gooj", "- Get out of jail free card!!", 0, null);
            chanceCard[13] = new Card("money", "- Bank error in your favour. Collect £50", 50, null);

            comChestCard[0] = new Card("move", "- Advance to Go! Collect £200!", 200, go);
            comChestCard[1] = new Card("money", "- Bank error in your favour. Collect £75", 75, null);
            comChestCard[2] = new Card("money", "- Doctors fee. Pay £50", -50, null);
            comChestCard[3] = new Card("gooj", "- Get out of jail free card!!", 0, null);
            comChestCard[4] = new Card("money", "- Speeding fine. Pay £15", -15, null);
            comChestCard[5] = new Card("money", "- Pay your insurance premium! £50", -50, null);
            comChestCard[6] = new Card("money", "- Holiday fund matures. Receive £100", 100, null);
            comChestCard[7] = new Card("money", "- Pay school fees of £50", -50, null);
            comChestCard[8] = new Card("moveJ", "- Go To Jail! Directly to Jail! Do not pass Go!", 0, jail);
            comChestCard[9] = new Card("money", "- Pay hospital fees of £100", -100, null);
            comChestCard[10] = new Card("money", "- Life insurance matures. Receive £100", 100, null);
            comChestCard[11] = new Card("move", "- Go to Mayfair", 0, dark2);
            comChestCard[12] = new Card("money", "- From sale of stock you received £50", 50, null);
            comChestCard[13] = new Card("prop", "- You are assessed for street repairs. £45 for houses, £115 for hotels", 0, null);

            //creates the property buttons for each of the properties
            propButton[0] = new Button(new Vector2(870, 270), "Old Kent", "Prop", Content, brown1);
            propButton[1] = new Button(new Vector2(920, 270), "Whitechapel", "Prop", Content, brown2);
            propButton[2] = new Button(new Vector2(970, 270), "Angel", "Prop", Content, blue1);
            propButton[3] = new Button(new Vector2(1020, 270), "Euston", "Prop", Content, blue2);
            propButton[4] = new Button(new Vector2(1070, 270), "Penton", "Prop", Content, blue3);
            propButton[5] = new Button(new Vector2(870, 345), "Pall", "Prop", Content, pink1);
            propButton[6] = new Button(new Vector2(920, 345), "Whitehall", "Prop", Content, pink2);
            propButton[7] = new Button(new Vector2(970, 345), "Northum", "Prop", Content, pink3);
            propButton[8] = new Button(new Vector2(1020, 345), "Bow", "Prop", Content, orange1);
            propButton[9] = new Button(new Vector2(1070, 345), "Marlbo", "Prop", Content, orange2);
            propButton[10] = new Button(new Vector2(1120, 345), "Vine", "Prop", Content, orange3);
            propButton[11] = new Button(new Vector2(870, 420), "Strand", "Prop", Content, red1);
            propButton[12] = new Button(new Vector2(920, 420), "Fleet", "Prop", Content, red2);
            propButton[13] = new Button(new Vector2(970, 420), "Trafal", "Prop", Content, red3);
            propButton[14] = new Button(new Vector2(1020, 420), "Leicest", "Prop", Content, yellow1);
            propButton[15] = new Button(new Vector2(1070, 420), "Coventry", "Prop", Content, yellow2);
            propButton[16] = new Button(new Vector2(1120, 420), "Piccadilly", "Prop", Content, yellow3);
            propButton[17] = new Button(new Vector2(870, 495), "Regent", "Prop", Content, green1);
            propButton[18] = new Button(new Vector2(920, 495), "Oxford", "Prop", Content, green2);
            propButton[19] = new Button(new Vector2(970, 495), "Bond", "Prop", Content, green3);
            propButton[20] = new Button(new Vector2(1020, 495), "Park", "Prop", Content, dark1);
            propButton[21] = new Button(new Vector2(1070, 495), "Mayfair", "Prop", Content, dark2);
            propButton[22] = new Button(new Vector2(870, 570), "King's", "Train", Content, train1);
            propButton[23] = new Button(new Vector2(920, 570), "Maryle", "Train", Content, train2);
            propButton[24] = new Button(new Vector2(970, 570), "Fench", "Train", Content, train3);
            propButton[25] = new Button(new Vector2(1020, 570), "Liver", "Train", Content, train4);
            propButton[26] = new Button(new Vector2(870, 645), "Elec", "Util", Content, elecUtil);
            propButton[27] = new Button(new Vector2(920, 645), "Water", "Util", Content, waterUtil);
            

            //creates the links between the spaces needed for movement
            go.nextSpace = brown1;
            brown1.nextSpace = chest1;
            chest1.nextSpace = brown2;
            brown2.nextSpace = fine200;
            fine200.nextSpace = train1;
            train1.nextSpace = blue1;
            blue1.nextSpace = chance1;
            chance1.nextSpace = blue2;
            blue2.nextSpace = blue3;
            blue3.nextSpace = jail;
            jail.nextSpace = pink1;
            pink1.nextSpace = elecUtil;
            elecUtil.nextSpace = pink2;
            pink2.nextSpace = pink3;
            pink3.nextSpace = train2;
            train2.nextSpace = orange1;
            orange1.nextSpace = chest2;
            chest2.nextSpace = orange2;
            orange2.nextSpace = orange3;
            orange3.nextSpace = freePark;
            freePark.nextSpace = red1;
            red1.nextSpace = chance2;
            chance2.nextSpace = red2;
            red2.nextSpace = red3;
            red3.nextSpace = train3;
            train3.nextSpace = yellow1;
            yellow1.nextSpace = yellow2;
            yellow2.nextSpace = waterUtil;
            waterUtil.nextSpace = yellow3;
            yellow3.nextSpace = goToJail;
            goToJail.nextSpace = green1;
            green1.nextSpace = green2;
            green2.nextSpace = chest3;
            chest3.nextSpace = green3;
            green3.nextSpace = train4;
            train4.nextSpace = chance3;
            chance3.nextSpace = dark1;
            dark1.nextSpace = fine100;
            fine100.nextSpace = dark2;
            dark2.nextSpace = go;

            //creates the group links needed for houses
            brown1.matchingSpace[0] = brown2;
            brown2.matchingSpace[0] = brown1;
            blue1.matchingSpace[0] = blue2;
            blue1.matchingSpace[1] = blue3;
            blue2.matchingSpace[0] = blue1;
            blue2.matchingSpace[1] = blue3;
            blue3.matchingSpace[0] = blue1;
            blue3.matchingSpace[1] = blue2;
            pink1.matchingSpace[0] = pink2;
            pink1.matchingSpace[1] = pink3;
            pink2.matchingSpace[0] = pink1;
            pink2.matchingSpace[1] = pink3;
            pink3.matchingSpace[0] = pink1;
            pink3.matchingSpace[1] = pink2;
            orange1.matchingSpace[0] = orange2;
            orange1.matchingSpace[1] = orange3;
            orange2.matchingSpace[0] = orange1;
            orange2.matchingSpace[1] = orange3;
            orange3.matchingSpace[0] = orange1;
            orange3.matchingSpace[1] = orange2;
            red1.matchingSpace[0] = red2;
            red1.matchingSpace[1] = red3;
            red2.matchingSpace[0] = red1;
            red2.matchingSpace[1] = red3;
            red3.matchingSpace[0] = red1;
            red3.matchingSpace[1] = red2;
            yellow1.matchingSpace[0] = yellow2;
            yellow1.matchingSpace[1] = yellow3;
            yellow2.matchingSpace[0] = yellow1;
            yellow2.matchingSpace[1] = yellow3;
            yellow3.matchingSpace[0] = yellow1;
            yellow3.matchingSpace[1] = yellow2;
            green1.matchingSpace[0] = green2;
            green1.matchingSpace[1] = green3;
            green2.matchingSpace[0] = green1;
            green2.matchingSpace[1] = green3;
            green3.matchingSpace[0] = green1;
            green3.matchingSpace[1] = green2;
            dark1.matchingSpace[0] = dark2;
            dark2.matchingSpace[0] = dark1;

            //creates the links between trains and utilities, which is neded for rent
            train1.matchingSpace[0] = train2;
            train1.matchingSpace[1] = train3;
            train1.matchingSpace[2] = train4;
            train2.matchingSpace[0] = train1;
            train2.matchingSpace[1] = train3;
            train2.matchingSpace[2] = train4;
            train3.matchingSpace[0] = train1;
            train3.matchingSpace[1] = train2;
            train3.matchingSpace[2] = train4;
            train4.matchingSpace[0] = train2;
            train4.matchingSpace[1] = train3;
            train4.matchingSpace[2] = train1;
            elecUtil.matchingSpace[0] = waterUtil;
            waterUtil.matchingSpace[0] = elecUtil;

            chanceNum = cardGen.Next(14);
            chestNum = cardGen.Next(14);

            bTwo.visible = true;
            bThree.visible = true;
            bFour.visible = true;

            curName = "";
            base.Initialize();
        }

        
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            theSpriteBatch = new SpriteBatch(GraphicsDevice);
            playingBoard = Content.Load<Texture2D>("Board");
            playerArea = Content.Load<Texture2D>("gameArea");
            title = Content.Load<Texture2D>("Title");
            nameArea = Content.Load<Texture2D>("Name Box");
            font = Content.Load<SpriteFont>("gameFont");
            infoFont = Content.Load<SpriteFont>("gameInfoFont");
            menuFont = Content.Load<SpriteFont>("gameMenuFont");
            gameMouse.LoadContent(this.Content);
            die.LoadContent();
            buy.LoadContent();
            sell.LoadContent();
            roll.LoadContent();
            endGo.LoadContent();
            mortgage.LoadContent();
            bBuy.LoadContent();
            bSell.LoadContent();
            bTwo.LoadContent();
            bThree.LoadContent();
            bFour.LoadContent();
            bEnd.LoadContent();
            for (int i = 0; i < 28; i++)
            {
                propButton[i].LoadContent();
                bAlphabet[i].LoadContent();
            }

            // TODO: use this.Content to load your game content here
        }

        //this method loads the players into the game
        //it can't happen in the initialize of loadcontent methods as we 
        //don't know how many players are playing when the program launches
        public void loadPlayers()
        {
            if (noOfPlayers == 2)
            {
                players[0] = new Player(name1, 1600, "Player 1");
                players[1] = new Player(name2, 1600, "Player 2");
                players[2] = null;
                players[3] = null;
            }
            else if (noOfPlayers == 3)
            {
                players[0] = new Player(name1, 1600, "Player 1");
                players[1] = new Player(name2, 1600, "Player 2");
                players[2] = new Player(name3, 1600, "Player 3");
                players[3] = null;
            }
            else if (noOfPlayers == 4)
            {
                players[0] = new Player(name1, 1600, "Player 1");
                players[1] = new Player(name2, 1600, "Player 2");
                players[2] = new Player(name3, 1600, "Player 3");
                players[3] = new Player(name4, 1600, "Player 4");
            }

            for (int i = 0; i < noOfPlayers; i++)
            {
                players[i].LoadContent(Content);
                players[i].currentSpace = go;
            }

            //makes the current player be player 1 and initialises the text strings
            currentPlayer = players[0];
            name = "Name: " + currentPlayer.name;
            money = "Money: £" + currentPlayer.money;

            //makes the gameplay buttons visible and useable
            roll.visible = true;
            buy.visible = true;
            sell.visible = true;
            bBuy.visible = true;
            bSell.visible = true;
            mortgage.visible = true;
            endGo.visible = true;

            //makes the name entry buttons invisible and unuseable
            bEnd.visible = false;
            for (int i = 0; i < 28; i++)
                bAlphabet[i].visible = false;
            
        }

        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (Keyboard.GetState().IsKeyDown(Keys.Escape))
                this.Exit();

            //updates the mouse
            gameMouse.Update(gameTime);

            if (!inGame && !winner) //update for the main menu
            {
                if (!nameEntry)
                {
                    checkButtons(bTwo);
                    checkButtons(bThree);
                    checkButtons(bFour);
                }
                else if (nameEntry)
                {
                    for (int i = 0; i < 28; i++)
                        checkButtons(bAlphabet[i]);
                    checkButtons(bEnd);
                }

                //checks if its time to start the game
                if (setUpDone)
                {
                    loadPlayers();
                    inGame = true;
                }
            }
            else if (inGame) //update for when playing the game
            {
                //checks if any of the gameplay buttons have been clicked
                checkButtons(roll);
                checkButtons(buy);
                checkButtons(sell);
                checkButtons(mortgage);
                checkButtons(bBuy);
                checkButtons(bSell);
                checkButtons(endGo);
                for (int i = 0; i < 28; i++)
                    checkButtons(propButton[i]);
            }

            base.Update(gameTime);
        }

        //checks if a button has been clicked. If it has, it executes code depending on what button was clicked
        public void checkButtons(Button b)
        {
            if (gameMouse.ButtonClick(b))
            {
                b.state = "Down";
                b.LoadContent();
                if (b == roll)
                {
                    rollButtonClicked();
                }
                if (b == buy)
                {
                    buyButtonClicked();
                }
                if (b == endGo)
                {
                    endGoButtonClicked();
                }
                if (b == sell)
                {
                    propManage = "Sell";
                }
                if (b == mortgage)
                {
                    propManage = "Mortgage";
                }
                if (b == bBuy)
                {
                    propManage = "Add B";
                }
                if (b == bSell)
                {
                    propManage = "Sell B";
                }
                if (b == bTwo)
                {
                    noOfPlayers = 2;
                    beginNameEntry();
                }
                if (b == bThree)
                {
                    noOfPlayers = 3;
                    beginNameEntry();
                }
                if (b == bFour)
                {
                    noOfPlayers = 4;
                    beginNameEntry();
                }
                if (b == bEnd)
                {
                    updateNameEntry(b);
                }
                for (int i = 0; i < 28; i++)
                {
                    if (b == propButton[i])
                    {
                        if (currentPlayer.hasMoved && propManage.Equals("Add B"))
                        {
                            moveInfoDown();
                            info[0] = "- You cannot do this after you have rolled";
                        }
                        else
                        {
                            moveInfoDown();
                            info[0] = propButton[i].Manage(propManage, currentPlayer);
                            propButton[i].prop.LoadContent(Content);
                            updateCurrentInfo();
                        }
                    }
                    if (b == bAlphabet[i])
                    {
                        updateNameEntry(b);
                    }
                }
            }
            else
            {
                b.state = "Up";
                b.LoadContent();
            }
        }

        public void updateNameEntry(Button b)
        {
            if (b != bEnd)
            {
                if (curName.Equals("")) //used as a check to see if the letter should be a capital
                {
                    if (!b.name.Equals("Space") && !b.name.Equals("Delete"))
                    {
                        curName = curName + b.name;
                    }
                }
                else if (curName.Length > 0 && curName.Length < 10) //adds a small case letter to the name
                {
                    if (!b.name.Equals("Delete"))
                    {
                        curName = curName + b.type;
                    }
                }
                if (!curName.Equals("") && b.name.Equals("Delete")) //removes the last character form the name
                {
                    curName = curName.Remove(curName.Length - 1);
                }
            }
            else if (b == bEnd && !curName.Equals(""))
            {
                //assigns the name entered to the correct player
                if (currentNum == 0)
                    name1 = curName;
                else if (currentNum == 1)
                    name2 = curName;
                else if (currentNum == 2)
                    name3 = curName;
                else if (currentNum == 3)
                    name4 = curName;

                curName = "";
                currentNum++;
                //checks if all of the players have had a name entered, and if so, moves onto the actual game
                if (currentNum == noOfPlayers)
                {
                    currentNum = 0;
                    setUpDone = true;
                }
            }
        }

        //moves the main menu onto the name entry stage
        public void beginNameEntry()
        {
            nameEntry = true;
            bTwo.visible = false;
            bThree.visible = false;
            bFour.visible = false;
            bEnd.visible = true;
            for (int i = 0; i < 28; i++)
                bAlphabet[i].visible = true;
        }

        public void rollButtonClicked()
        {
            if (currentPlayer.hasMoved == false)
            {
                die.resetDouble();
                die.Roll();
                bool rolledDouble = die.getDouble();

                if (currentPlayer.inJail && rolledDouble) //lets the player out of jail if they roll a double
                {
                    currentPlayer.inJail = false;
                    moveInfoDown();
                    info[0] = "- You are out of jail!";
                    die.doublesRolled = 0;
                }
                else if (currentPlayer.inJail && !rolledDouble) //keeps the player in jail if they didn't roll a double
                {
                    moveInfoDown();
                    info[0] = "- You are still in jail, you didn't get to move";
                }
                else if (!currentPlayer.inJail)
                {
                    if (die.doublesRolled < 3)
                    {
                        for (int i = 0; i < die.total; i++)
                        {
                            currentPlayer.move();
                            updatePlayerPos(currentPlayer);
                            if (currentPlayer.currentSpace == go)
                            {
                                moveInfoDown();
                                info[0] = "- You have collected £200!";
                                currentPlayer.deposit(200);
                                updateCurrentInfo();
                            }
                        }
                        moveInfoDown();
                        info[0] = "- You have moved to " + currentPlayer.currentSpace.name;
                        finishedMoving(currentPlayer);
                    }
                    else //sends the player to jail if they have rolled three doubles in a row
                    {
                        currentPlayer.currentSpace = goToJail;
                        finishedMoving(currentPlayer);
                        currentPlayer.hasMoved = true;
                    }
                }

                if (!rolledDouble)
                {
                    currentPlayer.hasMoved = true;
                }
            }
            else
            {
                moveInfoDown();
                info[0] = "- You have already rolled";
            }
        }

        public void buyButtonClicked()
        {
            bool rolledDouble = die.getDouble();

            if (currentPlayer.hasMoved || rolledDouble)
            {
                if (currentPlayer.currentSpace.buyable && currentPlayer.currentSpace.owner == null)
                {
                    currentPlayer.purchaseProperty(currentPlayer.currentSpace);
                    moveInfoDown();
                    if (currentPlayer == currentPlayer.currentSpace.owner)
                    {
                        info[0] = "- You have bought " + currentPlayer.currentSpace.name + " for £" + currentPlayer.currentSpace.buyPrice;
                        updateCurrentInfo();
                        for (int i = 0; i < 28; i++)
                        {
                            if (propButton[i].prop == currentPlayer.currentSpace)
                                propButton[i].visible = true;
                        }
                    }
                    else
                        info[0] = "- You do not have enough money to buy " + currentPlayer.currentSpace.name;
                }
                else if (currentPlayer.currentSpace.owner != null)
                {
                    moveInfoDown();
                    info[0] = "- This space is owned by " + currentPlayer.currentSpace.owner.name;
                }
                else if (!currentPlayer.currentSpace.buyable)
                {
                    moveInfoDown();
                    info[0] = "- This space cannot be bought";
                }
            }
            else
            {
                moveInfoDown();
                info[0] = "- You have to roll before you can buy a property";
            }
        }

        public void endGoButtonClicked()
        {
            if (currentPlayer.hasMoved)
            {
                int playersGone = 0;

                currentPlayer.hasMoved = false;
                //as this player's money is below 0, they are removed from the game
                if (currentPlayer.money < 0)
                    removePlayer(currentPlayer);

                //moves to the next player. This do loop is needed for when players are removed from the game
                do
                {
                    currentNum++;
                    if (currentNum > 3)
                        currentNum = 0;
                    currentPlayer = players[currentNum];
                } while (players[currentNum] == null);

                //checks if there is only one player left, so they can be declared the winner
                for (int i = 0; i < 4; i++)
                {
                    if (players[i] == null)
                        playersGone++;
                }

                if (playersGone < 3)
                {
                    moveInfoDown();
                    info[0] = "- It is now " + currentPlayer.name + "'s turn";
                    updateCurrentInfo();
                    propManage = "";
                    die.reset();
                }
                else if (playersGone == 3) //a winner has been found
                {
                    //makes the buttons unuseable
                    buy.visible = false;
                    sell.visible = false;
                    mortgage.visible = false;
                    bBuy.visible = false;
                    bSell.visible = false;
                    roll.visible = false;
                    endGo.visible = false;
                    for (int i = 0; i < 28; i++)
                        propButton[i].visible = false;
                    winner = true;
                }
            }
            else
            {
                moveInfoDown();
                info[0] = "- You haven't rolled yet or have rolled a double";
            }
        }

        public void removePlayer(Player p)
        {
            moveInfoDown();
            info[0] = "- " + p.name + " has been removed from the game";
            for (int i = 0; i < 28; i++)
            {
                if (p.owned[i] != null)
                    p.owned[i].owner = null; 
            }
            for (int i = 0; i < 4; i++)
            {
                if (p == players[i])
                    players[i] = null;
            }
        }

        public void finishedMoving(Player p)
        {
            //code for when the player lands on a card space
            if (p.currentSpace.type.Equals("Chance") || p.currentSpace.type.Equals("CChest"))
            {
                if (p.currentSpace.type.Equals("Chance"))
                {
                    moveInfoDown();
                    info[0] = chanceCard[chanceNum].pickupCard(p, 2);
                    chanceNum++;
                    if (chanceNum > 13)
                        chanceNum = 0;
                }
                if (p.currentSpace.type.Equals("CChest"))
                {
                    moveInfoDown();
                    info[0] = comChestCard[chestNum].pickupCard(p, 1);
                    chestNum++;
                    if (chestNum > 13)
                        chestNum = 0;
                }
                updateCurrentInfo();
                updatePlayerPos(p);
            }
            //code for when the player lands on the Go To Jail space
            else if (p.currentSpace.type.Equals("Go To Jail"))
            {
                String s;
                p.currentSpace = jail;
                s = p.setJail();
                moveInfoDown();
                info[0] = "Do not pass Go. Do not collect £200";
                moveInfoDown();
                info[0] = "- Go to jail. Directly to jail.";
                if (!s.Equals(" "))
                {
                    moveInfoDown();
                    info[0] = s;
                }
                updatePlayerPos(p);
            }
            //code for when the player lands on free parking
            else if (p.currentSpace.type.Equals("Free Park"))
            {
                p.deposit(300);
                moveInfoDown();
                info[0] = "- Congradulations!! You have earned £300!!";
            }
            //code for when the player lands on a fine space
            else if (p.currentSpace.type.Equals("F 100"))
            {
                p.withdraw(100);
                moveInfoDown();
                info[0] = "- You have payed £100 in fines";
            }
            else if (p.currentSpace.type.Equals("F 200"))
            {
                p.withdraw(200);
                moveInfoDown();
                info[0] = "- You have payed £200 in fines";
            }
            //code for when the player lands on a property space
            else if (p.currentSpace.buyable && p.currentSpace.owner != null && p.currentSpace.owner != p && !p.currentSpace.mortgage)
            {
                //this if checks ensure the payrent method isn't called if the player owns the property, the 
                //property doesn't have an owner, the property is mortgaged or the owner is in jail
                if (!p.currentSpace.owner.inJail)
                {
                    p.currentSpace.payRent(p, die.total);
                    moveInfoDown();
                    info[0] = "- You have payed £" + p.currentSpace.totalRent + " to " + p.currentSpace.owner.name;
                }
            }

            //updates the display to show the current amount of money
            updateCurrentInfo();

            //checks if the player's money is below 0
            if (p.money < 0)
            {
                moveInfoDown();
                info[0] = "you will be excluded from the game";
                moveInfoDown();
                info[0] = "to get this money back. If you end your turn before increasing your money,";
                moveInfoDown();
                info[0] = "- Your money is below £0. Please mortgage or sell properties";
            }
        }

        //updates the position of the players on the board
        public void updatePlayerPos(Player p)
        {
            if (p == players[0])
            {
                //sets the position for a corner space
                if (p.currentSpace.rect.Width == 100 & p.currentSpace.rect.Height == 100)
                {
                    p.pos = new Vector2(p.currentSpace.rect.X + 30, p.currentSpace.rect.Y + 30);
                    if (p.currentSpace == jail)
                    {
                        //affects the players position in the jail space depending on whether they are actually in jail or not
                        if (p.inJail)
                            p.pos = new Vector2(p.currentSpace.rect.X + 40, p.currentSpace.rect.Y + 30);
                        else
                            p.pos = new Vector2(p.currentSpace.rect.X + 5, p.currentSpace.rect.Y + 2);
                    }
                }
                //sets the position for the top and bottom row
                if (p.currentSpace.rect.Width == 60 & p.currentSpace.rect.Height == 100)
                {
                    p.pos = new Vector2(p.currentSpace.rect.X + 15, p.currentSpace.rect.Y + 50);
                }
                //sets the position for the left and right columns
                if (p.currentSpace.rect.Width == 100 & p.currentSpace.rect.Height == 60)
                {
                    p.pos = new Vector2(p.currentSpace.rect.X + 50, p.currentSpace.rect.Y + 15);
                }
            }

            if (p == players[1])
            {
                if (p.currentSpace.rect.Width == 100 & p.currentSpace.rect.Height == 100)
                {
                    p.pos = new Vector2(p.currentSpace.rect.X + 50, p.currentSpace.rect.Y + 30);
                    if (p.currentSpace == jail)
                    {
                        if (p.inJail)
                            p.pos = new Vector2(p.currentSpace.rect.X + 60, p.currentSpace.rect.Y + 30);
                        else
                            p.pos = new Vector2(p.currentSpace.rect.X + 5, p.currentSpace.rect.Y + 22);
                    }
                }

                if (p.currentSpace.rect.Width == 60 & p.currentSpace.rect.Height == 100)
                {
                    p.pos = new Vector2(p.currentSpace.rect.X + 25, p.currentSpace.rect.Y + 50);
                }
                if (p.currentSpace.rect.Width == 100 & p.currentSpace.rect.Height == 60)
                {
                    p.pos = new Vector2(p.currentSpace.rect.X + 50, p.currentSpace.rect.Y + 25);
                }
            }

            if (p == players[2])
            {
                if (p.currentSpace.rect.Width == 100 & p.currentSpace.rect.Height == 100)
                {
                    p.pos = new Vector2(p.currentSpace.rect.X + 50, p.currentSpace.rect.Y + 30);
                    if (p.currentSpace == jail)
                    {
                        if (p.inJail)
                            p.pos = new Vector2(p.currentSpace.rect.X + 30, p.currentSpace.rect.Y + 60);
                        else
                            p.pos = new Vector2(p.currentSpace.rect.X + 50, p.currentSpace.rect.Y + 80);
                    }
                }

                if (p.currentSpace.rect.Width == 60 & p.currentSpace.rect.Height == 100)
                {
                    p.pos = new Vector2(p.currentSpace.rect.X + 40, p.currentSpace.rect.Y + 40);
                }
                if (p.currentSpace.rect.Width == 100 & p.currentSpace.rect.Height == 60)
                {
                    p.pos = new Vector2(p.currentSpace.rect.X + 40, p.currentSpace.rect.Y + 40);
                }
            }

            if (p == players[3])
            {
                if (p.currentSpace.rect.Width == 100 & p.currentSpace.rect.Height == 100)
                {
                    p.pos = new Vector2(p.currentSpace.rect.X + 50, p.currentSpace.rect.Y + 30);
                    if (p.currentSpace == jail)
                    {
                        if (p.inJail)
                            p.pos = new Vector2(p.currentSpace.rect.X + 80, p.currentSpace.rect.Y + 10);
                        else
                            p.pos = new Vector2(p.currentSpace.rect.X + 80, p.currentSpace.rect.Y + 80);
                    }
                }

                if (p.currentSpace.rect.Width == 60 & p.currentSpace.rect.Height == 100)
                {
                    p.pos = new Vector2(p.currentSpace.rect.X + 40, p.currentSpace.rect.Y + 60);
                }
                if (p.currentSpace.rect.Width == 100 & p.currentSpace.rect.Height == 60)
                {
                    p.pos = new Vector2(p.currentSpace.rect.X + 60, p.currentSpace.rect.Y + 40);
                }
            }
        }

        //updates the text strings about the current player
        public void updateCurrentInfo()
        {
            name = "Name: " + currentPlayer.name;
            money = "Money: £" + currentPlayer.money;
        }

        //moves the game information text down one line, so the last line at the time is deleted and the firts line is left blank
        public void moveInfoDown()
        {
            for (int i = 5; i > 0; i--)
                info[i] = info[i - 1];
        }

        //determines which game screen to draw
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);
            theSpriteBatch.Begin();
            if (!inGame && !winner)
                DrawMenu();
            else if (inGame && !winner)
                DrawGame();
            else if (winner)
                DrawEnd();

            //the mouse is drawn last so it will always be on the top
            gameMouse.Draw(theSpriteBatch);
            theSpriteBatch.End();
            base.Draw(gameTime);
        }

        //draws the main menu screen
        public void DrawMenu()
        {
            theSpriteBatch.Draw(title, new Vector2(240, 0), Color.White);
            if (!nameEntry) //this draws the screen at player select
            {
                theSpriteBatch.DrawString(menuFont, "How many people are playing?", new Vector2(320, 280), Color.Black);
                bTwo.Draw(theSpriteBatch);
                bThree.Draw(theSpriteBatch);
                bFour.Draw(theSpriteBatch);
            }
            else //draws the name entry screen
            {
                if (currentNum == 0)
                    theSpriteBatch.DrawString(menuFont, "Enter the name for Player 1 (the dog)", new Vector2(250, 250), Color.Black);
                else if (currentNum == 1)
                    theSpriteBatch.DrawString(menuFont, "Enter the name for Player 2 (the hat)", new Vector2(250, 250), Color.Black);
                else if (currentNum == 2)
                    theSpriteBatch.DrawString(menuFont, "Enter the name for Player 3 (the iron)", new Vector2(245, 250), Color.Black);
                else if (currentNum == 3)
                    theSpriteBatch.DrawString(menuFont, "Enter the name for Player 4 (the car)", new Vector2(250, 250), Color.Black);

                theSpriteBatch.Draw(nameArea, new Vector2(425, 350), Color.White);
                bEnd.Draw(theSpriteBatch);
                for (int i = 0; i < 28; i++)
                    bAlphabet[i].Draw(theSpriteBatch);

                theSpriteBatch.DrawString(menuFont, curName, new Vector2(435, 350), Color.Black);
            }
        }

        //draws the game over / winner screen
        public void DrawEnd()
        {
            theSpriteBatch.Draw(title, new Vector2(240, 0), Color.White);
            theSpriteBatch.DrawString(menuFont, "CONGRADULATIONS!!!!!", new Vector2(365, 250), Color.Black);
            theSpriteBatch.Draw(nameArea, new Vector2(425, 350), Color.White);
            theSpriteBatch.DrawString(menuFont, currentPlayer.name, new Vector2(435, 350), Color.Black);
            theSpriteBatch.DrawString(menuFont, "You are the winner!!", new Vector2(415, 450), Color.Black);
        }

        //draws the in game screen
        public void DrawGame()
        {
            theSpriteBatch.Draw(playingBoard, new Vector2(0,0), Color.White);
            theSpriteBatch.Draw(playerArea, new Vector2(740, 0), Color.White);
            for (int i = 0; i < 4; i++)
            {
                if (players[i] != null)
                    players[i].Draw(theSpriteBatch);
            }
            currentPlayer.DrawCurrent(theSpriteBatch);
            buy.Draw(theSpriteBatch);
            sell.Draw(theSpriteBatch);
            mortgage.Draw(theSpriteBatch);
            endGo.Draw(theSpriteBatch);
            roll.Draw(theSpriteBatch);
            bBuy.Draw(theSpriteBatch);
            bSell.Draw(theSpriteBatch);

            //calls the draw method for the properties that may need to draw buildings
            brown1.Draw(theSpriteBatch);
            brown2.Draw(theSpriteBatch);
            blue1.Draw(theSpriteBatch);
            blue2.Draw(theSpriteBatch);
            blue3.Draw(theSpriteBatch);
            pink1.Draw(theSpriteBatch);
            pink2.Draw(theSpriteBatch);
            pink3.Draw(theSpriteBatch);
            orange1.Draw(theSpriteBatch);
            orange2.Draw(theSpriteBatch);
            orange3.Draw(theSpriteBatch);
            red1.Draw(theSpriteBatch);
            red2.Draw(theSpriteBatch);
            red3.Draw(theSpriteBatch);
            yellow1.Draw(theSpriteBatch);
            yellow2.Draw(theSpriteBatch);
            yellow3.Draw(theSpriteBatch);
            green1.Draw(theSpriteBatch);
            green2.Draw(theSpriteBatch);
            green3.Draw(theSpriteBatch);
            dark1.Draw(theSpriteBatch);
            dark2.Draw(theSpriteBatch);

            for (int i = 0; i < 28; i++)
            {
                if (propButton[i].prop.owner == currentPlayer)
                    propButton[i].Draw(theSpriteBatch);
            }

            theSpriteBatch.DrawString(infoFont, name, namePos, Color.Black);
            theSpriteBatch.DrawString(infoFont, money, moneyPos, Color.Black);
            for (int i = 0; i < 6; i++)
                theSpriteBatch.DrawString(font, info[i], infoPos[i], Color.Black);

            die.Draw(theSpriteBatch);

            
        }
    }
}
