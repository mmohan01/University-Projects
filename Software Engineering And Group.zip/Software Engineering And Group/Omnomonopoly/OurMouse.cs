﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

namespace Omnomonopoly
{
    public class OurMouse
    {
        private Vector2 mousePos;
        private Texture2D mouseTex;
        private MouseState mouseState;
        private Rectangle mouseRect;
        private bool mouseDown, mouseDownCheck;
        

        public OurMouse(Vector2 pos)
        {
            mousePos = pos; 
            mouseRect = new Rectangle((int)mousePos.X, (int)mousePos.Y, 2, 2);
            mouseDown = false;
            mouseDownCheck = false;
        }

        public void LoadContent(ContentManager theContentManager)
        {
            mouseTex = theContentManager.Load<Texture2D>("Mouse");
        }

        //On Update we will call this function
        public void Update(GameTime gameTime)
        {
            mouseState = Mouse.GetState(); //Gets the current state of the mouse

            //Updates the location of the mouse and the mouse rectangle
            mousePos.X = mouseState.X; 
            mousePos.Y = mouseState.Y;
            mouseRect.X = (int)mousePos.X;
            mouseRect.Y = (int)mousePos.Y;

            //uses if statements to imitates a single mouse click
            if (!mouseDownCheck && mouseState.LeftButton == ButtonState.Pressed)
            {
                mouseDown = true;
                mouseDownCheck = true;
            }
            else if (mouseDownCheck && mouseState.LeftButton == ButtonState.Pressed)
            {
                mouseDown = false;
            }
            else
            {
                mouseDown = false;
                mouseDownCheck = false;
            }
        }

        //Drawing function to be called in the main Draw function.
        public void Draw(SpriteBatch spriteBatch) //SpriteBatch to use.
        {
            spriteBatch.Draw(mouseTex, mousePos, Color.White); //Draw it using the batch.
        }

        public bool ButtonClick(Button b)
        {
            //checks if the mouse intersects the button
            //visible is needed so buttons that aren't visible on screen can't be clicked by this
            if (mouseRect.Intersects(b.rect) && mouseDown && b.visible)
            {
                return true;
            }
            else
                return false; 
        }
    }
}
