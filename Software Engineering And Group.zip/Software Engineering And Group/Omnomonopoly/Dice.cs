﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

namespace Omnomonopoly
{
    class Dice
    {
        private ContentManager theContentManager;
        private int die1 = 0;
        private int die2 = 0;
        private Texture2D dieImage1, dieImage2;
        private Vector2 diePos1, diePos2;
        private bool doubleRoll;
        public int total;
        private Random diceRoll = new Random();
        public int doublesRolled = 0;

        public Dice(ContentManager c)
        {
            theContentManager = c;
            diePos1 = new Vector2(260, 180);
            diePos2 = new Vector2(400, 180);
        }

        //resets the dice to its defaul values
        public void reset()
        {
            die1 = 0;
            die2 = 0;
            total = 0;
            doubleRoll = false;
            doublesRolled = 0;
            LoadContent();
        }

        //resets the bool value of doubleRoll to false
        public void resetDouble()
        {
            doubleRoll = false;
        }

        public bool getDouble()
        {
            return doubleRoll;
        }

        public void LoadContent()
        {
            dieImage1 = theContentManager.Load<Texture2D>("Dice " + die1);
            dieImage2 = theContentManager.Load<Texture2D>("Dice " + die2);
        }

        public void Roll()
        {
            die1 = (diceRoll.Next(6)) + 1;
            die2 = (diceRoll.Next(6)) + 1;

            //updates the image for the dice
            LoadContent();

            if (die1 == die2)
            {
                doubleRoll = true;
                doublesRolled++; //needed for checking how many times a player has a rolled a double
            }

            total = die1 + die2;
        }

        public void Draw(SpriteBatch theSpriteBatch)
        {
            theSpriteBatch.Draw(dieImage1, diePos1, Color.White);
            theSpriteBatch.Draw(dieImage2, diePos2, Color.White);
        }
    }
}
