﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class chaletsearch : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // Enables the validation controls
        vldCountry.Enabled = true;
        vldMaxPrice.Enabled = true;
        vldRating.Enabled = true;
        vldSchool.Enabled = true;

        // Appends the necessary text to the end of the SQL Select statement
        if (this.rdoSchool.SelectedValue != "null")
        {
            if ((this.rdoSchool.SelectedValue == "True"))
            {
                
                sqlResult.SelectCommand += "AND (skischoolAssociated = 1)";
            }
            else if (this.rdoSchool.SelectedValue == "False")
            {
                sqlResult.SelectCommand += "AND (skischoolAssociated = 0)";
            }
        }
        
    }    


    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        
        if (vldCountry.IsValid && vldMaxPrice.IsValid && vldRating.IsValid && vldSchool.IsValid)
        {
            // Makes the grid visible when there are valid search values.
            gridResult.Enabled = true;
            gridResult.Visible = true;

            // Displays error message when no results are found.
            if (this.gridResult.Rows.Count == 0)
            {
                var error = "<h2>No Results. Please Broaden Your Search!</h2>";
                var l = (Label)this.FindControl("lblEmpty"); // Finds the control lblEmpty
                l.Text = error;
            }
            else
            {
                var l = (Label)this.FindControl("lblEmpty"); // Finds the control lblEmpty
                l.Text = "";
            }
                
            // Databinds the gridview
            gridResult.DataBind();
        }
        
    }
    protected void ddlResorts_SelectedIndexChanged(object sender, EventArgs e)
    {
        // Negates the country dropdown list when selecting a resort to avoid conflicting search criteria
        if (ddlResorts.SelectedIndex != 0)
        {
            vldCountry.Enabled = false;
            vldCountry.Visible = false;
            ddlCountry.Enabled = false;
        }
    }
    protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
    {
        // Negates the resorts dropdown list when a country is selected to avoid possible conflicting search criteria
        if (ddlCountry.SelectedIndex !=0)
            ddlResorts.Enabled = false;
    }

    protected void pictureLoad(Object o, GridViewRowEventArgs e)
    {
        // Loads the image in the necessary area in the gridview
        if(e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Cells[12].Text = "<img id=\"picThumb\" src=\"images/" + e.Row.Cells[12].Text + "\" alt=\"" + e.Row.Cells[12].Text + "\"  />";
        }
    }

    /// <summary>
    /// Resets the values on the page to their original "empty" settings
    /// </summary>
    protected void btnRefresh_click(object sender, EventArgs e)
    {
        gridResult.Visible = false;
        gridResult.Enabled = false;
        ddlResorts.Enabled = true;
        ddlCountry.Enabled = true;
        vldCountry.Visible = true;
        vldCountry.Enabled = true;
        ddlResorts.SelectedIndex = 0;
        ddlCountry.SelectedIndex = 0;
        ddlRating.SelectedIndex = 0;
        txtmaxprice.Text = "0";
        txtminbeds.Text = "0";
        txtminprice.Text = "0";
        txtminheight.Text = "0";
        var l = (Label)this.FindControl("lblEmpty");
        l.Text = "";
    }
}
