﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class chaletdetails : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // Retrieves the resort passed through from resorts.aspx dropdownlist
        String resortTXT = Request.QueryString["resortName"];

        // Populates the repeater with necessary information
        chaletlblIMG.Text = "<img src=\"images/" + Request.QueryString["resortName"] + ".jpg\" width=130 height=90 /> <br />";
        chaletlbl.Text = resortTXT;
        srcChalets.SelectCommand = "SELECT * FROM [skichalets] WHERE ([resort] = @resort)";

        // Attaches text to the head of the repeater
        Label repeaterHeader = (Label)FindControl("repeaterHeader");
        repeaterHeader.Text = "Chalets At " + resortTXT;
    }

}
