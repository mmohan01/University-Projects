﻿using System;
using System.Web.UI.WebControls;
using System.Web.Security;

public partial class login : System.Web.UI.Page
{
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (FormsAuthentication.Authenticate(txtUsername.Text, txtPassword.Text))
        {
            lblStatus.Text = ("Welcome " + txtUsername.Text);
            FormsAuthentication.RedirectFromLoginPage(txtUsername.Text, true);
        }
        else
        {
            lblStatus.Text = "Invalid login!";
        }

    }
}
