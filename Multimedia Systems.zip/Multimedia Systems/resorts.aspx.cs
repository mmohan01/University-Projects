﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;


/// <summary>
/// DONT EDIT THIS FILE!!!
/// </summary>
public partial class resorts : System.Web.UI.Page
{
//************************************************************

    protected void Page_Load(object sender, EventArgs e)
    {
        // write a javaScript array to the client from the database table *resorts*
        ClientScriptManager cs = Page.ClientScript;
        DataView dView = (DataView)srcResorts.Select(DataSourceSelectArguments.Empty);
        String resortsContent = getArrayContents(dView, "resortName");
        cs.RegisterArrayDeclaration("resorts", resortsContent);

        //get a randon resort description
        Random rand = new Random();
        DataRow dRow;
        int max = dView.Table.Rows.Count - 1;
        int randNumb = rand.Next(0, max);
        dRow = dView.Table.Rows[randNumb];
        this.litResortDesc.InnerHtml = (String) dRow["resortDescription"];

        // write a javaScript array to the client from the database table *chalets*
        dView = (DataView)srcChalets.Select(DataSourceSelectArguments.Empty);
        String chaletsContent = getArrayContents(dView,"name");
        cs.RegisterArrayDeclaration("chalets", chaletsContent);

    }



    private String getArrayContents(DataView dv, String ColumnName)
    {
        String contentsString = "";
        String quoteChar = "\"";     
        DataRow dr;
        for (var i = 0; i < dv.Table.Rows.Count - 1; i++)
        {
            dr = dv.Table.Rows[i];
            contentsString += quoteChar + dr[ColumnName] + quoteChar + ",";
        }
        dr = dv.Table.Rows[dv.Table.Rows.Count - 1];
        contentsString += quoteChar + dr[ColumnName] + quoteChar;
        return contentsString;
    }
}
