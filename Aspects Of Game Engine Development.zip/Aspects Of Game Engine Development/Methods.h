// Michael Mohan 40020843
// 2D Physics Engine
#pragma region HEADER DECLARATIONS
#include "Headers.h"
#include "Globals.h"
#include "Circle.h"
#pragma endregion

void Keyboard(unsigned char key, int mousex, int mousey);
void SpecialKeys(int key, int x, int y);
void Move(GLfloat amount, bool x);
void ChangeProperties(GLfloat massAmount, GLfloat vAmountX, GLfloat vAmountY, int prop, bool up);
void Gravity(GLfloat g);
void Velocity();
void Text(char* String, GLfloat x, GLfloat y, GLfloat r, GLfloat g, GLfloat b);
void VariableText(char* String, GLfloat value, GLfloat x, GLfloat y, GLfloat r, GLfloat g, GLfloat b);
void IntersectionHUD(GLfloat depth, GLfloat xIntersect, GLfloat yIntersect, GLfloat x1, GLfloat y1, GLfloat x2, GLfloat y2);
GLfloat SquaredMagnitude(GLfloat x, GLfloat y);
GLfloat DotProduct(GLfloat x1, GLfloat y1, GLfloat x2, GLfloat y2);
void CollisionResolver(int type);
void SetupRC();
GLvoid IdleFunc(GLvoid);