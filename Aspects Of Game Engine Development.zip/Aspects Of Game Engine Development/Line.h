// Michael Mohan 40020843
// 2D Physics Engine
#pragma region HEADER DECLARATIONS
#pragma once
#include "Headers.h"
#include "Properties.h"
#pragma endregion

// Header file initializes methods for the main class.
class Line
{
	GLfloat startX, startY, endX, endY;
	Properties lineProperties;
public:
	Line(GLfloat sX, GLfloat sY, GLfloat eX, GLfloat eY, Properties lP);
	~Line();
	GLfloat GetStartX();
	GLfloat GetStartY();
	GLfloat GetEndX();
	GLfloat GetEndY();
	Properties GetLineProperties();
	void SetAttributes(GLfloat sX, GLfloat sY, GLfloat eX, GLfloat eY, Properties lP);

	void Draw(GLfloat colourR, GLfloat colourG, GLfloat colourB);
};