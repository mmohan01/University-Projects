// Michael Mohan 40020843
// 2D Physics Engine
#pragma region HEADER DECLARATIONS
#include "Headers.h"
#include "Methods.h"
#include "Collisions.h"
#include "Properties.h"
#include "Line.h"
#include "Circle.h"
#include "Square.h"
#include "Rect.h"
#pragma endregion

void RenderScene();