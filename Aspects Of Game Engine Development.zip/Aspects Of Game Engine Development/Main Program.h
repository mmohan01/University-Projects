// Michael Mohan 40020843
// 2D Physics Engine
#pragma region HEADER DECLARATIONS
#include "Methods.h"
#include "Render Scene.h"
#pragma endregion

int main(int argc, char* argv[]);