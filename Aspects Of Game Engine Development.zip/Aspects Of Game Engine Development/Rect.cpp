// Michael Mohan 40020843
// 2D Physics Engine
#pragma region HEADER DECLARATIONS
#include "StdAfx.h"
#include "Rect.h"
#pragma endregion

// Constructor to provide access to 
// the components of the object.
Rect::Rect(GLfloat cX, GLfloat cY, GLfloat hL, GLfloat hW, GLfloat a, Properties rP)
{
	centreX = cX;
	centreY = cY;
	halfLength = hL;
	halfWidth = hW;
	angle = a;
	rectProperties.SetAttributes(rP.GetMass(), rP.GetVelocityX(), rP.GetVelocityY(), rP.GetShapeIndex());

	// Defines the anglular rotation of the rect in radians
	GLfloat radians = angle*(3.141592654/180);

	// Constants are used to calculate the 
	// corner points of the rect object
	// at any angular rotation
	GLfloat xX = cos(radians)*halfWidth;
	GLfloat xY = sin(radians)*halfWidth;
	GLfloat yX = -sin(radians)*halfLength;
	GLfloat yY = cos(radians)*halfLength;

	// The corners of the rect object are defined
	cornersX[0] = centreX - xX + yX;
	cornersY[0] = centreY - xY + yY;
	cornersX[1] = centreX + xX + yX;
	cornersY[1] = centreY + xY + yY;
	cornersX[2] = centreX + xX - yX;
	cornersY[2] = centreY + xY - yY;
	cornersX[3] = centreX - xX - yX;
	cornersY[3] = centreY - xY - yY;
}

// Destructor cleans up the data by freeing 
// the memory when the program is finished.
Rect::~Rect()
{
	centreX = NULL;
	centreY = NULL;
	halfLength = NULL;
	halfWidth = NULL;
	angle = NULL;
	rectProperties.~Properties();

	for (int i = 0; i < 4; i++)
	{
		cornersX[i] = NULL;
		cornersY[i] = NULL;
	}
}

// Sequence of get and set functions
// used to provide access to the private
// members of the class object.
#pragma region GET/SET FUNCTIONS
GLfloat Rect::GetCentreX()
{
	return centreX;
}

GLfloat Rect::GetCentreY()
{
	return centreY;
}

GLfloat Rect::GetHalfLength()
{
	return halfLength;
}

GLfloat Rect::GetHalfWidth()
{
	return halfWidth;
}

GLfloat Rect::GetAngle()
{
	return angle;
}

Properties Rect::GetRectProperties()
{
	return rectProperties;
}

void Rect::SetAttributes(GLfloat cX, GLfloat cY, GLfloat hL, GLfloat hW, GLfloat a, Properties rP)
{
	centreX = cX;
	centreY = cY;
	halfLength = hL;
	halfWidth = hW;
	angle = a;
	rectProperties.SetAttributes(rP.GetMass(), rP.GetVelocityX(), rP.GetVelocityY(), rP.GetShapeIndex());
}
#pragma endregion

// Method used to draw a rectangle onto the 
// screen with a user defined colour, and 
// stored rotation.
void Rect::Draw(GLfloat colourR, GLfloat colourG, GLfloat colourB)
{
	GLfloat tempX = centreX;
	GLfloat tempY = centreY;
	glPushMatrix();
	centreX = 0.0f;
	centreY = 0.0f;

	// Translates the rectangle to the origin
	// and then rotates it by the given angle.
	glTranslatef(tempX, tempY, 0.0f); 
	glRotatef(angle, 0.0f, 0.0f, 1.0f);

	glColor3f(colourR, colourG, colourB);

	// Vertices for the 4 initial points of the
	// rectangle are calculated using the centre 
	// point, the width and the height of the rectangle.
	GLfloat x1, y1, x2, y2, x3, y3, x4, y4;
	x1 = centreX + halfWidth;
	y1 = centreY + halfLength;
	x2 = centreX - halfWidth;
	y2 = centreY + halfLength;
	x3 = centreX - halfWidth;
	y3 = centreY - halfLength;
	x4 = centreX + halfWidth;
	y4 = centreY - halfLength;

	// GL_QUADS used to draw the rectangle.
	glBegin(GL_QUADS);
        glVertex2f(x1, y1);
        glVertex2f(x2, y2);
        glVertex2f(x3, y3);
        glVertex2f(x4, y3);
    glEnd();

	// Returns the rect object to its
	// position in the world view.
	centreX = tempX;
	centreY = tempY;
	glPopMatrix();
}