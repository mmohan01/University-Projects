// Michael Mohan 40020843
// 2D Physics Engine
#pragma region HEADER DECLARATIONS
#pragma once
#include "Headers.h"
#include "Globals.h"
#include "Methods.h"
#include "Line.h"
#include "Circle.h"
#include "Square.h"
#include "Rect.h"
#pragma endregion

bool LineToLineCollision(GLfloat sX1, GLfloat sY1, GLfloat eX1, GLfloat eY1, GLfloat sX2, GLfloat sY2, GLfloat eX2, GLfloat eY2);
bool LineToCircleCollision(Line L, Circle C);
bool LineToSquareCollision(Line L, Square S);
bool LineToRectCollision(Line L, Rect R);

bool CircleToCircleCollision(Circle C1, Circle C2);
bool CircleToSquareCollision(Circle C, Square S);
bool CircleToRectCollision(Circle C, Rect R);

bool SquareToSquareCollision(Square S1, Square S2);
bool SquareToRectCollision(Square S, Rect R);

bool RectToRectCollision(Rect R1, Rect R2);