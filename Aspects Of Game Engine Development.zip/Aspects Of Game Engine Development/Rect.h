// Michael Mohan 40020843
// 2D Physics Engine
#pragma region HEADER DECLARATIONS
#pragma once
#include "Headers.h"
#include "Methods.h"
#include "Properties.h"

#pragma endregion

// Header file initializes methods for the main class.
class Rect
{
	GLfloat centreX, centreY, halfLength, halfWidth, angle, colourR, colourG, colourB;
	Properties rectProperties;
public:
	GLfloat cornersX[4], cornersY[4];

	Rect(GLfloat cX, GLfloat cY, GLfloat hL, GLfloat hW, GLfloat angle, Properties rP);
	~Rect();
	GLfloat GetCentreX();
	GLfloat GetCentreY();
	GLfloat GetHalfLength();
	GLfloat GetHalfWidth();
	GLfloat GetAngle();
	Properties GetRectProperties();
	void SetAttributes(GLfloat cX, GLfloat cY, GLfloat hL, GLfloat hW, GLfloat a, Properties rP);

	void Draw(GLfloat colourR, GLfloat colourG, GLfloat colourB);
};