// Michael Mohan 40020843
// 2D Physics Engine
#pragma region HEADER DECLARATIONS
#pragma once
#include "Headers.h"
#include "Methods.h"
#include "Properties.h"
#pragma endregion

// Header file initializes methods for the main class.
class Circle
{
	GLfloat centreX, centreY, radius;
	Properties circleProperties;
public:
	Circle(GLfloat cX, GLfloat cY, GLfloat r, Properties cP);
	~Circle();
	GLfloat GetCentreX();
	GLfloat GetCentreY();
	GLfloat GetRadius();
	Properties GetCircleProperties();
	void SetAttributes(GLfloat cX, GLfloat cY, GLfloat r, Properties cP);
	
	void Draw(GLfloat angle, GLfloat cR, GLfloat cG, GLfloat cB);
};

