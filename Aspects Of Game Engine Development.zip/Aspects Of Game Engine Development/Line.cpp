// Michael Mohan 40020843
// 2D Physics Engine
#pragma region HEADER DECLARATIONS
#include "StdAfx.h"
#include "Line.h"
#pragma endregion

// Constructor to provide access to 
// the components of the object.
Line::Line(GLfloat sX, GLfloat sY, GLfloat eX, GLfloat eY, Properties lP)
{
	startX = sX;
	startY = sY;
	endX = eX;
	endY = eY;
	lineProperties.SetAttributes(lP.GetMass(), lP.GetVelocityX(), lP.GetVelocityY(), lP.GetShapeIndex());
}

// Destructor cleans up the data by freeing 
// the memory when the program is finished.
Line::~Line()
{
	startX = NULL;
	startY = NULL;
	endX = NULL;
	endY = NULL;
	lineProperties.~Properties();
}


// Sequence of get and set functions
// used to provide access to the private
// members of the class object.
#pragma region GET/SET FUNCTIONS
GLfloat Line::GetStartX()
{
	return startX;
}

GLfloat Line::GetStartY()
{
	return startY;
}

GLfloat Line::GetEndX()
{
	return endX;
}

GLfloat Line::GetEndY()
{
	return endY;
}

Properties Line::GetLineProperties()
{
	return lineProperties;
}

void Line::SetAttributes(GLfloat sX, GLfloat sY, GLfloat eX, GLfloat eY, Properties lP)
{
	startX = sX;
	startY = sY; 
	endX = eX;
	endY = eY;
	lineProperties.SetAttributes(lP.GetMass(), lP.GetVelocityX(), lP.GetVelocityY(), lP.GetShapeIndex());
}
#pragma endregion

// Method used to draw a line onto the 
// screen with a user defined colour.
void Line::Draw(GLfloat colourR, GLfloat colourG, GLfloat colourB)
{
	glColor3f(colourR, colourG, colourB);

	// GL_LINES used to draw the line.
	glBegin(GL_LINES);
		glVertex2f (startX,startY);
		glVertex2f (endX,endY); 
	glEnd();
}