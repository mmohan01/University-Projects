// Michael Mohan 40020843
// 2D Physics Engine
#pragma region HEADER DECLARATIONS
#include "StdAfx.h"
#include "Methods.h"
#pragma endregion

// Uses event handling to detect user 
// input for movement functionality.
void Keyboard(unsigned char key, int mousex, int mousey)
{
	switch (key) 
	{
	// Escape.
	case 27:		
		PostQuitMessage(0);
		break;
	// Space.
	// Changes shapes.
	case 32:		
		changeShape += 1;

		if(changeShape > 3) 
			changeShape = 1;
		break;
	// Tab.
	// Changes between modifiable details.
	case 9:		
		modify += 1;

		if(modify > 4) 
			modify = 1;
		break;
	// Toggle gravity.
	case 'g':		
		tGravity = !tGravity;
		break;
	// Toggle second list of instructions.
	case 'i':
		instructions = !instructions;
		break;
	// Toggle velocities.
	case 'v':
		velocity = !velocity;
		break;
	// Debug mode.
	case 'q':
		debug = !debug;
		instructions = true;
		break;
	// changes the angle of the shapes
	// to allow for transform/rotate functionality.
	case 't':	
		for (int i = 0; i < shapeCounts[1]; i++)
		{
			circleAttributes[i][3] -= 5.0f;
			if (circleAttributes[i][3] < -360.0f)
				circleAttributes[i][3] = 0.0f;

			rectAttributes[i][4] -= 5.0f;
			if (rectAttributes[i][4] < -360.0f)
				rectAttributes[i][4] = 0.0f;

			squareAttributes[i][3] -= 5.0f;
			if (squareAttributes[i][3] < -360.0f)
				squareAttributes[i][3] = 0.0f;
		}
		break;
	// Resolves the collisions.
	case 'r':
		penetrating = !penetrating;
		break;
	// Allows for movement functionality.
	case 'a':
		Move(-0.05f, true);
		break;
	case 'd':
		Move(0.05f, true);
		break;
	case 'w':
		Move(0.05f, false);
		break;
	case 's':
		Move(-0.05, false);
	}
}

// Processes the special keys i.e. the arrow keys
// to allow for manipulation of gravity.
void SpecialKeys(int key, int x, int y)
{
	switch (key) 
	{
	// Modify properties.
	case GLUT_KEY_UP:
		switch (modify)
		{
		case 1:
			gravity += 0.01f;
			break;
		case 2:
			ChangeProperties(0.1f, 0.01f, 0.01f, 1, true);
			break;
		case 3:
			ChangeProperties(0.1f, 0.01f, 0.01f, 2, true);
			break;
		case 4:
			ChangeProperties(0.1f, 0.01f, 0.01f, 3, true);
			break;
		}
		break;
	// Modify Properties.
	case GLUT_KEY_DOWN:		
		switch (modify)
		{
		case 1:
			gravity -= 0.01f;
			break;
		case 2:
			ChangeProperties(0.1f, 0.01f, 0.01f, 1, false);
			break;
		case 3:
			ChangeProperties(0.1f, 0.01f, 0.01f, 2, false);
			break;
		case 4:
			ChangeProperties(0.1f, 0.01f, 0.01f, 3, false);
			break;
		}
		break;
	// Switch collision modes.
	case GLUT_KEY_LEFT:
		alternate = !alternate;
		break;
	// Switch resolution modes.
	case GLUT_KEY_RIGHT:
		instant = !instant;
		break;
	}
}

// Finds out which shape is being controlled
// and the moves it by the given amount.
void Move(GLfloat amount, bool x)
{
	if (x)
	{
		switch (changeShape)
			{
			case 1:
				circleAttributes[0][0] += amount;
				break;
			case 2:
				rectAttributes[0][0] += amount;
				break;
			case 3:
				squareAttributes[0][0] += amount;
				break;
			}
	}
	else
	{
		switch (changeShape)
		{
		case 1:
			circleAttributes[0][1] += amount;
			break;
		case 2:
			rectAttributes[0][1] += amount;
			break;
		case 3:
			squareAttributes[0][1] += amount;
			break;
		}
	}
}

// Finds out which shapes properties are
// being controlled and the moves them by the given amount.
void ChangeProperties(GLfloat massAmount, GLfloat vAmountX, GLfloat vAmountY, int prop, bool up)
{
	if (up)
	{
		switch (changeShape)
			{
			case 1:
				if (prop == 1)
					shapeProperties[1][0] += massAmount;
				else if (prop == 2)
					shapeProperties[1][1] += vAmountX;
				else
					shapeProperties[1][2] += vAmountY;
				break;
			case 2:
				if (prop == 1)
					shapeProperties[2][0] += massAmount;
				else if (prop == 2)
					shapeProperties[2][1] += vAmountX;
				else
					shapeProperties[2][2] += vAmountY;
				break;
			case 3:
				if (prop == 1)
					shapeProperties[3][0] += massAmount;
				else if (prop == 2)
					shapeProperties[3][1] += vAmountX;
				else
					shapeProperties[3][2] += vAmountY;
				break;
			}
	}
	else
	{
		switch (changeShape)
		{
		case 1:
			if (prop == 1)
				shapeProperties[1][0] -= massAmount;
			else if (prop == 2)
				shapeProperties[1][1] -= vAmountX;
			else
				shapeProperties[1][2] -= vAmountY;
			break;
		case 2:
			if (prop == 1)
				shapeProperties[2][0] -= massAmount;
			else if (prop == 2)
				shapeProperties[2][1] -= vAmountX;
			else
				shapeProperties[2][2] -= vAmountY;
			break;
		case 3:
			if (prop == 1)
				shapeProperties[3][0] -= massAmount;
			else if (prop == 2)
				shapeProperties[3][1] -= vAmountX;
			else
				shapeProperties[3][2] -= vAmountY;
			break;
		}
	}
}

// Creates the illusion of gravity in the program.
void Gravity(GLfloat g)
{
	for (int i = 0; i < shapeCounts[1]; i++)
	{
		circleAttributes[i][1] -= g;
	}

	for (int i = 0; i < shapeCounts[2]; i++)
	{
		rectAttributes[i][1] -= g;
	}

	for (int i = 0; i < shapeCounts[3]; i++)
	{
		squareAttributes[i][1] -= g;
	}

	// Restriction in bounds of the scene.
	for (int i = 0; i < shapeCounts[1]; i++)
	{
		for (int j = 0; j < 2; j++)
		{
			 if (circleAttributes[i][j] < (-1 + circleAttributes[i][2]))
				 circleAttributes[i][j] = -1 + circleAttributes[i][2];

			 if (circleAttributes[i][j] > (1 - circleAttributes[i][2]))
				 circleAttributes[i][j] = 1 - circleAttributes[i][2];
		}
	}

	// Restriction in bounds of the scene.
	for (int i = 0; i < shapeCounts[2]; i++)
	{
		for (int j = 0; j < 2; j++)
		{
			 if (rectAttributes[i][j] > (1 - rectAttributes[i][3-j]))
				 rectAttributes[i][j] = 1 - rectAttributes[i][3-j];

			 if (rectAttributes[i][j] < (-1 + rectAttributes[i][3-j]))
				 rectAttributes[i][j] = -1 + rectAttributes[i][3-j];
		}
	}

	// Restriction in bounds of the scene.
	for (int i = 0; i < shapeCounts[3]; i++)
	{
		for (int j = 0; j < 2; j++)
		{
			 if (squareAttributes[i][j] < (-1 + squareAttributes[i][2]))
				 squareAttributes[i][j] = -1 + squareAttributes[i][2];

			 if (squareAttributes[i][j] > (1 - squareAttributes[i][2]))
				 squareAttributes[i][j] = 1 - squareAttributes[i][2];
		}
	}
}

// Makes the shapes movesabout the screen by
// their given x and y velocities.
void Velocity()
{
	for (int i = 0; i < shapeCounts[1]; i++)
	{
		lineAttributes[i][0] += shapeProperties[0][1];
		lineAttributes[i][2] += shapeProperties[0][1];

		lineAttributes[i][1] += shapeProperties[0][2];
		lineAttributes[i][3] += shapeProperties[0][2];

		if (((lineAttributes[i][2]||lineAttributes[i][0]) >= 1)||((lineAttributes[i][0]||lineAttributes[i][2]) <= -1))
			shapeProperties[0][1] *= -1;

		if (((lineAttributes[i][1]||lineAttributes[i][3]) >= 1)||((lineAttributes[i][3]||lineAttributes[i][1]) <= -1))
			shapeProperties[0][2] *= -1;
	}

	for (int i = 0; i < shapeCounts[1]; i++)
	{
		circleAttributes[i][0] += shapeProperties[1][1];
		circleAttributes[i][1] += shapeProperties[1][2];

		if ((circleAttributes[i][0] <= (-1 + circleAttributes[i][2]))||(circleAttributes[i][0] >= (1 - circleAttributes[i][2])))
			shapeProperties[1][1] *= -1;

		if ((circleAttributes[i][1] <= (-1 + circleAttributes[i][2]))||(circleAttributes[i][1] >= (1 - circleAttributes[i][2])))
			shapeProperties[1][2] *= -1;
	}

	for (int i = 0; i < shapeCounts[1]; i++)
	{
		rectAttributes[i][0] += shapeProperties[2][1];
		rectAttributes[i][1] += shapeProperties[2][2];

		if ((rectAttributes[i][0] <= (-1 + rectAttributes[i][3]))||(rectAttributes[i][0] >= (1 - rectAttributes[i][3])))
			shapeProperties[2][1] *= -1;

		if ((rectAttributes[i][1] <= (-1 + rectAttributes[i][2]))||(rectAttributes[i][1] >= (1 - rectAttributes[i][2])))
			shapeProperties[2][2] *= -1;
	}

	for (int i = 0; i < shapeCounts[1]; i++)
	{
		squareAttributes[i][0] += shapeProperties[3][1];
		squareAttributes[i][1] += shapeProperties[3][2];

		if ((squareAttributes[i][0] <= (-1 + squareAttributes[i][2]))||(squareAttributes[i][0] >= (1 - squareAttributes[i][2])))
			shapeProperties[3][1] *= -1;

		if ((squareAttributes[i][1] <= (-1 + squareAttributes[i][2]))||(squareAttributes[i][1] >= (1 - squareAttributes[i][2])))
			shapeProperties[3][2] *= -1;
	}

}

// Method used to draw text onto the screen.
void Text(char* String, GLfloat x, GLfloat y, GLfloat r, GLfloat g, GLfloat b)
{
	char *i;
	glPushMatrix();
	glColor3f(r, g, b);
	glRasterPos2f(x, y); 
	for(i = String; *i != '\0'; i++) 
	{
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_10, *i);
	}
	glPopMatrix();
}

// Method used to output data from the program.
void VariableText(char* String, GLfloat value, GLfloat x, GLfloat y, GLfloat r, GLfloat g, GLfloat b)
{
	char textString[10];
	sprintf(textString, "%f", value);
	Text(String, x, y, r, g, b);
	Text(textString, (x + 0.4f), y, r, g, b);
}

// Method is used to output collision information
// onto the screen using the previously defined Text method.
void IntersectionHUD(GLfloat depth, GLfloat xIntersect, GLfloat yIntersect, GLfloat x1, GLfloat y1, GLfloat x2, GLfloat y2)
{
	if (debug != true)
	{
		VariableText("Collision Depth: ", depth, 0.4f, 0.9f, 0.0f, 0.0f, 0.0f);
		VariableText("X Intersection Point: ", xIntersect, 0.4f, 0.8f, 0.0f, 0.0f, 0.0f);
		VariableText("Y intersection Point: ", yIntersect, 0.4f, 0.7f, 0.0f, 0.0f, 0.0f);
	}

	// Collision normal is displayed onto the screen.
	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_LINES);
		glVertex2f (x1, y1);
		glVertex2f (x2, y2); 
	glEnd();
}

// Method finds the squared size of a vector.
GLfloat SquaredMagnitude(GLfloat x, GLfloat y)
{
	return (pow(x, 2) + pow(y, 2));
}

// Method finds the dot product of a vector.
GLfloat DotProduct(GLfloat x1, GLfloat y1, GLfloat x2, GLfloat y2)
{
	return ((x1*x2) + (y1*y2));
}

// Method used to resolve the 
// collisions between each shape.
void CollisionResolver(int type)
{
	GLfloat r, g, b;

	if (debug)
	{
		r = 1.0f;
		g = 1.0f;
		b = 1.0f;
	}
	else
	{
		r = 0.0f;
		g = 0.0f;
		b = 0.0f;
	}

	glColor3f(r, g, b);

	glBegin(GL_TRIANGLE_FAN);
	    glVertex2f(0.0f, 0.0f);
		// Loop used to create a smooth edge.
	    for (GLfloat angle = 0.0f; angle <= 360.0f; angle += 10.0f)
			glVertex2f(0.0f + 0.1f*GLfloat(sin(angle)), 0.0f + 0.1f*GLfloat(cos(angle)));
	glEnd();

	switch (type)
		{
		case 1:
			Text("Circle to Line collision",
			-0.2f, -0.2f, r, g, b);
		 break;
		 case 2:
			Text("Circle to Circle collision",
			-0.2f, -0.2f, r, g, b);
		 break;
		 case 3:
			Text("Circle to Square collision",
			-0.2f, -0.2f, r, g, b);
		 break;
		 case 4:
			Text("Circle to Rectangle collision",
			-0.2f, -0.2f, r, g, b);
		 break;
		 case 5:
			Text("Square to Line collision",
			-0.2f, -0.2f, r, g, b);
		 break;
		 case 6:
			Text("Square to Square collision",
			-0.2f, -0.2f, r, g, b);
		 break;
		 case 7:
			Text("Square to Rectangle collision",
			-0.2f, -0.2f, r, g, b);
		 break;
		 case 8:
			Text("Rectangle to Line collision",
			-0.2f, -0.2f, r, g, b);
		 break;
		 case 9:
			Text("Rectangle to Rectangle collision",
			-0.2f, -0.2f, r, g, b);
		 break;
		}
}

// This function does any needed 
// initialization before rendering.
void SetupRC()
{
	// Hidden surface removal.
	glEnable(GL_DEPTH_TEST);
	// Counter clock-wise polygons face out.
	glFrontFace(GL_CCW);
	// Do not calculate inside of the objects.
	glEnable(GL_CULL_FACE);

	// Enable color tracking.
	glEnable(GL_COLOR_MATERIAL);
	// Set Material properties to follow glColor values.
	glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);
	// Give the scene a cream background.		
	glClearColor(0.96f, 0.93f, 0.93f, 0.0f);
}

// Makes sure the program continuously
// redraws the scene.
GLvoid IdleFunc(GLvoid)
{
	glutPostRedisplay();
}