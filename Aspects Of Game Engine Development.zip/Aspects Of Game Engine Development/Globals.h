// Michael Mohan 40020843
// 2D Physics Engine
#pragma region GLOBAL VARIABLES
GLfloat lineAttributes[][4];
GLfloat circleAttributes[][4];
GLfloat rectAttributes[][5];
GLfloat squareAttributes[][4];
GLfloat shapeProperties[][3];
extern int shapeCounts[4];
extern int changeShape, modify;
extern GLfloat gravity;
extern bool tGravity, rotate, penetrating, instructions, debug, alternate, instant, velocity;
#pragma endregion