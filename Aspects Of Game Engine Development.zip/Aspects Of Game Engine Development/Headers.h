// Michael Mohan 40020843
// 2D Physics Engine
#pragma region HEADER DECLARATIONS
#include "stdafx.h"
#include <windows.h>
#include <math.h>
#include <string.h>
#include <iostream>
#include <vector>
//#include <GL\glut.h>
#include "glut.h"
#define NULL 0
using namespace std;
#pragma endregion