// Michael Mohan 40020843
// 2D Physics Engine
#pragma region HEADER DECLARATIONS
#include "StdAfx.h"
#include "Collisions.h"
#pragma endregion

#pragma region GLOBAL VARIABLES
bool penetrating = false;
#pragma endregion


// Method to test for Line to Line collision.
// it is used when checking for square/rect to
// line collision.
bool LineToLineCollision(GLfloat sX1, GLfloat sY1, GLfloat eX1, GLfloat eY1, GLfloat sX2, GLfloat sY2, GLfloat eX2, GLfloat eY2)
{
	float denominator = ((eY2 - sY2)*(eX1 - sX1)) - ((eX2 - sX2)*(eY1 - sY1));    
	float numerator1 = ((eX2 - sX2)*(sY1 - sY2)) - ((eY2 - sY2)*(sX1 - sX2));    
	float numerator2 = ((eX1 - sX1)*(sY1 - sY2)) - ((eY1 - sY1)*(sX1 - sX2));    
	if (denominator == 0.0f)    
	{  
		if ((numerator1 == 0.0f)&&(numerator2 == 0.0f))  
			// Coincident.
			return false;
		// The lines are parallel.
		return false;   
	}    
	float Projection1 = numerator1/denominator;    
	float Projection2 = numerator2/denominator;  
	GLfloat answerX = sX2 + Projection2*(eX2 - sX2);
	GLfloat answerY = sY2 + Projection2*(eY2 - sY2);
	
	return ((Projection1 >= 0.0f)&&(Projection1 <= 1.0f)&&(Projection2 >= 0.0f)&&(Projection2 <= 1.0f));
}

// Override used for rect to line/square/rect  collision
bool LineToLineCollision(GLfloat sX1, GLfloat sY1, GLfloat eX1, GLfloat eY1, GLfloat sX2, GLfloat sY2, GLfloat eX2, GLfloat eY2, Rect R, int shape, Properties oP)
{

	float denominator = ((eY2 - sY2)*(eX1 - sX1)) - ((eX2 - sX2)*(eY1 - sY1));    
	float numerator1 = ((eX2 - sX2)*(sY1 - sY2)) - ((eY2 - sY2)*(sX1 - sX2));    
	float numerator2 = ((eX1 - sX1)*(sY1 - sY2)) - ((eY1 - sY1)*(sX1 - sX2));    
	if (denominator == 0.0f)    
	{  
		if ((numerator1 == 0.0f)&&(numerator2 == 0.0f))  
			// Coincident.
			return false;
		// The lines are parallel.
		return false;   
	}    
	float Projection1 = numerator1/denominator;    
	float Projection2 = numerator2/denominator;  
	
	if ((Projection1 >= 0.0f)&&(Projection1 <= 1.0f)&&(Projection2 >= 0.0f)&&(Projection2 <= 1.0f))
	{
		// Code adapted from the circle to line
		// intersection method to find the closest
		// point of the line to the centre of the rect.
		GLfloat lineX = eX1 - sX1;
		GLfloat lineY = eY1 - sY1;
		GLfloat rectX = R.GetCentreX() - sX1;
		GLfloat rectY = R.GetCentreY() - sY1;
		GLfloat rectDotLine = DotProduct(rectX, rectY, lineX, lineY);
		GLfloat closestPointX = sX1 + (lineX*rectDotLine);
		GLfloat closestPointY = sY1 + (lineY*rectDotLine);

		// Finds the depth of intersection using a projected
		// radius on the axis of intersection .
		//GLfloat xCentreDistance = R.GetCentreX() - R2.GetCentreX();
		//GLfloat yCentreDistance = R.GetCentreY() - R2.GetCentreY();
		//GLfloat centreDistance = sqrt(SquaredMagnitude(xCentreDistance, yCentreDistance));
		//GLfloat xRect1Radius = R.GetCentreX() - closestPointX;
		//GLfloat yRect1Radius = R.GetCentreY() - closestPointY;
		//GLfloat rect1RadiusLength = sqrt(SquaredMagnitude(xRect1Radius, yRect1Radius));
		//GLfloat xRect2Radius = R2.GetCentreX() - closestPointX;
		//GLfloat yRect2Radius = R2.GetCentreY() - closestPointY;
		//GLfloat rect2RadiusLength = sqrt(SquaredMagnitude(xRect2Radius, yRect2Radius));
		//GLfloat depth = (rect1RadiusLength + rect2RadiusLength) - centreDistance;
		//IntersectionHUD(depth, closestPointX, closestPointY, C.GetCentreX(), 
		//				C.GetCentreY(), R.GetCentreX(), R.GetCentreY());

		if ((debug)&&(instructions))
		{
			Text("Rectangle To Rectangle/Line", -0.2f, 0.9, 1.0f, 1.0f, 1.0f);
			VariableText("Distance X: ", rectX, -0.2f, 0.8f, 1.0f, 1.0f, 1.0f);
			VariableText("Distance Y: ", rectY, -0.2f, 0.7f, 1.0f, 1.0f, 1.0f);
			VariableText("Projection: ", rectDotLine, -0.2f, 0.6f, 1.0f, 1.0f, 1.0f);
		}
		
		// Intersection point calculated as a point along
		// the current line of the rect using the projection
		// along it.
		GLfloat intersectionX = sX2 + Projection2*(eX2 - sX2);
		GLfloat intersectionY = sY2 + Projection2*(eY2 - sY2);

		if ((shape == 1)||(shape == 2))
			IntersectionHUD(closestPointX, intersectionX, intersectionY, 
							0.0f, 0.0f, 0.0f, 0.0f);
		else
			IntersectionHUD(closestPointX, intersectionX, intersectionY, 
							R.GetCentreX(), R.GetCentreY(), intersectionX, intersectionY);

		if (penetrating)
		{
			// Determine direction.
			bool directionX, directionY;
			GLfloat distanceX = R.GetCentreX() - closestPointX;
			GLfloat distanceY = R.GetCentreY() - closestPointX;

			directionX = ((distanceX >= 0) ? true : false);
			directionY = ((distanceY >= 0) ? true : false);
			
			// Alternate algorithm to 
			// take mass in consideration.
			if (alternate)
			{
				// Finds the masses of the shapes and calculates 
				// the ratio between them.
				Properties RProperties = R.GetRectProperties();
				GLfloat RMass = RProperties.GetMass();
		
				GLfloat RMassRatio = RMass/(RMass + oP.GetMass());
				//GLfloat OMassRatio = RMass/(SMass + oP.GetMass());
				GLfloat OMassRatio = 1 - RMassRatio;

				// The bigger the mass, the less the shape will
				// move. Therefore the values are switch to allow
				// realistic movement.
				GLfloat RInertia = OMassRatio;
				GLfloat OInertia = RMassRatio;

				rectAttributes[RProperties.GetShapeIndex()][0] += ((directionX) ? (RInertia*0.005) : (RInertia*-0.005));
				rectAttributes[RProperties.GetShapeIndex()][1] += ((directionY) ? (RInertia*0.005) : (RInertia*-0.005));

				// What is the other shape.
				switch (shape) 
				{
				case 1:		
					rectAttributes[oP.GetShapeIndex()][0] += ((directionX) ? (OInertia*-0.005) : (OInertia*0.005));
					rectAttributes[oP.GetShapeIndex()][1] += ((directionY) ? (OInertia*-0.005) : (OInertia*0.005));
					break;
				case 2:		
					squareAttributes[oP.GetShapeIndex()][0] += ((directionX) ? (OInertia*-0.005) : (OInertia*0.005));
					squareAttributes[oP.GetShapeIndex()][1] += ((directionY) ? (OInertia*-0.005) : (OInertia*0.005));
					break;
				case 3:
					lineAttributes[oP.GetShapeIndex()][0] += ((directionX) ? (OInertia*-0.005) : (OInertia*0.005));
					lineAttributes[oP.GetShapeIndex()][2] += ((directionX) ? (OInertia*-0.005) : (OInertia*0.005));
					lineAttributes[oP.GetShapeIndex()][1] += ((directionY) ? (OInertia*-0.005) : (OInertia*0.005));					
					lineAttributes[oP.GetShapeIndex()][3] += ((directionY) ? (OInertia*-0.005) : (OInertia*0.005));
					break;
				}
			}
			else
			{
				if ((changeShape == 3)||(tGravity))
				{
					squareAttributes[0][0] += ((directionX) ? 0.005 : -0.005);
					squareAttributes[0][1] += ((directionY) ? 0.005 : -0.005);
				}
				else
				{
					rectAttributes[0][0] += ((directionX) ? 0.005 : -0.005);
					rectAttributes[0][1] += ((directionY) ? 0.005 : -0.005);
				}
			}
		}
		return true;
	}
	else
		return false;
}

// Override used for square to line/square/rect collision
bool LineToLineCollision(GLfloat sX1, GLfloat sY1, GLfloat eX1, GLfloat eY1, GLfloat sX2, GLfloat sY2, GLfloat eX2, GLfloat eY2, Square S, bool box, Properties oP)
{
	float denominator = ((eY2 - sY2)*(eX1 - sX1)) - ((eX2 - sX2)*(eY1 - sY1));    
	float numerator1 = ((eX2 - sX2)*(sY1 - sY2)) - ((eY2 - sY2)*(sX1 - sX2));    
	float numerator2 = ((eX1 - sX1)*(sY1 - sY2)) - ((eY1 - sY1)*(sX1 - sX2));    
	if (denominator == 0.0f)    
	{  
		if ((numerator1 == 0.0f)&&(numerator2 == 0.0f))  
			// Coincident.
			return false;
		// The lines are parallel.
		return false;   
	}    
	float Projection1 = numerator1/denominator;    
	float Projection2 = numerator2/denominator;  
	GLfloat answerX = sX2 + Projection2*(eX2 - sX2);
	GLfloat answerY = sY2 + Projection2*(eY2 - sY2);
	
	if ((Projection1 >= 0.0f)&&(Projection1 <= 1.0f)&&(Projection2 >= 0.0f)&&(Projection2 <= 1.0f))
	{
		// Code adapted from the circle to line
		// intersection method to find the closest
		// point of the line to the centre of the square.
		GLfloat lineX = eX1 - sX1;
		GLfloat lineY = eY1 - sY1;
		GLfloat squareX = S.GetCentreX() - sX1;
		GLfloat squareY = S.GetCentreY() - sY1;
		GLfloat squareDotLine = DotProduct(squareX, squareY, lineX, lineY);
		GLfloat closestPointX = sX1 + (lineX*squareDotLine);
		GLfloat closestPointY = sY1 + (lineY*squareDotLine);

		if ((debug)&&(instructions))
		{
			Text("Square To Square/Line", 0.4f, 0.9, 1.0f, 1.0f, 1.0f);
			VariableText("Distance X: ", squareX, 0.4f, 0.8f, 1.0f, 1.0f, 1.0f);
			VariableText("Distance Y: ", squareY, 0.4f, 0.7f, 1.0f, 1.0f, 1.0f);
			VariableText("Projection: ", squareDotLine, 0.4f, 0.6f, 1.0f, 1.0f, 1.0f);
		}
		
		// Intersection point calculated as a point along
		// the current line of the square using the projection
		// along it.
		GLfloat intersectionX = sX2 + Projection2*(eX2 - sX2);
		GLfloat intersectionY = sY2 + Projection2*(eY2 - sY2);

		if (box)
			IntersectionHUD(closestPointX, intersectionX, intersectionY, 
							0.0f, 0.0f, 0.0f, 0.0f);
		else
			IntersectionHUD(closestPointX, intersectionX, intersectionY, 
							S.GetCentreX(), S.GetCentreY(), intersectionX, intersectionY);

		if (penetrating)
		{
			// Determine direction.
			bool directionX, directionY;
			GLfloat distanceX = S.GetCentreX() - closestPointX;
			GLfloat distanceY = S.GetCentreY() - closestPointX;
			directionX = ((distanceX >= 0) ? true : false);
			directionY = ((distanceY >= 0) ? true : false);
			
			// Alternate algorithm to 
			// take mass in consideration.
			if (alternate)
			{
				// Finds the masses of the shapes and calculates 
				// the ratio between them.
				Properties SProperties = S.GetSquareProperties();
				GLfloat SMass = SProperties.GetMass();
		
				GLfloat SMassRatio = SMass/(SMass + oP.GetMass());
				//GLfloat OMassRatio = RMass/(SMass + oP.GetMass());
				GLfloat OMassRatio = 1 - SMassRatio;

				// The bigger the mass, the less the shape will
				// move. Therefore the values are switch to allow
				// realistic movement.
				GLfloat SInertia = OMassRatio;
				GLfloat OInertia = SMassRatio;

				squareAttributes[SProperties.GetShapeIndex()][0] += ((directionX) ? (SInertia*-0.005) : (SInertia*0.005));
				squareAttributes[SProperties.GetShapeIndex()][1] += ((directionY) ? (SInertia*-0.005) : (SInertia*0.005));

				if(box)
				{
					squareAttributes[oP.GetShapeIndex()][0] += ((directionX) ? (OInertia*0.005) : (OInertia*-0.005));
					squareAttributes[oP.GetShapeIndex()][1] += ((directionY) ? (OInertia*0.005) : (OInertia*-0.005));
				}
				else
				{
					lineAttributes[oP.GetShapeIndex()][0] += ((directionX) ? (OInertia*0.005) : (OInertia*-0.005));
					lineAttributes[oP.GetShapeIndex()][2] += ((directionX) ? (OInertia*0.005) : (OInertia*-0.005));
					lineAttributes[oP.GetShapeIndex()][1] += ((directionY) ? (OInertia*0.005) : (OInertia*-0.005));					
					lineAttributes[oP.GetShapeIndex()][3] += ((directionY) ? (OInertia*0.005) : (OInertia*-0.005));
				}
			}
			else
			{
				if ((changeShape == 3)||(tGravity))
				{
					squareAttributes[0][0] += ((directionX) ? -0.005 : 0.005);
					squareAttributes[0][1] += ((directionY) ? -0.005 : 0.005);
				}
				else
				{
					rectAttributes[0][0] += ((directionX) ? 0.005 : -0.005);
					rectAttributes[0][1] += ((directionY) ? 0.005 : -0.005);
				}
			}
		}
		return true;
	}
	else
		return false;
}

// Method used to calculate if the circle object has collided 
// with a line and returns true if it has.
bool LineToCircleCollision(Line L, Circle C)
{
	// Find the vector that represents the line.
	GLfloat lineX = L.GetEndX() - L.GetStartX();
	GLfloat lineY = L.GetEndY() - L.GetStartY();

	// Find the vector that represents the distance between
	// the start of the line and the centre of the circle.
	GLfloat circleX = C.GetCentreX() - L.GetStartX();
	GLfloat circleY = C.GetCentreY() - L.GetStartY();

	// Find the projection of the centre of the circle onto
	// the line by taking the dot product of the circle vector
	// with the line vector (this projects the centre of the
	// circle onto the normal to the line), and divide it by
	// the dot product of the line vector with itself (this
	// can be used to represent finding the normal to the line
	// and calculating the dot product of the circle vector with
	// that).
	GLfloat circleDotLine = DotProduct(circleX, circleY, lineX, lineY);
	GLfloat lineDotLine = DotProduct(lineX, lineY, lineX, lineY);
	GLfloat circleProjLine = circleDotLine/lineDotLine;		
	
	// This conditional operator constrains the projection.
	// If the value is 0 the circle vector is perpendicular
	// to the line vector and if it is 1 it is parallel so
	// if the the value is less than 0 or more
	// than 1 it is clamped to that range.
	if (circleProjLine < 0)
		circleProjLine = 0;
	else if (circleProjLine > 1)
		circleProjLine = 1;

	// Find the closest point on the line to the centre
	// of the circle by using the projection as a scale
	// along the line (between 0 and 1) and adding it to
	// the initial point on the line.
	GLfloat closestPointX = L.GetStartX() + (lineX*circleProjLine);
	GLfloat closestPointY = L.GetStartY() + (lineY*circleProjLine);
		
	// Floats used to represent the magnitude
	// of the distance between the centres of
	// the points.
	GLfloat xDistance = C.GetCentreX() - closestPointX;
	GLfloat yDistance = C.GetCentreY() - closestPointY;

	// If the distance between the centre of the circle
	// and the closest point on the line is less than the
	// radius of the circle then they intersect.
	// I am adding the squared magnitude of the 2 values to 
	// prevent using the expensive square root operator:
	// sqrt(x2 + y2) < r ==> x2 + y2 < r2.
	if (SquaredMagnitude(xDistance, yDistance) < (pow(C.GetRadius(), 2)))
	{
		
		GLfloat depth = C.GetRadius() - sqrt(SquaredMagnitude(xDistance, yDistance));

		IntersectionHUD(depth, closestPointX, closestPointY, C.GetCentreX(), 
						C.GetCentreY(), closestPointX, closestPointY);

		if ((debug)&&(instructions == false))
		{
			Text("Circle To Line", -0.9f, 0.9, 1.0f, 1.0f, 1.0f);
			VariableText("Distance X: ", circleX, -0.9f, 0.8f, 1.0f, 1.0f, 1.0f);
			VariableText("Distance Y: ", circleY, -0.9f, 0.7f, 1.0f, 1.0f, 1.0f);
			VariableText("Projection: ", circleProjLine, -0.9f, 0.6f, 1.0f, 1.0f, 1.0f);
		}

		if (penetrating)
		{
			// Determine direction.
			bool directionX, directionY;
			directionX = ((xDistance >= 0) ? true : false);
			directionY = ((yDistance >= 0) ? true : false);
			
			// Determine between instant or gradual
			// collision resolution.
			float move = ((instant) ? depth : 0.005);

			// Alternate algorithm to 
			// take mass in consideration.
			if (alternate)
			{
				// Finds the masses of the circle and line and calculates 
				// the ratio between them.
				Properties CProperties = C.GetCircleProperties();
				GLfloat CMass = CProperties.GetMass();

				Properties LProperties = L.GetLineProperties();
				GLfloat LMass = LProperties.GetMass();
		
				GLfloat CMassRatio = CMass/(CMass + LMass);
				//GLfloat LMassRatio = LMass/(CMass + LMass);
				GLfloat LMassRatio = 1 - CMassRatio;

				// The bigger the mass, the less the shape will
				// move. Therefore the values are switch to allow
				// realistic movement.
				GLfloat CInertia = LMassRatio;
				GLfloat LInertia = CMassRatio;

				circleAttributes[CProperties.GetShapeIndex()][0] += ((directionX) ? (CInertia*move) : (CInertia*-move));
				circleAttributes[CProperties.GetShapeIndex()][1] += ((directionY) ? (CInertia*move) : (CInertia*-move));

				lineAttributes[LProperties.GetShapeIndex()][0] += ((directionX) ? (LInertia*-move) : (LInertia*move));
				lineAttributes[LProperties.GetShapeIndex()][2] += ((directionX) ? (LInertia*-move) : (LInertia*move));
				lineAttributes[LProperties.GetShapeIndex()][1] += ((directionY) ? (LInertia*-move) : (LInertia*move));
				lineAttributes[LProperties.GetShapeIndex()][3] += ((directionY) ? (LInertia*-move) : (LInertia*move));
			}
			else
			{
				circleAttributes[0][0] += ((directionX) ? move : -move);
				circleAttributes[0][1] += ((directionY) ? move : -move);
			}
				
		}
		return true;
	}
	else
		return false;
}

// Override used for rect to circle collision
bool LineToCircleCollision(GLfloat x1, GLfloat y1, GLfloat x2, GLfloat y2, Rect R, Circle C)
{
	// Find the vector that represents the line.
	GLfloat lineX = x2 - x1;
	GLfloat lineY = y2 - y1;

	// Find the vector that represents the distance between
	// the start of the line and the centre of the circle.
	GLfloat circleX = C.GetCentreX() - x1;
	GLfloat circleY = C.GetCentreY() - y1;

	// Find the projection of the centre of the circle onto
	// the line by taking the dot product of the circle vector
	// with the line vector (this projects the centre of the
	// circle onto the normal to the line), and divide it by
	// the dot product of the line vector with itself (this
	// can be used to represent finding the normal to the line
	// and calculating the dot product of the circle vector with
	// that).
	GLfloat circleDotLine = DotProduct(circleX, circleY, lineX, lineY);
	GLfloat lineDotLine = DotProduct(lineX, lineY, lineX, lineY);
	GLfloat circleProjLine = circleDotLine/lineDotLine;

	// This conditional operator constrains the projection.
	// If the value is 0 the circle vector is perpendicular
	// to the line vector and if it is 1 it is parallel so
	// any value outside of this range is irrelevant.
	if ((circleProjLine < 0)||(circleProjLine > 1))
		return false;
	else 
	{
		// Find the closest point on the line to the centre
		// of the circle by using the projection as a scale
		// along the line (between 0 and 1) and adding it to
		// the initial point on the line.
		GLfloat closestPointX = x1 + (lineX*circleProjLine);
		GLfloat closestPointY = y1 + (lineY*circleProjLine);
		
		// Floats used to represent the magnitude
		// of the distance between the centres of
		// the points.
		GLfloat xDistance = C.GetCentreX() - closestPointX;
		GLfloat yDistance = C.GetCentreY() - closestPointY;

		// If the distance between the centre of the circle
		// and the closest point on the line is less than the
		// radius of the circle then they intersect.
		// I am adding the squared magnitude of the 2 values to 
		// prevent using the expensive square root operator:
		// sqrt(x2 + y2) < r ==> x2 + y2 < r2.
		if (SquaredMagnitude(xDistance, yDistance) < (pow(C.GetRadius(), 2)))
		{
			// Finds the depth of intersection using a projected
			// radius on the axis of intersection .
			GLfloat xCentreDistance = C.GetCentreX() - R.GetCentreX();
			GLfloat yCentreDistance = C.GetCentreY() - R.GetCentreY();
			GLfloat centreDistance = sqrt(SquaredMagnitude(xCentreDistance, yCentreDistance));
			GLfloat xRectRadius = R.GetCentreX() - closestPointX;
			GLfloat yRectRadius = R.GetCentreY() - closestPointY;
			GLfloat rectRadiusLength = sqrt(SquaredMagnitude(xRectRadius, yRectRadius));
			GLfloat depth = (C.GetRadius() + rectRadiusLength) - centreDistance;
			IntersectionHUD(depth, closestPointX, closestPointY, C.GetCentreX(), 
							C.GetCentreY(), R.GetCentreX(), R.GetCentreY());

			if ((debug)&&(instructions == false))
			{
				Text("Circle To Rectangle", -0.2f, 0.9, 1.0f, 1.0f, 1.0f);
				VariableText("Distance X: ", circleX, -0.2f, 0.8f, 1.0f, 1.0f, 1.0f);
				VariableText("Distance Y: ", circleY, -0.2f, 0.7f, 1.0f, 1.0f, 1.0f);
				VariableText("Projection: ", circleProjLine, -0.2f, 0.6f, 1.0f, 1.0f, 1.0f);
			}

			if (penetrating)
			{
				// Determine direction.
				bool directionX, directionY;
				directionX = ((xDistance >= 0) ? true : false);
				directionY = ((yDistance >= 0) ? true : false);

				// Determine between instant or gradual
				// collision resolution.
				float move = ((instant) ? depth : 0.005);
			
				// Alternate algorithm to 
				// take mass in consideration.
				if (alternate)
				{
					// Finds the masses of the circles and calculates 
					// the ratio between them.
					Properties CProperties = C.GetCircleProperties();
					GLfloat CMass = CProperties.GetMass();

					Properties RProperties = R.GetRectProperties();
					GLfloat RMass = RProperties.GetMass();
		
					GLfloat CMassRatio = CMass/(CMass + RMass);
					//GLfloat RMassRatio = RMass/(CMass + RMass);
					GLfloat RMassRatio = 1 - CMassRatio;

					// The bigger the mass, the less the shape will
					// move. Therefore the values are switch to allow
					// realistic movement.
					GLfloat CInertia = RMassRatio;
					GLfloat RInertia = CMassRatio;

					circleAttributes[CProperties.GetShapeIndex()][0] += ((directionX) ? (CInertia*move) : (CInertia*-move));
					circleAttributes[CProperties.GetShapeIndex()][1] += ((directionY) ? (CInertia*move) : (CInertia*-move));

					rectAttributes[RProperties.GetShapeIndex()][0] += ((directionX) ? (RInertia*-move) : (RInertia*move));
					rectAttributes[RProperties.GetShapeIndex()][1] += ((directionY) ? (RInertia*-move) : (RInertia*move));
				}
				else
				{	
					if ((changeShape == 1)||(tGravity))
					{
						circleAttributes[0][0] += ((directionX) ? move : -move);
						circleAttributes[0][1] += ((directionY) ? move : -move);
					}
					else
					{
						rectAttributes[0][0] += ((directionX) ? -move : move);
						rectAttributes[0][1] += ((directionY) ? -move : move);
					}
				}
			}
			return true;
		}
		else
			return false;
	}
}

// Override used for square to circle collision
bool LineToCircleCollision(GLfloat x1, GLfloat y1, GLfloat x2, GLfloat y2, Square S, Circle C)
{
	// Find the vector that represents the line.
	GLfloat lineX = x2 - x1;
	GLfloat lineY = y2 - y1;

	// Find the vector that represents the distance between
	// the start of the line and the centre of the circle.
	GLfloat circleX = C.GetCentreX() - x1;
	GLfloat circleY = C.GetCentreY() - y1;

	// Find the projection of the centre of the circle onto
	// the line by taking the dot product of the circle vector
	// with the line vector (this projects the centre of the
	// circle onto the normal to the line), and divide it by
	// the dot product of the line vector with itself (this
	// can be used to represent finding the normal to the line
	// and calculating the dot product of the circle vector with
	// that).
	GLfloat circleDotLine = DotProduct(circleX, circleY, lineX, lineY);
	GLfloat lineDotLine = DotProduct(lineX, lineY, lineX, lineY);
	GLfloat circleProjLine = circleDotLine/lineDotLine;

	// This conditional operator constrains the projection.
	// If the value is 0 the circle vector is perpendicular
	// to the line vector and if it is 1 it is parallel so
	// any value outside of this range is irrelevant.
	if ((circleProjLine < 0)||(circleProjLine > 1))
		return false;
	else 
	{
		// Find the closest point on the line to the centre
		// of the circle by using the projection as a scale
		// along the line (between 0 and 1) and adding it to
		// the initial point on the line.
		GLfloat closestPointX = x1 + (lineX*circleProjLine);
		GLfloat closestPointY = y1 + (lineY*circleProjLine);
		
		// Floats used to represent the magnitude
		// of the distance between the centres of
		// the points.
		GLfloat xDistance = C.GetCentreX() - closestPointX;
		GLfloat yDistance = C.GetCentreY() - closestPointY;

		// If the distance between the centre of the circle
		// and the closest point on the line is less than the
		// radius of the circle then they intersect.
		// I am adding the squared magnitude of the 2 values to 
		// prevent using the expensive square root operator:
		// sqrt(x2 + y2) < r ==> x2 + y2 < r2.
		if (SquaredMagnitude(xDistance, yDistance) < (pow(C.GetRadius(), 2)))
		{
			// Finds the depth of intersection using a projected
			// radius on the axis of intersection .
			GLfloat xCentreDistance = C.GetCentreX() - S.GetCentreX();
			GLfloat yCentreDistance = C.GetCentreY() - S.GetCentreY();
			GLfloat centreDistance = sqrt(SquaredMagnitude(xCentreDistance, yCentreDistance));
			GLfloat xRectRadius = S.GetCentreX() - closestPointX;
			GLfloat yRectRadius = S.GetCentreY() - closestPointY;
			GLfloat rectRadiusLength = sqrt(SquaredMagnitude(xRectRadius, yRectRadius));
			GLfloat depth = (C.GetRadius() + rectRadiusLength) - centreDistance;
			IntersectionHUD(depth, closestPointX, closestPointY, C.GetCentreX(), 
							C.GetCentreY(), S.GetCentreX(), S.GetCentreY());

			if ((debug)&&(instructions == false))
			{
				Text("Circle To Square", 0.4f, 0.9, 1.0f, 1.0f, 1.0f);
				VariableText("Distance X: ", circleX, 0.4, 0.8f, 1.0f, 1.0f, 1.0f);
				VariableText("Distance Y: ", circleY, 0.4, 0.7f, 1.0f, 1.0f, 1.0f);
				VariableText("Projection: ", circleProjLine, 0.4, 0.6f, 1.0f, 1.0f, 1.0f);
			}

			if (penetrating)
			{
				// Determine direction.
				bool directionX, directionY;
				directionX = ((xDistance >= 0) ? true : false);
				directionY = ((yDistance >= 0) ? true : false);

				// Determine between instant or gradual
				// collision resolution.
				float move = ((instant) ? depth : 0.005);
			
				// Alternate algorithm to 
				// take mass in consideration.
				if (alternate)
				{
					// Finds the masses of the circles and calculates 
					// the ratio between them.
					Properties CProperties = C.GetCircleProperties();
					GLfloat CMass = CProperties.GetMass();

					Properties SProperties = S.GetSquareProperties();
					GLfloat SMass = SProperties.GetMass();
		
					GLfloat CMassRatio = CMass/(CMass + SMass);
					//GLfloat SMassRatio = SMass/(CMass + SMass);
					GLfloat SMassRatio = 1 - CMassRatio;

					// The bigger the mass, the less the shape will
					// move. Therefore the values are switch to allow
					// realistic movement.
					GLfloat CInertia = SMassRatio;
					GLfloat SInertia = CMassRatio;

					circleAttributes[CProperties.GetShapeIndex()][0] += ((directionX) ? (CInertia*move) : (CInertia*-move));
					circleAttributes[CProperties.GetShapeIndex()][1] += ((directionY) ? (CInertia*move) : (CInertia*-move));

					squareAttributes[SProperties.GetShapeIndex()][0] += ((directionX) ? (SInertia*-move) : (SInertia*move));
					squareAttributes[SProperties.GetShapeIndex()][1] += ((directionY) ? (SInertia*-move) : (SInertia*move));
				}
				else
				{
					if ((changeShape == 1)||(tGravity))
					{
						circleAttributes[0][0] += ((directionX) ? move : -move);
						circleAttributes[0][1] += ((directionY) ? move : -move);
					}
					else
					{
						squareAttributes[0][0] += ((directionX) ? -move : move);
						squareAttributes[0][1] += ((directionY) ? -move : move);
					}
				}
			}
			return true;
		}
		else
			return false;
	}
}

// Method used to calculate if the square object has collided 
// with a line and returns true if it has.
bool LineToSquareCollision(Line L, Square S)
{
	int iPlus;

	// For each line of the square object, a line
	// to line collision is checked for and if there
	// is an intersect, true is returned.
	for (int i = 0; i < 4; i++)
	{
		iPlus = i + 1;
		if (i == 3)
			iPlus = 0;

		if (LineToLineCollision(L.GetStartX(), L.GetStartY(), L.GetEndX(), L.GetEndY(), 
								S.cornersX[i], S.cornersY[i], S.cornersX[iPlus], S.cornersY[iPlus], S, false, L.GetLineProperties()))
			return true;
	}
	// If no intersectsions 
	// occured then false is returned.
	return false;
}

// Method used to calculate if the rect object has collided 
// with a line and returns true if it has.
bool LineToRectCollision(Line L, Rect R)
{
	int iPlus;

	// For each line of the rect object, a line
	// to line collision is checked for and if there
	// is an intersect, true is returned.
	for (int i = 0; i < 4; i++)
	{
		iPlus = i + 1;
		if (i == 3)
			iPlus = 0;

		if (LineToLineCollision(L.GetStartX(), L.GetStartY(), L.GetEndX(), L.GetEndY(), 
								R.cornersX[i], R.cornersY[i], R.cornersX[iPlus], R.cornersY[iPlus], R, 3, L.GetLineProperties()))
		{
			//GLfloat intersectX = 0.0f;
			//GLfloat intersectY = 0.0f;
			//GLfloat Line1AxisX = L.GetEndX() - L.GetStartX();
			//GLfloat Line1AxisY = L.GetEndY() - L.GetStartY();
			//GLfloat Line2AxisX = R.cornersX[iPlus] - R.cornersX[i];
			//GLfloat Line2AxisY = R.cornersY[iPlus] - R.cornersY[i];
			//GLfloat dot = DotProduct(Line1AxisX, Line1AxisY, Line2AxisX, Line2AxisY);
			//GLfloat Line1LengthSquared = SquaredMagnitude(Line1AxisX, Line1AxisY);
			//GLfloat Line2LengthSquared = SquaredMagnitude(Line2AxisX, Line2AxisY);
			//GLfloat determiner = pow(dot, 2)/(Line1LengthSquared*Line2LengthSquared);
			//GLfloat closestPointX;
			//GLfloat closestPointY;
			//if (determiner == 0.0f)
			//{
			//	if (Line1LengthSquared < Line2LengthSquared)
			//	{
			//		intersectX = Line2AxisX/2;
			//		intersectY = Line2AxisY/2;
			//	}
			//	else
			//	{
			//		intersectX = Line1AxisX/2;
			//		intersectY = Line1AxisY/2;
			//	}
			//}
			//else
			//{

			//}
			//GLfloat depth = 0.0f;
			//IntersectionHUD(depth, intersectX, intersectY, R.GetCentreX(), 
			//				R.GetCentreY(), intersectX, intersectY);
			return true;
		}
	}
	// If no intersectsions 
	// occured then false is returned.
	return false;
}

// Method used to calculate if the circle object has collided 
// with another circle object and returns true if it has.
bool CircleToCircleCollision(Circle C1, Circle C2)
{
	// Floats used to represent the magnitude
	// of the distance between the centres of
	// the circles.
	GLfloat xDistance = C1.GetCentreX() - C2.GetCentreX();
	GLfloat yDistance = C1.GetCentreY() - C2.GetCentreY();

	// If the distance between the centre points of the 2 circles 
	// is less than the sum of their radii then the circles 
	// must be intersecting. 
	// I am adding the squared magnitude of the 2 values to 
	// prevent using the expensive square root operator:
	// sqrt(x2 + y2) < r1 + r2 ==> x2 + y2 < (r1 + r2)2.
	if (SquaredMagnitude(xDistance, yDistance) < (pow(C1.GetRadius() + C2.GetRadius(), 2)))
	{
		// Also calculates and outputs the depth of the collision,
		// the normal of the collision and an intersection point at
		// the overlap of the 2 circles (for circles with the same radius
		// the intersection point is in the middle of the overlap otherwise
		// it will be offset closer to the larger circle).
		GLfloat depth = (C1.GetRadius() + C2.GetRadius()) - sqrt(SquaredMagnitude(xDistance, yDistance));
		GLfloat xIntersect = C2.GetCentreX() + (xDistance/2);
		GLfloat yIntersect = C2.GetCentreY() + (yDistance/2);
		IntersectionHUD(depth, xIntersect, yIntersect, C1.GetCentreX(), 
						C1.GetCentreY(), C2.GetCentreX(), C2.GetCentreY());
		if ((debug)&&(instructions))
		{
			Text("Circle To Circle", -0.9, 0.9, 1.0f, 1.0f, 1.0f);
			VariableText("Distance X: ", xDistance, -0.9f, 0.8f, 1.0f, 1.0f, 1.0f);
			VariableText("Distance Y: ", yDistance, -0.9f, 0.7f, 1.0f, 1.0f, 1.0f);
			VariableText("Squared Magnitude: ", SquaredMagnitude(xDistance, yDistance), -0.9f, 0.6f, 1.0f, 1.0f, 1.0f);
		}

		if (penetrating)
		{
			// Determine direction.
			bool directionX, directionY;
			directionX = ((xDistance >= 0) ? true : false);
			directionY = ((yDistance >= 0) ? true : false);

			// Determine between instant or gradual
			// collision resolution.
			float move = ((instant) ? depth : 0.005);

			// Alternate algorithm to 
			// take mass in consideration.
			if (alternate)
			{
				// Finds the masses of the circles and calculates 
				// the ratio between them.
				Properties C1Properties = C1.GetCircleProperties();
				GLfloat C1Mass = C1Properties.GetMass();

				Properties C2Properties = C2.GetCircleProperties();
				GLfloat C2Mass = C2Properties.GetMass();
		
				GLfloat C1MassRatio = C1Mass/(C1Mass + C2Mass);
				//GLfloat C2MassRatio = C2Mass/(C1Mass + C2Mass);
				GLfloat C2MassRatio = 1 - C1MassRatio;

				// The bigger the mass, the less the shape will
				// move. Therefore the values are switch to allow
				// realistic movement.
				GLfloat C1Inertia = C2MassRatio;
				GLfloat C2Inertia = C1MassRatio;

				circleAttributes[C1Properties.GetShapeIndex()][0] += ((directionX) ? (C1Inertia*move) : (C1Inertia*-move));
				circleAttributes[C1Properties.GetShapeIndex()][1] += ((directionY) ? (C1Inertia*move) : (C1Inertia*-move));

				circleAttributes[C2Properties.GetShapeIndex()][0] += ((directionX) ? (C2Inertia*-move) : (C2Inertia*move));
				circleAttributes[C2Properties.GetShapeIndex()][1] += ((directionY) ? (C2Inertia*-move) : (C2Inertia*move));
			}
			else
			{
				circleAttributes[0][0] += ((directionX) ? (move) : (-move));
				circleAttributes[0][1] += ((directionY) ? (move) : (-move));
			}
		}
		return true;
	}
	else
		return false;
}

// Alternate method used to take mass into consideration

// Method used to calculate if the circle object has collided 
// with a square and returns true if it has.
bool CircleToSquareCollision(Circle C, Square S)
{
	int iPlus;

	// Check for collison with the circle 
	// and the faces of the square.
	for (int i = 0; i < 4; i++)
	{
		iPlus = i + 1;
		if (i == 3)
			iPlus = 0;

		// Performs a line to circle collision check with
		// each edge of the square.
		if (LineToCircleCollision(S.cornersX[i], S.cornersY[i], 
								  S.cornersX[iPlus], S.cornersY[iPlus], S, C))
			return true;
	}

	// Check for collision with the circle 
	// and the vertices of the square.
	for (int j = 0; j < 4; j++)
	{
		// Find the distance between each corner
		// of the square and the centre of the circle.
		GLfloat xDistance = C.GetCentreX() - S.cornersX[j];
		GLfloat yDistance = C.GetCentreY() - S.cornersY[j];

		// If the distance between the corner of the square and the
		// centre of the circle is less than the radius of the circle,
		// then the circle is intersecting with the square. To avoid the
		// use of the expensive square root operator the squared distance
		// is used instead:
		// sqrt(distanceX2 + distanceY2) < radius --> distanceX2 + distanceY2 < radius2.
		if (SquaredMagnitude(xDistance, yDistance)  < pow(C.GetRadius(), 2))
		{
			GLfloat depth = C.GetRadius() - sqrt(SquaredMagnitude(xDistance, yDistance));
			IntersectionHUD(depth, S.cornersX[j], S.cornersY[j], C.GetCentreX(), 
							C.GetCentreY(), S.GetCentreX(), S.GetCentreY());

			if (penetrating)
			{
				// Determine direction.
				bool directionX, directionY;
				directionX = ((xDistance >= 0) ? true : false);
				directionY = ((yDistance >= 0) ? true : false);
			
				// Determine between instant or gradual
				// collision resolution.
				float move = ((instant) ? depth : 0.005);

				// Alternate algorithm to 
				// take mass in consideration.
				if (alternate)
				{
					// Finds the masses of the circles and calculates 
					// the ratio between them.
					Properties CProperties = C.GetCircleProperties();
					GLfloat CMass = CProperties.GetMass();

					Properties SProperties = S.GetSquareProperties();
					GLfloat SMass = SProperties.GetMass();
		
					GLfloat CMassRatio = CMass/(CMass + SMass);
					//GLfloat SMassRatio = SMass/(CMass + SMass);
					GLfloat SMassRatio = 1 - CMassRatio;

					// The bigger the mass, the less the shape will
					// move. Therefore the values are switch to allow
					// realistic movement.
					GLfloat CInertia = SMassRatio;
					GLfloat SInertia = CMassRatio;

					circleAttributes[CProperties.GetShapeIndex()][0] += ((directionX) ? (CInertia*move) : (CInertia*-move));
					circleAttributes[CProperties.GetShapeIndex()][1] += ((directionY) ? (CInertia*move) : (CInertia*-move));

					squareAttributes[SProperties.GetShapeIndex()][0] += ((directionX) ? (SInertia*-move) : (SInertia*move));
					squareAttributes[SProperties.GetShapeIndex()][1] += ((directionY) ? (SInertia*-move) : (SInertia*move));
				}
				else
				{
					if ((changeShape == 1)||(tGravity))
					{
						circleAttributes[0][0] += ((directionX) ? move : -move);
						circleAttributes[0][1] += ((directionY) ? move : -move);
					}
					else
					{
						squareAttributes[0][0] += ((directionX) ? -move : move);
						squareAttributes[0][1] += ((directionY) ? -move : move);
					}
				}
			}
			return true;
		}
	}
	// If no collision has occured by now, return false.
	return false;
}

// Method used to calculate if the circle object has collided 
// with a rectangle and returns true if it has.
bool CircleToRectCollision(Circle C, Rect R)
{
	int iPlus;

	// Check for collison with the circle 
	// and the faces of the rect.
	for (int i = 0; i < 4; i++)
	{
		iPlus = i + 1;
		if (i == 3)
			iPlus = 0;

		// Performs a line to circle collision check with
		// each edge of the rect.
		if (LineToCircleCollision(R.cornersX[i], R.cornersY[i], 
								  R.cornersX[iPlus], R.cornersY[iPlus], R, C))
			return true;
	}

	// Check for collision with the circle 
	// and the vertices of the rect.
	for (int j = 0; j < 4; j++)
	{
		// Find the distance between each corner
		// of the rect and the centre of the circle.
		GLfloat xDistance = C.GetCentreX() - R.cornersX[j];
		GLfloat yDistance = C.GetCentreY() - R.cornersY[j];

		// If the distance between the corner of the rect and the
		// centre of the circle is less than the radius of the circle,
		// then the circle is intersecting with the rect. To avoid the
		// use of the expensive square root operator the squared distance
		// is used instead:
		// sqrt(distanceX2 + distanceY2) < radius --> distanceX2 + distanceY2 < radius2.
		if (SquaredMagnitude(xDistance, yDistance)  < pow(C.GetRadius(), 2))
		{
			GLfloat depth = C.GetRadius() - sqrt(SquaredMagnitude(xDistance, yDistance));
			IntersectionHUD(depth, R.cornersX[j], R.cornersY[j], C.GetCentreX(), 
							C.GetCentreY(), R.GetCentreX(), R.GetCentreY());

			if (penetrating)
			{
				// Determine direction.
				bool directionX, directionY;
				directionX = ((xDistance >= 0) ? true : false);
				directionY = ((yDistance >= 0) ? true : false);

				// Determine between instant or gradual
				// collision resolution.
				float move = ((instant) ? depth : 0.005);
			
				// Alternate algorithm to 
				// take mass in consideration.
				if (alternate)
				{
					// Finds the masses of the circles and calculates 
					// the ratio between them.
					Properties CProperties = C.GetCircleProperties();
					GLfloat CMass = CProperties.GetMass();

					Properties RProperties = R.GetRectProperties();
					GLfloat RMass = RProperties.GetMass();
		
					GLfloat CMassRatio = CMass/(CMass + RMass);
					//GLfloat RMassRatio = RMass/(CMass + RMass);
					GLfloat RMassRatio = 1 - CMassRatio;

					// The bigger the mass, the less the shape will
					// move. Therefore the values are switch to allow
					// realistic movement.
					GLfloat CInertia = RMassRatio;
					GLfloat RInertia = CMassRatio;

					circleAttributes[CProperties.GetShapeIndex()][0] += ((directionX) ? (CInertia*move) : (CInertia*-move));
					circleAttributes[CProperties.GetShapeIndex()][1] += ((directionY) ? (CInertia*move) : (CInertia*-move));

					rectAttributes[RProperties.GetShapeIndex()][0] += ((directionX) ? (RInertia*-move) : (RInertia*move));
					rectAttributes[RProperties.GetShapeIndex()][1] += ((directionY) ? (RInertia*-move) : (RInertia*move));
				}
				else
				{
					if ((changeShape == 1)||(tGravity))
					{
						circleAttributes[0][0] += ((directionX) ? move : -move);
						circleAttributes[0][1] += ((directionY) ? move : -move);
					}
					else
					{
						rectAttributes[0][0] += ((directionX) ? -move : move);
						rectAttributes[0][1] += ((directionY) ? -move : move);
					}
				}
			}
			return true;
		}
	}
	// If no collision has occured by now, return false.
	return false;
}

// Method used to calculate if the circle object has collided 
// with a square and returns true if it has.
bool SquareToSquareCollision(Square S1, Square S2)
{
	int iPlus, jPlus;

	for (int i = 0; i < 4; i++)
	{
		iPlus = i + 1;
		if (i == 3)
			iPlus = 0;

		for (int j = 0; j < 4; j++)
		{
			jPlus = j + 1;
			if (j == 3)
				jPlus = 0;

			// For each side of each Square, a line to line collision
			// is checked for and if there is an intersection, true is returned.
			if (LineToLineCollision(S1.cornersX[i], S1.cornersY[i], S1.cornersX[iPlus], S1.cornersY[iPlus], 
									S2.cornersX[j], S2.cornersY[j], S2.cornersX[jPlus], S2.cornersY[jPlus], S2, true, S1.GetSquareProperties()))
			{
				// Collision normal is displayed onto the screen
				glColor3f(1.0f, 1.0f, 1.0f);
				glBegin(GL_LINES);
					glVertex2f (S1.GetCentreX(), S1.GetCentreY());
					glVertex2f (S2.GetCentreX(), S2.GetCentreY()); 
				glEnd();

				return true;
			}
		}
	}
	// If no intersectsions 
	// occured then false is returned.
	return false;
}

// Method used to calculate if the rect object has collided 
// with a square and returns true if it has.
bool SquareToRectCollision(Square S, Rect R)
{
	int iPlus, jPlus;

	for (int i = 0; i < 4; i++)
	{
		iPlus = i + 1;
		if (i == 3)
			iPlus = 0;

		for (int j = 0; j < 4; j++)
		{
			jPlus = j + 1;
			if (j == 3)
				jPlus = 0;

			// For each side of the rectangle, a line to line collision
			// is checked for with each side of the square and if there 
			// is an intersection, true is returned.
			if (LineToLineCollision(S.cornersX[i], S.cornersY[i], S.cornersX[iPlus], S.cornersY[iPlus], 
									R.cornersX[j], R.cornersY[j], R.cornersX[jPlus], R.cornersY[jPlus], R, 2, S.GetSquareProperties()))
			{
				// Collision normal is displayed onto the screen
				glColor3f(1.0f, 1.0f, 1.0f);
				glBegin(GL_LINES);
					glVertex2f (S.GetCentreX(), S.GetCentreY());
					glVertex2f (R.GetCentreX(), R.GetCentreY()); 
				glEnd();
				return true;
			}
		}
	}
	// If no intersectsions 
	// occured then false is returned.
	return false;
}

// Method used to calculate if the rect object has collided 
// with a rectangle and returns true if it has.
bool RectToRectCollision(Rect R1, Rect R2)
{
	int iPlus, jPlus;

	for (int i = 0; i < 4; i++)
	{
		iPlus = i + 1;
		if (i == 3)
			iPlus = 0;

		for (int j = 0; j < 4; j++)
		{
			jPlus = j + 1;
			if (j == 3)
				jPlus = 0;

			// For each side of each rectangle, a line to line collision
			// is checked for and if there is an intersection, true is returned.
			if (LineToLineCollision(R1.cornersX[i], R1.cornersY[i], R1.cornersX[iPlus], R1.cornersY[iPlus], 
									R2.cornersX[j], R2.cornersY[j], R2.cornersX[jPlus], R2.cornersY[jPlus], R2, 1, R1.GetRectProperties()))
			{
				// Collision normal is displayed onto the screen
				glColor3f(1.0f, 1.0f, 1.0f);
				glBegin(GL_LINES);
					glVertex2f (R1.GetCentreX(), R1.GetCentreY());
					glVertex2f (R2.GetCentreX(), R2.GetCentreY()); 
				glEnd();

				return true;
			}
		}
	}
	// If no intersectsions 
	// occured then false is returned.
	return false;
}