// Michael Mohan 40020843
// 2D Physics Engine
#pragma region HEADER DECLARATIONS
#include "StdAfx.h"
#include "Circle.h"
#pragma endregion

// Constructor to provide access to 
// the components of the object.
Circle::Circle(GLfloat cX, GLfloat cY, GLfloat r, Properties cP)
{
	centreX = cX;
	centreY = cY;
	radius = r;
	circleProperties.SetAttributes(cP.GetMass(), cP.GetVelocityX(), cP.GetVelocityY(), cP.GetShapeIndex());
}

// Destructor cleans up the data by freeing 
// the memory when the program is finished.
Circle::~Circle()
{
	centreX = NULL;
	centreY = NULL;
	radius = NULL;
	circleProperties.~Properties();
}

// Sequence of get and set functions
// used to provide access to the private
// members of the class object.
#pragma region GET/SET FUNCTIONS
GLfloat Circle::GetCentreX()
{
	return centreX;
}

GLfloat Circle::GetCentreY()
{
	return centreY;
}

GLfloat Circle::GetRadius()
{
	return radius;
}

Properties Circle::GetCircleProperties()
{
	return circleProperties;
}

void Circle::SetAttributes(GLfloat cX, GLfloat cY, GLfloat r, Properties cP)
{
	centreX = cX;
	centreY = cY;
	radius = r;
	circleProperties.SetAttributes(cP.GetMass(), cP.GetVelocityX(), cP.GetVelocityY(), cP.GetShapeIndex());
}
#pragma endregion

// Method used to draw a circle onto the 
// screen with a rotation and a user defined colour.
void Circle::Draw(GLfloat angle, GLfloat colourR, GLfloat colourG, GLfloat colourB)
{
	GLfloat tempX = centreX;
	GLfloat tempY = centreY;
	glPushMatrix();
	centreX = 0.0f;
	centreY = 0.0f;
	glTranslatef(tempX, tempY, 0.0f); 
	glRotatef(angle, 0.0f, 0.0f, 1.0f);
	glColor3f(colourR, colourG, colourB);

	// GL_TRIANGLE_FAN used to draw the circle.
	glBegin(GL_TRIANGLE_FAN);
	    glVertex2f(centreX, centreY);
		// Loop used to create a smooth edge.
	    for (GLfloat angle = 0.0f; angle <= 360.0f; angle += 6.0f)
			glVertex2f(centreX + radius*GLfloat(sin(angle)), centreY + radius*GLfloat(cos(angle)));
	glEnd();
	centreX = tempX;
	centreY = tempY;
	glPopMatrix();
}