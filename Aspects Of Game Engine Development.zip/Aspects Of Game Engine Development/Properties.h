// Michael Mohan 40020843
// 2D Physics Engine
#pragma region HEADER DECLARATIONS
#pragma once
#include "Headers.h"
#pragma endregion

// Header file initializes methods for the main class.
class Properties
{
	GLfloat mass, velocityX, velocityY; 
	int shapeIndex;
public:
	Properties(GLfloat m, GLfloat vX, GLfloat vY, int sI);
	Properties();
	~Properties();
	GLfloat GetMass();
	GLfloat GetVelocityX();
	GLfloat GetVelocityY();
	int GetShapeIndex();
	void SetAttributes(GLfloat m, GLfloat vX, GLfloat vY, int sI);
};

