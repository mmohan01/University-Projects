// Michael Mohan 40020843
// 2D Physics Engine
#pragma region HEADER DECLARATIONS
#include "StdAfx.h"
#include "Properties.h"
#pragma endregion

// Constructor to provide access to 
// the components of the object.
Properties::Properties(GLfloat m, GLfloat vX, GLfloat vY, int sI)
{
	mass = m;
	velocityX = vX;
	velocityY = vY;
	shapeIndex = sI;
}

// extra constructor to initialise the object when it is declared
Properties::Properties()
{
	mass = 0.0f;
	velocityX = 0.0f;
	velocityY = 0.0f;
	shapeIndex = 0;
}

// Destructor cleans up the data by freeing 
// the memory when the program is finished.
Properties::~Properties(void)
{
	mass = NULL;
	velocityX = NULL;
	velocityY = NULL;
	shapeIndex = NULL;
}

// Sequence of get and set functions
// used to provide access to the private
// members of the class object.
#pragma region GET/SET FUNCTIONS
GLfloat Properties::GetMass()
{
	return mass;
}

GLfloat Properties::GetVelocityX()
{
	return velocityX;
}

GLfloat Properties::GetVelocityY()
{
	return velocityY;
}

int Properties::GetShapeIndex()
{
	return shapeIndex;
}

void Properties::SetAttributes(GLfloat m, GLfloat vX, GLfloat vY, int sI)
{
	mass = m;
	velocityX = vX;
	velocityY = vY;
	shapeIndex = sI;
}
#pragma endregion
