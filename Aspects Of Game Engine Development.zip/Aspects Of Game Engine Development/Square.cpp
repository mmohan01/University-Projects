// Michael Mohan 40020843
// 2D Physics Engine
#pragma region HEADER DECLARATIONS
#include "StdAfx.h"
#include "Square.h"
#pragma endregion

// Constructor to provide access to 
// the components of the object.
Square::Square(GLfloat cX, GLfloat cY, GLfloat hL, GLfloat a, Properties sP)
{
	centreX = cX;
	centreY = cY;
	halfLength = hL;
	angle = a;
	squareProperties.SetAttributes(sP.GetMass(), sP.GetVelocityX(), sP.GetVelocityY(), sP.GetShapeIndex());

	// Defines the anglular rotation of the square in radians
	GLfloat radians = angle*(3.141592654/180);

	// Constants are used to calculate the 
	// corner points of the square object
	// at any angular rotation
	GLfloat xX = cos(radians)*halfLength;
	GLfloat xY = sin(radians)*halfLength;
	GLfloat yX = -sin(radians)*halfLength;
	GLfloat yY = cos(radians)*halfLength;

	// The corners of the square object are defined
	cornersX[0] = centreX - xX + yX;
	cornersY[0] = centreY - xY + yY;
	cornersX[1] = centreX + xX + yX;
	cornersY[1] = centreY + xY + yY;
	cornersX[2] = centreX + xX - yX;
	cornersY[2] = centreY + xY - yY;
	cornersX[3] = centreX - xX - yX;
	cornersY[3] = centreY - xY - yY;
}

// Destructor cleans up the data by freeing 
// the memory when the program is finished.
Square::~Square()
{
	centreX = NULL;
	centreY = NULL;
	halfLength = NULL;
	squareProperties.~Properties();
}

// Sequence of get and set functions
// used to provide access to the private
// members of the class object.
#pragma region GET/SET FUNCTIONS
GLfloat Square::GetCentreX()
{
	return centreX;
}

GLfloat Square::GetCentreY()
{
	return centreY;
}

GLfloat Square::GetHalfLength()
{
	return halfLength;
}

GLfloat Square::GetAngle()
{
	return angle;
}

Properties Square::GetSquareProperties()
{
	return squareProperties;
}

void Square::SetAttributes(GLfloat cX, GLfloat cY, GLfloat hL, GLfloat a, Properties sP)
{
	centreX = cX;
	centreY = cY;
	halfLength = hL;
	angle = a;
	squareProperties.SetAttributes(sP.GetMass(), sP.GetVelocityX(), sP.GetVelocityY(), sP.GetShapeIndex());
}
#pragma endregion

// Method used to draw a square onto the 
// screen with a user defined colour, and 
// stored rotation.
void Square::Draw(GLfloat colourR, GLfloat colourG, GLfloat colourB)
{
	GLfloat tempX = centreX;
	GLfloat tempY = centreY;
	glPushMatrix();
	centreX = 0.0f;
	centreY = 0.0f;

	// Translates the square to the origin
	// and then rotates it by the given angle.
	glTranslatef(tempX, tempY, 0.0f); 
	glRotatef(angle, 0.0f, 0.0f, 1.0f);

	glColor3f(colourR, colourG, colourB);

	// Vertices for the 4 points of the square
	// are calculated using the centre point 
	// and the width of the square.
	GLfloat x1, y1, x2, y2, x3, y3, x4, y4;
	x1 = centreX + halfLength;
	y1 = centreY + halfLength;
	x2 = centreX - halfLength;
	y2 = centreY + halfLength;
	x3 = centreX - halfLength;
	y3 = centreY - halfLength;
	x4 = centreX + halfLength;
	y4 = centreY - halfLength;

	// GL_QUADS used to draw the square.
	glBegin(GL_QUADS);
        glVertex2f(x1, y1);
        glVertex2f(x2, y2);
        glVertex2f(x3, y3);
        glVertex2f(x4, y4);
    glEnd();

	// Returns the square object to its
	// position in the world view.
	centreX = tempX;
	centreY = tempY;
	glPopMatrix();
}