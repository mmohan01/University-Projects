// Michael Mohan 40020843
// 2D Physics Engine
#pragma region HEADER DECLARATIONS
#include "StdAfx.h"
#include "Render Scene.h"
#pragma endregion

#pragma region GLOBAL VARIABLES
vector<Line> LineList;
vector<Circle> CircleList;
vector<Rect> RectList;
vector<Square> SquareList;
int shapeCounts[4];

int changeShape = 1;
int modify = 1;
GLfloat gravity = 0.01f;
bool tGravity = false;
bool instructions = true;
bool debug = false;
bool alternate = false;
bool instant = false;
bool velocity = false;
#pragma endregion

// Insert data to add a new shape into the program.
#pragma region SHAPE DATA
GLfloat lineAttributes[][4] = {-1.0f, 1.0f, 1.0f, 1.0f,
							   1.0f, 1.0f, 1.0f, -1.0f,
							   1.0f, -1.0f, -1.0f, -1.0f,
							   -1.0f, -1.0f, -1.0f, 1.0f,
							   -0.5f, 0.0f, 0.5f, 0.0f};
GLfloat circleAttributes[][4] = {-0.7, 0.5, 0.1, 0.0,
								 -0.7, -0.5, 0.1, 0.0};
GLfloat rectAttributes[][5] = {0.0, 0.5, 0.1, 0.2, 0.0,
							   0.0, -0.5, 0.1, 0.2, 0.0};
GLfloat squareAttributes[][4] = {0.6, 0.5, 0.1, 0.0,
								 0.6, -0.5, 0.1, 0.0};

// These are the same for each type of shape.
// They can be modified in the program.
GLfloat shapeProperties[][3] = {100.0f, 0.0f, 0.0f,
								1.0f, 0.02f, 0.02f,
								4.0f, 0.01f, 0.01f,
								4.0f, 0.01f, 0.01f};

#pragma endregion

// Draws The Scene.
void RenderScene(void)
{
	#pragma region INITIALISATION
	// Clear the Window.
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// Changes the colour of the 
	// scene if it is in debug mode.
	if (debug)
		glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
	else
		glClearColor(0.96, 0.93, 0.93, 0.0f);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluOrtho2D (-1.0, 1.0, -1.0, 1.0);               
	#pragma endregion

	#pragma region INITIALISE DATA
	// find the amount of shapes by calculating the size of the float arrays
	int lineAmount = sizeof(lineAttributes)/(sizeof(GLfloat)*4);
	int circleAmount = sizeof(circleAttributes)/(sizeof(GLfloat)*4);
	int rectAmount = sizeof(rectAttributes)/(sizeof(GLfloat)*5);
	int squareAmount = sizeof(squareAttributes)/(sizeof(GLfloat)*4);

	// Stores the amount of each shape in
	// the program for further use.
	shapeCounts[0] = lineAmount;
	shapeCounts[1] = circleAmount;
	shapeCounts[2] = rectAmount;
	shapeCounts[3] = squareAmount;
	#pragma endregion

	#pragma region CREATE SHAPES
	// Declares each shape.
	for (int i = 0; i < lineAmount; i++)
	{
		Properties lineProperties (shapeProperties[0][0], shapeProperties[0][1], shapeProperties[0][2], i);
		Line Linei (lineAttributes[i][0], lineAttributes[i][1], lineAttributes[i][2], lineAttributes[i][3], lineProperties);
		LineList.push_back(Linei);

		// Draws the lines onto the screen as they are made.
		if (debug)
			Linei.Draw(1.0f, 1.0f, 1.0f);
		else
			Linei.Draw(0.0f, 0.0f, 0.0f);
	}

	for (int i = 0; i < circleAmount; i++)
	{
		Properties circleProperties (shapeProperties[1][0], shapeProperties[1][1], shapeProperties[1][2], i);
		Circle Circlei (circleAttributes[i][0], circleAttributes[i][1], circleAttributes[i][2], circleProperties);
		CircleList.push_back(Circlei);
	}

	for (int i = 0; i < rectAmount; i++)
	{
		Properties rectProperties (shapeProperties[2][0], shapeProperties[2][1], shapeProperties[2][2], i);
		Rect Recti (rectAttributes[i][0], rectAttributes[i][1], rectAttributes[i][2], rectAttributes[i][3], rectAttributes[i][4], rectProperties);
		RectList.push_back(Recti);
	}

	for (int i = 0; i < squareAmount; i++)
	{
		Properties squareProperties (shapeProperties[3][0], shapeProperties[3][1], shapeProperties[3][2], i);
		Square Squarei (squareAttributes[i][0], squareAttributes[i][1], squareAttributes[i][2], squareAttributes[i][3], squareProperties);
		SquareList.push_back(Squarei);
	}
	#pragma endregion

	#pragma region COLLISION DETECTION
	// Counters are needed for cases where a shape checks
	// for collisions with a shape of the same type. The
	// counters stop the same check happening multiple times.
	int circleCounter = 0;
	int rectCounter = 0;
	int squareCounter = 0;

	// Draws the circles onto the screen and works out
	// whether they collide with any other shape,
	// including each other.
	for (int i = 0; i < circleAmount; i++)
	{
		for (int j = 0; j < lineAmount; j++)
		{
			if (LineToCircleCollision(LineList[j], CircleList[i]))
				CollisionResolver(1);
		}

		for (int j = 0; j < circleAmount; j++)
		{
			j += circleCounter;

			// If the shape is not checking 
			// for collision with itself.
			if (i != j)
				if (CircleToCircleCollision(CircleList[i], CircleList[j]))
					CollisionResolver(2);
		}
		circleCounter++;

		for (int j = 0; j < squareAmount; j++)
		{
			if (CircleToSquareCollision(CircleList[i], SquareList[j]))
				CollisionResolver(3);
		}

		for (int j = 0; j < rectAmount; j++)
		{
			if(CircleToRectCollision(CircleList[i], RectList[j]))
				CollisionResolver(4);
		}

		CircleList[i].Draw(circleAttributes[i][3], 1.0f, 0.0f, 0.0f);
	}

	// Draws the rects onto the screen and works out
	// whether they collide with any other shape,
	// including each other.
	for (int i = 0; i < rectAmount; i++)
	{
		for (int j = 0; j < lineAmount; j++)
		{
			if (LineToRectCollision(LineList[j], RectList[i]))
				CollisionResolver(8);
		}

		for (int j = 0; j < squareAmount; j++)
		{
			if (SquareToRectCollision(SquareList[j], RectList[i]))
				CollisionResolver(7);
		}

		for (int j = 0; j < rectAmount; j++)
		{
			j += rectCounter;

			// If the shape is not checking 
			// for collision with itself.
			if (i != j)
				if((RectToRectCollision(RectList[0], RectList[j])))
					CollisionResolver(9);
		}
		rectCounter++;

		RectList[i].Draw(1.0f, 0.84f, 0.0f);
	}

	// Draws the squares onto the screen and works out
	// whether they collide with any other shape,
	// including each other.
	for (int i = 0; i < squareAmount; i++)
	{
		for (int j = 0; j < lineAmount; j++)
		{
			if (LineToSquareCollision(LineList[j], SquareList[i]))
				CollisionResolver(5);
		}
		
		for (int j = 0; j < squareAmount; j++)
		{
			j += squareCounter;

			// If the shape is not checking 
			// for collision with itself.
			if (i != j)
				if (SquareToSquareCollision(SquareList[0], SquareList[j]))
					CollisionResolver(6);
		}
		squareCounter++;

		SquareList[i].Draw(0.36f, 0.2f, 0.09f);
	}
	#pragma endregion

	// Draws instructions onto the screen.
	#pragma region TEXT
	if (debug == false)
	{
		if (instructions)
		{
		
			Text("Use the W, A, S & D buttons to move the shapes around the screen.",
				-0.9f, 0.9f, 0.0f, 0.0f, 0.0f);
			Text("Press T to tranform the angle of the shapes or R to resolve the collisions.",
				-0.9f, 0.8f, 0.0f, 0.0f, 0.0f);
			Text("Press the spacebar to toggle between the shapes.",
				-0.9f, 0.7f, 0.0f, 0.0f, 0.0f);
			Text("Press I for more instructions.",
				-0.9f, 0.6f, 0.0f, 0.0f, 0.0f);
		}
		else
		{
			Text("Press V to toggle velocity.",
				 -0.9f, 0.9f, 0.0f, 0.0f, 0.0f);
			Text("Press Left to toggle collision modes and Right to toggle resolution modes.",
				 -0.9f, 0.8f, 0.0f, 0.0f, 0.0f);
			Text("Press the Up and Down arrow buttons to increase/decrease the properties.",
				 -0.9f, 0.7f, 0.0f, 0.0f, 0.0f);
			Text("Press the Tab button to switch between properties or Q to enter debug mode.",
				 -0.9f, 0.6f, 0.0f, 0.0f, 0.0f);
		}
	}
	else if (instructions)
		Text("Press I for more information.", -0.2f, -0.9, 1.0f, 1.0f, 1.0f);

	if (alternate)
		Text("ALT", 0.8f, -0.7f, 0.0f, 0.0f, 1.0f);
	
	if (instant)
		Text("INSTANT", 0.8f, -0.8f, 0.0f, 0.0f, 1.0f);

	if (velocity)
		Text("VELOCITY", 0.8f, -0.9f, 0.0f, 0.0f, 1.0f);

	#pragma region MODIFY
	VariableText("Gravity: ", gravity, -0.9f, -0.6f, 0.5f, 0.5f, 0.5f);

	Properties circleProperties = CircleList[0].GetCircleProperties();
	Properties rectProperties = RectList[0].GetRectProperties();
	Properties squareProperties = SquareList[0].GetSquareProperties();

	switch (changeShape) 
	{
	case 1:	
		VariableText("Circle Mass: ", circleProperties.GetMass(), -0.9f, -0.7f, 0.5f, 0.5f, 0.5f);
		VariableText("Circle Velocity X: ", circleProperties.GetVelocityX(), -0.9f, -0.8f, 0.5f, 0.5f, 0.5f);
		VariableText("Circle Velocity Y: ", circleProperties.GetVelocityY(), -0.9f, -0.9f, 0.5f, 0.5f, 0.5f);
		break;
	case 2:	
		VariableText("Rectangle Mass: ", rectProperties.GetMass(), -0.9f, -0.7f, 0.5f, 0.5f, 0.5f);
		VariableText("Rectangle Velocity X: ", rectProperties.GetVelocityX(), -0.9f, -0.8f, 0.5f, 0.5f, 0.5f);
		VariableText("Rectangle Velocity Y: ", rectProperties.GetVelocityY(), -0.9f, -0.9f, 0.5f, 0.5f, 0.5f);
		break;
	case 3:
		VariableText("Square Mass: ", squareProperties.GetMass(), -0.9f, -0.7f, 0.5f, 0.5f, 0.5f);
		VariableText("Square Velocity X: ", squareProperties.GetVelocityX(), -0.9f, -0.8f, 0.5f, 0.5f, 0.5f);
		VariableText("Square Velocity Y: ", squareProperties.GetVelocityY(), -0.9f, -0.9f, 0.5f, 0.5f, 0.5f);
		break;
	}
	#pragma endregion

	#pragma endregion

	// Creates gravity and limits the objects
	// within the bounds of the screen
	if (tGravity)
		Gravity(gravity);

	// Creates velocities in the shapes
	// and turns it on if it has been toggled.
	if (velocity)
		Velocity();

	#pragma region CLEANUP MEMORY
	glFlush();
	LineList.clear();
	CircleList.clear();
	SquareList.clear();
	RectList.clear();
	#pragma endregion
}