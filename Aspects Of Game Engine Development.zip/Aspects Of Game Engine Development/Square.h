// Michael Mohan 40020843
// 2D Physics Engine
#pragma region HEADER DECLARATIONS
#pragma once
#include "Headers.h"
#include "Properties.h"
#pragma endregion

// Header file initializes methods for the main class.
class Square
{
	GLfloat centreX, centreY, halfLength, angle;
	Properties squareProperties;
public:
	GLfloat cornersX[4], cornersY[4];

	Square(GLfloat cX, GLfloat cY, GLfloat hL, GLfloat a, Properties sP);
	~Square();
	GLfloat GetCentreX();
	GLfloat GetCentreY();
	GLfloat GetHalfLength();
	GLfloat GetAngle();
	Properties GetSquareProperties();
	void SetAttributes(GLfloat cX, GLfloat cY, GLfloat hL, GLfloat a, Properties sP);

	void Draw(GLfloat cR, GLfloat cG, GLfloat cB);

};