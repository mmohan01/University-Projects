/* ModelCompiler.java: The Model Compiler */  

public class ModelCompiler {
    
    public static void main( java.lang.String[] _args ) {
        
        FullAnalyser analyser = new FullAnalyser( );
        
        analyser.programme();
        
        SourceHandler.finaliseIO( );
        CodeHandler.listCode();
    }
}



