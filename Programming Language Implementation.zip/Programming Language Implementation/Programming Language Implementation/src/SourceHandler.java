/* SourceHandler.java */

import java.util.Date;
import java.text.DateFormat;

public class SourceHandler
  {

  /*friendly*/ static char currentCharacter;

  /* Termination Status */
  private static final byte Normal = 0;
  private static final byte InputExhausted = 1;

  private static final byte MaxCharsPerLine = 101;

  public static class TextPosition
    {
    public short lineNumber;
    public byte charNumber;

    public TextPosition copy ( )
      {
      TextPosition theCopy = new TextPosition ( );
      theCopy.lineNumber = this.lineNumber;
      theCopy.charNumber = this.charNumber;
      return theCopy;
      }
    }

  public static TextPosition positionNow;


  private static char[ ] line = new char[MaxCharsPerLine];
  private static byte firstInLine, lastInLine;


  private static final byte MaxErrorsPerLine = 9;

  private static class ErrorRecord
    {
    public TextPosition errorPosition;
    public short errorCode;
    }

  private static ErrorRecord[ ] errorList = new ErrorRecord[MaxErrorsPerLine];

  private static byte errorsInThisLine;
  private static boolean errorOverflow;
  private static short totalNumberOfErrors;

  private static Host.File sourceFile = new Host.File();
  private static Host.File listingFile = new Host.File();

  private static void listErrors ( )
    {
    byte k;
    short j;

    totalNumberOfErrors += (short)(errorsInThisLine);
    for (k = 1;  k <= errorsInThisLine ; k += 1)
      {
      listingFile.writeString( "*****   " );
      if (errorList[k-1].errorPosition.lineNumber != positionNow.lineNumber)
        {
        listingFile.writeString( "ERROR " );
        listingFile.writeCardinal( errorList[k-1].errorCode, (byte)1 );
        listingFile.writeString( " AT CHARACTER " );
        listingFile.writeCardinal( errorList[k-1].errorPosition.charNumber, (byte)1 );
        listingFile.writeString( " OF LINE " );
        listingFile.writeCardinal( errorList[k-1].errorPosition.lineNumber, (byte)1 );
        }
      else
        {
        for (j = 0; ( j <= errorList[k-1].errorPosition.charNumber - 1); j += 1)
          listingFile.writeChar(' ');
        listingFile.writeString( "^ERROR " );
        listingFile.writeCardinal( errorList[k-1].errorCode, (byte)1 );
        }
      listingFile.writeLine( );
      }
    if (errorOverflow)
      {
      listingFile.writeString( "*****   FURTHER ERRORS ON THIS LINE SUPPRESSED" );
      listingFile.writeLine( );
      }
    listingFile.writeLine( );
    errorsInThisLine = 0;
    errorOverflow = false;
    }


  private static void listThisLine ( )
    {
    byte i;
    listingFile.writeCardinal( positionNow.lineNumber, (byte) 5 );
    listingFile.writeString( "   " );
    for (i = 0;  i <= lastInLine; i += 1)
      listingFile.writeChar( line[i] );
    listingFile.writeLine( );
    if ( errorsInThisLine > 0 )
      listErrors();
    }


  private static void finalise (byte reason)
    {
    if ( reason == Normal )
      listThisLine();
    listingFile.writeLine( );
    listingFile.writeLine( );
    if ( reason == Normal )
      listingFile.writeString( "COMPILATION COMPLETED: " );
    else
      {
      listingFile.writeString( "COMPILATION ABORTED - PREMATURE END OF INPUT FILE" );
      listingFile.writeLine( );
      }
    if ( totalNumberOfErrors == 0)
      listingFile.writeString( "NO" );
    else
      listingFile.writeCardinal( totalNumberOfErrors, (byte)1 );
    listingFile.writeString(  " ERROR(S) REPORTED" );
    listingFile.writeLine( );
    listingFile.closeFile( );
    listingFile.closeFile( );
    }


  private static void readNextLine ( )
    {

    byte i;

    line[0] = sourceFile.readChar( );
    if (listingFile.endOfInput( ) )
      {
      finalise( InputExhausted );
      System.exit (0);
      }
    i = 0;
    while ( line[i] == ' ' )
      {
      i += 1;
      line[i] = sourceFile.readChar( );
      }
    firstInLine = i;
    while ( line[i] != Host.EOL )
      {
      i += 1;
      line[i] = sourceFile.readChar( );
      }
    line[i] = ' '; /* Replacing end of line by blank */
    lastInLine = i;
    if ( firstInLine != lastInLine )
      {
      do
        i -= 1;
      while ( line[i] == ' ' );
      lastInLine = (byte) (i + 1);
      }
    }


  public static void getNextCharacter ( )
    {
    if ( positionNow.charNumber == lastInLine )
      {
      listThisLine();
      readNextLine();
      positionNow.lineNumber += 1;
      positionNow.charNumber = firstInLine;
      }
    else
      positionNow.charNumber += 1;

    currentCharacter = line[positionNow.charNumber];
    }


  public static void error (short code, TextPosition position)
    {
    if ( errorsInThisLine == MaxErrorsPerLine )
      errorOverflow = true;
    else
      {
      errorsInThisLine += 1;
      errorList[ errorsInThisLine - 1 ].errorCode = code;
      errorList[ errorsInThisLine - 1 ].errorPosition = position.copy ( );
      }
    }


  public static void finaliseIO()
    {
    finalise( Normal );
    }


  /* initialisation */
  static
    {
    boolean ok;

    byte i;
    for (i = 0; i < MaxErrorsPerLine; i++)
      errorList[i] = new  ErrorRecord ( );

    ok = sourceFile.openFile( "Enter name of source text file: ", Host.File.Input );
    if (ok)
      {
      ok = listingFile.openFile( "Enter name of listing file: ", Host.File.Output );
      if (ok)
        {
        listingFile.writeString( "LISTING PRODUCED BY Model COMPILER (Java Version) " );
        listingFile.writeString( DateFormat.getDateTimeInstance().format(new Date() ) );
        listingFile.writeLine();
      	listingFile.writeString( "Student Name: Michael Mohan");
      	listingFile.writeLine();
      	listingFile.writeString( "Student Number: 40020843");
        listingFile.writeLine( );
        listingFile.writeLine( );
        readNextLine();

        positionNow = new TextPosition();
        positionNow.lineNumber = 0;
        positionNow.charNumber = firstInLine;

        currentCharacter = line[ (positionNow.charNumber) ];
        totalNumberOfErrors = 0;
        errorsInThisLine = 0;
        errorOverflow = false;
        }
      }

    if (!ok)
       System.exit (1);
    }

  }

