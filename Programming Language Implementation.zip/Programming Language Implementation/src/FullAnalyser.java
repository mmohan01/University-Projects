/* FullAnalyser.java: Full analyser */

/* Copy Table2.java to Table.java before compiling this. */


public class FullAnalyser implements SymbolType, TypeClass, IdentifierClass {

    /* public static void programme () */

    public FullAnalyser() {
    }

    private static LexicalAnalyser lexicalAnalyser = new LexicalAnalyser();

    /* The Analyser generates syntax error codes with the following  meanings:     */
    /*                                                                             */
    /*  10 ... Symbol expected was Identifier                                      */
    /*  11 ... Symbol expected was Integer Number                                  */
    /*  12 ... Symbol expected was Character constant                              */
    /*  13 ... .......                                                             */
    /*                                                                             */
    /* i.e., one value for each of the values of SymbolType.                       */
    /* The final value, OtherSymbol+10, is used to mean                            */
    /*                                                                             */
    /*  NN ... Unexpected symbol                                                   */
    /*                                                                             */
    /*                                                                             */
    /* Semantic errors are reported with the following error codes:                */
    /*                                                                             */
    /*  61 ... indexed variable must be an array variable                          */
    /*  62 ... index expression must be of type INTEGER                            */
    /*  63 ... Operand must be of type BOOLEAN                                     */
    /*  64 ... Operand must be of type INTEGER                                     */
    /*  65 ... Operands must both be INTEGER, CHAR or BOOLEAN                      */
    /*  66 ... Expression must be of same type as Variable                         */
    /*  67 ... Input variable must be of type INTEGER or CHAR                      */
    /*  68 ... Expression must be of type INTEGER, CHAR or BOOLEAN                 */
    /*  69 ... Expression must be of type BOOLEAN                                  */
    /*  70 ... Identifiers at beginning and end of block must match                */
    /*  71 ... For loop control variable must be of type INTEGER, CHAR or BOOLEAN  */
    /*  72 ... An exit-statement must occur within a loop-statement                */
    /*  73 ... Type of case label must be same as the selector type                */
    /*  74 ... Case label must appear at most once in case statement               */
    /*  75 ... Case label must be of type INTEGER, CHAR or BOOLEAN                 */



    /* SYNTAX ANALYSIS                                                             */
    /*                                                                             */
    /* Syntax analysis of Model programs is implemented as a set of recursive      */
    /* descent methods.  These methods are based on the syntax rules given in      */
    /* the document "Definition of Model". In their execution, the methods invoke  */
    /* one another resursively in a manner which reflects the 'natural' nesting    */
    /* of the corresponding non-terminal symbols in the syntax rules.              */
    /* The order, names, and 'natural' nesting of the methods are as follows:      */
    /*                                                                             */
    /*     programme                                                               */
    /*        block                                                                */
    /*           declarationPart                                                   */
    /*              variableDeclarationPart                                        */
    /*                 variableDeclaration                                         */
    /*                    type                                                     */
    /*                       simpleType                                            */
    /*                       indexType                                             */
    /*              procedureDeclaration                                           */
    /*           statementPart                                                     */
    /*              statementSequence                                              */
    /*                 statement                                                   */
    /*                    variable                                                 */
    /*                    expression                                               */
    /*                       simpleExpression                                      */
    /*                          term                                               */
    /*                             factor                                          */
    /*                    assignment                                               */
    /*                    readStatement                                            */
    /*                       inputVariable                                         */
    /*                    writeStatement                                           */
    /*                       outputValue                                           */
    /*                    ifStatement                                              */
    /*                    caseStatement                                            */
    /*                    loopStatement                                            */
    /*                    exitStatement                                            */
    /*                    forStatement                                             */
    /*                    doStatement											   */
    /*                    whileStatement                                           */
    /*                                                                             */
    /* The syntax analysers are written on the assumption that the next syntactic  */
    /* goal can always be selected by inspection of (at most) the next incoming    */
    /* symbol (i.e., that the underlying grammar is LL(1)).  This is not so at the */
    /* following points in the syntax rules actually used:                         */
    /*                                                                             */
    /*  1. A statement beginning with an Identifier may be either an assignment or */
    /*     a procedure-call;                                                       */
    /*  2. A factor beginning with an Identifier may be either a variable or a     */
    /*     constant.                                                               */
    /*                                                                             */
    /* In Case 1 to resolve the choice on a purely syntactic basis would require a */
    /* distortion of the syntax rules; choice 2 cannot be syntactically resolved   */
    /* in some cases.  However, if parallel semantic analysis is assumed (as in    */
    /* the case of this compiler) these choices can be resolved without syntax     */
    /* distortion, by inspection of the current semantic attributes of the         */
    /* Identifier involved.  For this reason syntactic resolution of these choices */
    /* is not used.                                                                */


    private static void syntaxError(int expectedSymbol) {
        SourceHandler.error((short)(expectedSymbol + 10), lexicalAnalyser.symbolDescription.position);
        Generator.noFurtherCode();
    }


    static void accept(int symbolExpected) {
        if (lexicalAnalyser.symbolDescription.symbol == symbolExpected)
            lexicalAnalyser.getNextSymbol();
        else
            syntaxError(symbolExpected);
    }



    /* The class SymbolSet provides an abstract data type       */
    /* denoting sets of symbols of type SymbolType.             */

    private static class SymbolSet {

        public boolean[] member;

        public SymbolSet() {
            member = new boolean[OtherSymbol+1];
        }

        public void copy(SymbolSet original) {
            java.lang.System.arraycopy(original.member, 0, this.member, 0, OtherSymbol+1);
        }

        public void clear() {
            int b;
            for (b = 0; (b <= OtherSymbol); b += 1)
                this.member[b] = false;
        }

        public void include(int i) {
            this.member[i] = true;
        }

        public void remove(int i) {
            this.member[i] = false;
        }

        public boolean contains(int i) {
            return this.member[i];
        }

        public void union(SymbolSet s1, SymbolSet s2) {
            int b;
            for (b = 0; (b <= OtherSymbol); b += 1) {
                this.member[b] = (s1.member[b] | s2.member[b]);
            }
        }

    } /* SymbolSet */



    /* SYNTACTIC ERROR RECOVERY                                                    */
    /*                                                                             */
    /* Recovery in the syntax analysis process following the discovery of a syntax */
    /* error is incorporated into the syntax methods on the following basis:       */
    /* 1. Each method when called is passed an actual parameter which is a set     */
    /*    of symbols which are possible followers of the string which it should    */
    /*    scan. These followers normally include:                                  */
    /*    (a) all symbols which may legitimately follow the string to be scanned;  */
    /*    (b) such additional symbols as a superior (calling) method may wish      */
    /*        to handle in the event of error recovery.                            */
    /*                                                                             */
    /* 2. When entered the method may ensure that the current symbol is an         */
    /*    acceptable starter for the string to be scanned and, if not, scan        */
    /*    forward (skip) until such a symbol is found (subject to 4, below).  This */
    /*    check is performed by an initial call of the method checkForStarter      */
    /*    within each syntax method.                                               */
    /*                                                                             */
    /* 3. When calling a subsidiary syntax method the method passes on as          */
    /*    followers its own followers plus those symbols, if any, which it may     */
    /*    determine as followers for the substring to be scanned.                  */
    /*                                                                             */
    /* 4. To recover from a syntax error the method may scan over any symbol       */
    /*    provided it is not contained in the followers passed to it.              */
    /*                                                                             */
    /* 5. On exit the syntax method ensures that the current symbol is             */
    /*    contained in the followers passed to it, flagging a terminal error and   */
    /*    skipping if this is not initially the case.  This action is performed by */
    /*    a final call of the method findFollower within each syntax method.       */



    private static SymbolSet declarationStarters  = new SymbolSet();
    private static SymbolSet statementStarters    = new SymbolSet();
    private static SymbolSet factorStarters       = new SymbolSet();
    private static SymbolSet relationalOps        = new SymbolSet();
    private static SymbolSet additionOps          = new SymbolSet();
    private static SymbolSet multiplicationOps    = new SymbolSet();
    private static SymbolSet signs                = new SymbolSet();

    private static void initialiseSymbolSets() {
        /* declarationStarters = {Var, Procedure}                               */
        declarationStarters.clear();
        declarationStarters.include(Var);
        declarationStarters.include(Procedure);

        /* relationalOps = {Equals, NotEquals, LessThan, LessThanOrEqual,       */
        /*                  GreaterThanOrEqual, GreaterThan}                    */
        relationalOps.clear();
        relationalOps.include(Equals);
        relationalOps.include(NotEquals);
        relationalOps.include(LessThan);
        relationalOps.include(LessThanOrEqual);
        relationalOps.include(GreaterThan);
        relationalOps.include(GreaterThanOrEqual);

        /* additionOps = {Plus, Minus, Or}                                      */
        additionOps.clear();
        additionOps.include(Plus);
        additionOps.include(Minus);
        additionOps.include(Or);

        /* multiplicationOps := {Times, Div, And}                                */
        multiplicationOps.clear();
        multiplicationOps.include(Times);
        multiplicationOps.include(Div);
        multiplicationOps.include(And);

        /* signs             = {Plus, Minus}                                    */
        signs.clear();
        signs.include(Plus);
        signs.include(Minus);

        /* statementStarters = {Identifier, Read, Write, If, Case, Loop, Exit   */
        /*                      For, Do, While}                                            */
        statementStarters.clear();
        statementStarters.include(Identifier);
        statementStarters.include(Read);
        statementStarters.include(Write);
        statementStarters.include(If);
        statementStarters.include(Case);
        statementStarters.include(Loop);
        statementStarters.include(Exit);
        statementStarters.include(For);
    	statementStarters.include(Do);
    	statementStarters.include(While);

        /* factorStarters = {Identifier, IntegerNumber, CharConstant, Not,      */
        /*                   LeftParenthesis}                                   */
        factorStarters.clear();
        factorStarters.include(Identifier);
        factorStarters.include(IntegerNumber);
        factorStarters.include(CharConstant);
        factorStarters.include(Not);
        factorStarters.include(LeftParenthesis);

    } /* initialiseSymbolSets */


    private static void skipTo(SymbolSet relevantSymbols) {
        while (!relevantSymbols.contains(lexicalAnalyser.symbolDescription.symbol))
            lexicalAnalyser.getNextSymbol();
    }


    private static boolean checkForStarter(SymbolSet starters, SymbolSet followers) {
        boolean found;
        SymbolSet localSet = new SymbolSet();

        if (!starters.contains(lexicalAnalyser.symbolDescription.symbol)) {
            syntaxError(OtherSymbol);
            localSet.union(starters, followers);
            skipTo(localSet);
        }
        found = starters.contains(lexicalAnalyser.symbolDescription.symbol);
        return found;
    } /* checkForStarter */


    private static void findFollower(SymbolSet followers) {
        if (!followers.contains(lexicalAnalyser.symbolDescription.symbol)) {
            syntaxError(OtherSymbol);
            skipTo(followers);
        }
    } /* findFollower */


    private static Table.TypeEntry integerType, booleanType, charType;

    private static void semanticError(short Code) {
        SourceHandler.error(Code, lexicalAnalyser.symbolDescription.position);
        Generator.noFurtherCode();
    }


    private static void checkIsSameAs(Host.Word blockIdentifier) {
        if (Host.Word.comparisonOf(blockIdentifier, Host.blankWord) != Host.Word.WordsEqual) {
            if (Host.Word.comparisonOf(lexicalAnalyser.symbolDescription.spelling, blockIdentifier)
            != Host.Word.WordsEqual)
                semanticError((short)70);
        }
    }

    /* OBJECT CODE GENERATION                                                      */
    /*                                                                             */
    /* Object Code generation is implemented by interfacing the Analyser module to */
    /* an object-Code-dependent Generator module.  The interface itself however is */
    /* independent of the object Code to be produced.  The interface specification */
    /* is given in the Generator module.                                           */

    private static Table.IdentifierEntry nullIdentifier;

    public static void programme() {
        Host.Word programName;
        Host.Word idSpelling;
        SymbolSet localSet = new SymbolSet();
        Table.IdentifierEntry entry;

        Generator.openFrame();
        Table.openScope();

        integerType = Table.newType(Scalars);
        integerType.representation = Generator.integerRepresentation;

        charType = Table.newType(Scalars);
        charType.representation = Generator.charRepresentation;

        booleanType = Table.newType(Scalars);
        booleanType.representation = Generator.booleanRepresentation;

        idSpelling = Host.getSpelling(Host.StandardIdentifiers.INTEGER);
        entry = Table.newId(idSpelling, Types);
        entry.idType = integerType;

        idSpelling = Host.getSpelling(Host.StandardIdentifiers.CHAR);
        entry = Table.newId(idSpelling, Types);
        entry.idType = charType;

        idSpelling = Host.getSpelling(Host.StandardIdentifiers.BOOLEAN);
        entry = Table.newId(idSpelling, Types);
        entry.idType = booleanType;

        idSpelling = Host.getSpelling(Host.StandardIdentifiers.FALSE);
        entry = Table.newId(idSpelling, Constants);
        entry.idType = booleanType;
        ((Table.ConstantsIdentifierEntry)entry).constantValue = 0;

        idSpelling = Host.getSpelling(Host.StandardIdentifiers.TRUE);
        entry = Table.newId(idSpelling, Constants);
        entry.idType = booleanType;
        ((Table.ConstantsIdentifierEntry)entry).constantValue = 1;

        initialiseSymbolSets();

        accept(Module);
        if (lexicalAnalyser.symbolDescription.symbol == lexicalAnalyser.Identifier)
            programName = lexicalAnalyser.symbolDescription.spelling;
        else
            programName = Host.blankWord;
        accept(Identifier);
        accept(Semicolon);
        localSet.clear();
        localSet.include(Identifier);
        localSet.include(Period);
        nullIdentifier = null;
        block(localSet, nullIdentifier);
        if (lexicalAnalyser.symbolDescription.symbol == Identifier)
            checkIsSameAs(programName);
        accept(Identifier);
        Table.closeScope();
        Generator.closeFrame();
    } /* programme */



    private static void block(SymbolSet followers, Table.IdentifierEntry blockID) {
        SymbolSet starters = new SymbolSet();
        SymbolSet localSet = new SymbolSet();
        boolean ok;

        starters.clear();
        starters.include(Var);
        starters.include(Procedure);
        starters.include(Begin);
        ok = checkForStarter(starters, followers);
        if (ok) {
            Generator.openFrame();
            Table.openScope();
            localSet.copy(followers);
            localSet.include(Procedure);
            localSet.include(Var);
            localSet.include(Begin);
            declarationPart(localSet);
            statementPart(followers, blockID);
            Table.closeScope();
            Generator.closeFrame();
            findFollower(followers);
        }
    } /* block */


    private static void declarationPart(SymbolSet followers) {

        SymbolSet starters = new SymbolSet();
        SymbolSet VarDeclarationFollowers = new SymbolSet();
        SymbolSet ProcDeclarationFollowers = new SymbolSet();
        boolean ok;

        starters.union(declarationStarters, followers);
        ok = checkForStarter(starters, followers);
        if (ok) {
            VarDeclarationFollowers.copy(starters);
            VarDeclarationFollowers.include(Begin);
            ProcDeclarationFollowers.copy(VarDeclarationFollowers);
            ProcDeclarationFollowers.include(Semicolon);
            while (declarationStarters.contains(lexicalAnalyser.symbolDescription.symbol)) {
                switch (lexicalAnalyser.symbolDescription.symbol) {
                    case Var:
                    {
                        variableDeclarationPart(VarDeclarationFollowers);
                        break;
                    }
                    case Procedure:
                    {
                        procedureDeclaration(ProcDeclarationFollowers);
                        accept(Semicolon);
                        break;
                    }
                }
            }
            findFollower(followers);
        }
    } /* declarationPart */



    private static void variableDeclarationPart(SymbolSet followers) {
        SymbolSet localSet = new SymbolSet();

        accept(Var);
        localSet.copy(followers);
        localSet.include(Semicolon);
        while (lexicalAnalyser.symbolDescription.symbol == Identifier) {
            variableDeclaration(localSet);
            accept(Semicolon);
        }
        findFollower(followers);
    } /* variableDeclarationPart */



    private static void variableDeclaration(SymbolSet followers) {
        SymbolSet starters = new SymbolSet();
        boolean ok;
        variableListRecord variableList;
        Table.TypeEntry variableType;

        starters.clear();
        starters.include(Identifier);
        starters.include(Comma);
        starters.include(Colon);
        ok = checkForStarter(starters, followers);
        if (ok) {
            variableList = new variableListRecord();
            variableList.head = null;
            newVariable(variableList);
            accept(Identifier);
            while (lexicalAnalyser.symbolDescription.symbol == Comma) {
                accept(Comma);
                newVariable(variableList);
                accept(Identifier);
            }
            accept(Colon);
            variableType = type(followers);
            addAttributes(variableType, variableList);
            findFollower(followers);
        }
    } /* variableDeclaration */



    private static class ListRecord {
        public Table.VariablesIdentifierEntry id;
        public ListRecord nextOnList;
    }

    private static class variableListRecord {
        public ListRecord head;
        public ListRecord tail;
    }

    private static void newVariable(variableListRecord variableList) {
        Table.VariablesIdentifierEntry variableEntry;
        ListRecord listEntry;

        if (lexicalAnalyser.symbolDescription.symbol == lexicalAnalyser.Identifier) {
            variableEntry = (Table.VariablesIdentifierEntry)Table.newId(lexicalAnalyser.symbolDescription.spelling, Variables);
            listEntry = new ListRecord();

            listEntry.id = variableEntry;
            listEntry.nextOnList = null;
            if (variableList.head == null)
                variableList.head = listEntry;
            else
                variableList.tail.nextOnList = listEntry;
            variableList.tail = listEntry;
        }
    } /* newVariable */


    private static void addAttributes(Table.TypeEntry variableType, variableListRecord variableList) {
        ListRecord listEntry;
        ListRecord oldEntry;

        listEntry = variableList.head;
        while (listEntry != null) {
            listEntry.id.idType = variableType;
            if (! variableType.isUndefined() )
                listEntry.id.variableAddress = Generator.addressFor(variableType.representation);
            oldEntry = listEntry;
            listEntry = listEntry.nextOnList;
            oldEntry = null;
        }
    } /* addAttributes */


    private static Table.TypeEntry type(SymbolSet followers) {

        Table.TypeEntry typeFound;
        Table.TypeEntry elementType;
        SymbolSet starters = new SymbolSet();
        SymbolSet localSet = new SymbolSet();
        boolean ok;

        starters.clear();
        starters.include(Identifier);
        starters.include(Array);
        ok = checkForStarter(starters, followers);
        if (ok) {
            if (lexicalAnalyser.symbolDescription.symbol == lexicalAnalyser.Identifier)
                typeFound = simpleType(followers);
            else {
                typeFound = Table.newType(Arrays);
                accept(Array);
                localSet.copy(followers);
                localSet.include(Of);
                indexType(localSet, typeFound);
                accept(Of);
                elementType = simpleType(followers);
                ((Table.ArrayTypeEntry)typeFound).elementType = elementType;
                if (! elementType.isUndefined() )
                    ((Table.ArrayTypeEntry)typeFound).representation = Generator.arrayRepresentation
                            ( ((Table.ArrayTypeEntry)typeFound).indexMin,
                            ((Table.ArrayTypeEntry)typeFound).indexMax,
                            elementType.representation);
            }
            findFollower(followers);
        } else
            typeFound = Table.TypeEntry.getUndefined();
        return typeFound;
    } /* type */


    private static Table.TypeEntry simpleType(SymbolSet followers) {

        Table.TypeEntry typeNamed;
        SymbolSet starters = new SymbolSet();
        boolean ok;
        Table.IdentifierEntry typeIdentifier;

        starters.clear();
        starters.include(Identifier);
        ok = checkForStarter(starters, followers);
        if (ok) {
            typeIdentifier = Table.searchId(lexicalAnalyser.symbolDescription.spelling,
                    new Table.IdClassSet().include(Types));
            typeNamed = typeIdentifier.idType;
            accept(Identifier);
            findFollower(followers);
        } else
            typeNamed = Table.TypeEntry.getUndefined();
        return typeNamed;
    } /* simpleType */


    private static void indexType(SymbolSet followers, Table.TypeEntry theArrayType) {

        SymbolSet starters = new SymbolSet();
        boolean ok;

        starters.clear();
        starters.include(LeftBracket);
        starters.include(IntegerNumber);
        starters.include(Thru);
        ok = checkForStarter(starters, followers);
        if (ok) {
            accept(LeftBracket);
            if (lexicalAnalyser.symbolDescription.symbol == lexicalAnalyser.IntegerNumber)
                ((Table.ArrayTypeEntry)theArrayType).indexMin = lexicalAnalyser.symbolDescription.intValue;
            accept(IntegerNumber);
            accept(Thru);
            if (lexicalAnalyser.symbolDescription.symbol == lexicalAnalyser.IntegerNumber)
                ((Table.ArrayTypeEntry)theArrayType).indexMax = lexicalAnalyser.symbolDescription.intValue;
            if (((Table.ArrayTypeEntry)theArrayType).indexMax < ((Table.ArrayTypeEntry)theArrayType).indexMin )
                semanticError((short)79);
            accept(IntegerNumber);
            accept(RightBracket);
            findFollower(followers);
        }
    } /* indexType */


    private static void procedureDeclaration(SymbolSet followers) {

        Table.ProceduresIdentifierEntry procedureIdentifier;
        Host.Word procedureName;
        SymbolSet localSet = new SymbolSet();

        accept(Procedure);
        if (lexicalAnalyser.symbolDescription.symbol == Identifier)
            procedureName = lexicalAnalyser.symbolDescription.spelling;
        else
            procedureName = Host.blankWord;
        procedureIdentifier = (Table.ProceduresIdentifierEntry)Table.newId(procedureName, Procedures);
        procedureIdentifier.linkage = Generator.newLinkage();
        accept(Identifier);
        accept(Semicolon);
        localSet.copy(followers);
        localSet.include(Identifier);
        block(localSet, procedureIdentifier);
        if (lexicalAnalyser.symbolDescription.symbol == Identifier)
            checkIsSameAs(procedureName);
        accept(Identifier);
        findFollower(followers);
    } /* procedureDeclaration */



    private static void statementPart(SymbolSet followers, Table.IdentifierEntry blockId) {
        SymbolSet starters = new SymbolSet();
        SymbolSet localSet = new SymbolSet();
        boolean ok;

        starters.clear();
        starters.include(Begin);
        ok = checkForStarter(starters, followers);
        if (ok) {
            if (blockId == nullIdentifier)
                Generator.enterProgram();
            else
                Generator.enterBody( ((Table.ProceduresIdentifierEntry)blockId).linkage);
            currentLoop = null;
            accept(Begin);
            localSet.copy(followers);
            localSet.include(End);
            statementSequence(localSet);
            accept(End);
            if (blockId == nullIdentifier)
                Generator.leaveProgram();
            else
                Generator.leaveBody( ((Table.ProceduresIdentifierEntry)blockId).linkage);
            findFollower(followers);
        }
    } /* statementPart */


    private static void statementSequence(SymbolSet followers) {
        SymbolSet localSet = new SymbolSet();
        SymbolSet tempSet = new SymbolSet();
        boolean ok;

        ok = checkForStarter(statementStarters, followers);
        if (ok) {
            localSet.union(statementStarters, followers);
            localSet.include(Semicolon);
            localSet.remove(Identifier);
            statement(localSet);
            tempSet.copy(statementStarters);
            tempSet.include(Semicolon);
            tempSet.remove(Identifier);
            while (tempSet.contains(lexicalAnalyser.symbolDescription.symbol)) {
                accept(Semicolon);
                statement(localSet);
            }
            findFollower(followers);
        }
    } /* statementSequence */


    private static void statement(SymbolSet followers) {
        boolean ok;
        Table.IdentifierEntry firstIdentifier;

        ok = checkForStarter(statementStarters, followers);
        if (ok) {
            switch (lexicalAnalyser.symbolDescription.symbol) {
                case Identifier:
                {
                    firstIdentifier = Table.searchId(lexicalAnalyser.symbolDescription.spelling,
                            new Table.IdClassSet().include(Procedures)
                            .include(Variables)  );
                    if (firstIdentifier.idClass == Variables)
                        assignment(followers);
                    else {
                        Generator.callProcedure( ((Table.ProceduresIdentifierEntry)firstIdentifier).linkage);
                        accept(Identifier);
                    }
                    break;
                }
//		    	Case statements are added to handle the do and while statements,
//		    	therefore if the identifier is Do or While, the doStatement() or
//		   		whileStatement is called
                case If:    { ifStatement   (followers);  break; }
                case Exit:  { exitStatement(followers);  break; }
                case Loop:  { loopStatement(followers);  break; }
                case Case:  { caseStatement(followers);  break; }
                case For:   { forStatement  (followers);  break; }
                case Read:  { readStatement(followers);  break; }
                case Write: { writeStatement(followers);  break; }
//      		SymbolSet parameters are added to the doStatement
//				and whileStatement methods to pass in the possible
//				followers in that case
		        case Do: 	{ doStatement   (followers);  break; }
		      	case While: { whileStatement(followers);  break; }
            }
            findFollower(followers);
        }
    } /* statement */



    private static Table.TypeEntry variable(SymbolSet followers) {

        Table.TypeEntry variableType;
        SymbolSet starters = new SymbolSet();
        SymbolSet localSet = new SymbolSet();
        boolean ok;
        Table.VariablesIdentifierEntry variableIdentifier;
        Table.ArrayTypeEntry arrayVariableType;
        Table.TypeEntry indexType;
        Table.TypeEntry elementType;

        variableType = Table.TypeEntry.getUndefined();
        //arrayVariableType =  Table.ArrayTypeEntry.getUndefined();
        starters.clear();
        starters.include(Identifier);
        ok = checkForStarter(starters, followers);
        if (ok) {
            variableIdentifier = (Table.VariablesIdentifierEntry)
            Table.searchId( lexicalAnalyser.symbolDescription.spelling,
                    new Table.IdClassSet().include(Variables));
            variableType = variableIdentifier.idType;
            Generator.stackReference(variableIdentifier.variableAddress);
            accept(Identifier);
            if (lexicalAnalyser.symbolDescription.symbol == lexicalAnalyser.LeftBracket) {
                if (!variableType.isUndefined()) {
                    if (variableType.form != Arrays) {
                        semanticError((short)61);
                        variableType = Table.ArrayTypeEntry.getUndefined();
                    }
                }
                accept(LeftBracket);
                localSet.copy(followers);
                localSet.include(RightBracket);
                indexType = expression(localSet);
                if (!Table.compatible(indexType, integerType))
                    semanticError((short)62);
                if (!variableType.isUndefined()) {
                    elementType = ((Table.ArrayTypeEntry)variableType).elementType;
                    Generator.indexedReference
                            ( ((Table.ArrayTypeEntry)variableType).indexMin,
                            ((Table.ArrayTypeEntry)variableType).indexMax,
                            elementType.representation );
                    variableType = elementType;
                }
                accept(RightBracket);
            }
            findFollower(followers);
        }
        return variableType;
    } /* variable */


    private static Table.TypeEntry expression(SymbolSet followers) {

        Table.TypeEntry expressionType;
        SymbolSet localSet = new SymbolSet();
        byte operator;
        Table.TypeEntry simpleExpressionType;

        localSet.union(relationalOps, followers);
        simpleExpressionType = simpleExpression(localSet);
        expressionType = simpleExpressionType;
        if (relationalOps.contains(lexicalAnalyser.symbolDescription.symbol)) {
            operator = lexicalAnalyser.symbolDescription.symbol;
            lexicalAnalyser.getNextSymbol();
            simpleExpressionType = simpleExpression(followers);
            if (!(    (    Table.compatible(simpleExpressionType, integerType)
            || Table.compatible(simpleExpressionType, charType)
            || Table.compatible(simpleExpressionType, booleanType) )
            && Table.compatible(simpleExpressionType, expressionType)     ))
                semanticError((short)65);
            Generator.comparison(operator);
            expressionType = booleanType;
        }
        return expressionType;
    } /* expression */


    private static Table.TypeEntry simpleExpression(SymbolSet followers) {
        Table.TypeEntry simpleExpressionType;
        SymbolSet starters = new SymbolSet();
        SymbolSet localSet = new SymbolSet();
        boolean ok;
        boolean signed;
        boolean negated = false;
        Table.TypeEntry termType;
        byte operator;

        starters.union(factorStarters, signs);
        ok = checkForStarter(starters, followers);
        if (ok) {
            if (signs.contains(lexicalAnalyser.symbolDescription.symbol)) {
                signed = true;
                negated = (lexicalAnalyser.symbolDescription.symbol == Minus);
                lexicalAnalyser.getNextSymbol();
            } else
                signed = false;
            localSet.union(additionOps, followers);
            termType = term(localSet);
            simpleExpressionType = termType;
            if (signed) {
                if (!Table.compatible(simpleExpressionType, integerType))
                    semanticError((short)64);
                else if (negated)
                    Generator.negateInteger();
            }
            while (additionOps.contains(lexicalAnalyser.symbolDescription.symbol)) {
                operator = lexicalAnalyser.symbolDescription.symbol;
                lexicalAnalyser.getNextSymbol();
                termType = term(localSet);
                switch (operator) {
                    case Plus:
                    case Minus:
                    {
                        if (!    (Table.compatible(simpleExpressionType, integerType)
                        && Table.compatible(termType, integerType)))
                            semanticError((short)64);
                        Generator.binaryIntegerOperation(operator);
                        simpleExpressionType = integerType;
                        break;
                    }
                    case Or:
                    {
                        if (!(Table.compatible(simpleExpressionType, booleanType) && Table.compatible(termType, booleanType)))
                            semanticError((short)63);
                        Generator.binaryBooleanOperation(operator);
                        simpleExpressionType = booleanType;
                        break;
                    }
                }
            }
            findFollower(followers);
        } else
            simpleExpressionType = Table.TypeEntry.getUndefined();
        return simpleExpressionType;
    } /* simpleExpression */


    private static Table.TypeEntry term(SymbolSet followers) {
        Table.TypeEntry termType;
        SymbolSet localSet = new SymbolSet();
        SymbolSet tempSet = new SymbolSet();
        Table.TypeEntry factorType;
        byte operator;

        tempSet.union(multiplicationOps, factorStarters);
        localSet.union(followers, tempSet);
        factorType = factor(localSet);
        termType = factorType;
        while (tempSet.contains(lexicalAnalyser.symbolDescription.symbol)) {
            operator = lexicalAnalyser.symbolDescription.symbol;
            if (multiplicationOps.contains(lexicalAnalyser.symbolDescription.symbol))
                lexicalAnalyser.getNextSymbol();
            else
                syntaxError(Times);
            factorType = factor(localSet);
            if (multiplicationOps.contains(operator)) {
                switch (operator) {
                    case Times:
                    case Div:
                    {
                        if (!(    Table.compatible(termType, integerType)
                        && Table.compatible(factorType, integerType)  ))
                            semanticError((short)64);
                        Generator.binaryIntegerOperation(operator);
                        termType = integerType;
                        break;
                    }
                    case And:
                    {
                        if (!(    Table.compatible(termType, booleanType)
                        && Table.compatible(factorType, booleanType)  ))
                            semanticError((short)63);
                        Generator.binaryBooleanOperation(operator);
                        termType = booleanType;
                        break;
                    }
                }
            } else
                termType = Table.TypeEntry.getUndefined();
        }
        return termType;
    } /* term */


    private static Table.TypeEntry factor(SymbolSet followers) {
        Table.TypeEntry factorType;
        SymbolSet localSet = new SymbolSet();
        boolean ok;
        Table.IdentifierEntry firstIdentifier;

        factorType = Table.TypeEntry.getUndefined();
        ok = checkForStarter(factorStarters, followers);
        if (ok) {
            switch (lexicalAnalyser.symbolDescription.symbol) {
                case Identifier:
                {
                    firstIdentifier = Table.searchId(lexicalAnalyser.symbolDescription.spelling,
                            new Table.IdClassSet().include(Variables)
                            .include(Constants));
                    switch (firstIdentifier.idClass) {
                        case Constants:
                        {
                            factorType = firstIdentifier.idType;
                            Generator.stackConstant(  ((Table.ConstantsIdentifierEntry)firstIdentifier).constantValue,
                                    factorType.representation);
                            accept(Identifier);
                            break;
                        }
                        case Variables:
                        {
                            factorType = variable(followers);
                            if (! factorType.isUndefined() )
                                Generator.deReference(factorType.representation);
                            break;
                        }
                    }
                    break;
                }
                case IntegerNumber:
                {
                    factorType = integerType;
                    Generator.stackConstant(lexicalAnalyser.symbolDescription.intValue, integerType.representation);
                    accept(IntegerNumber);
                    break;
                }
                case CharConstant:
                {
                    factorType = charType;
                    Generator.stackConstant(lexicalAnalyser.symbolDescription.charValue, charType.representation);
                    accept(CharConstant);
                    break;
                }
                case LeftParenthesis:
                {
                    accept(LeftParenthesis);
                    localSet.copy(followers);
                    localSet.include(RightParenthesis);
                    factorType = expression(localSet);
                    accept(RightParenthesis);
                    break;
                }
                case Not:
                {
                    accept(Not);
                    factorType = factor(followers);
                    if (!Table.compatible(factorType, booleanType))
                        semanticError((short)63);
                    Generator.negateBoolean();
                    factorType = booleanType;
                    break;
                }
            }
            findFollower(followers);
        }
        return factorType;
    } /* factor */


    private static void assignment(SymbolSet followers) {
        SymbolSet localSet = new SymbolSet();
        Table.TypeEntry variableType;
        Table.TypeEntry expressionType;

        localSet.copy(followers);
        localSet.include(Becomes);
        variableType = variable(localSet);
        accept(Becomes);
        expressionType = expression(followers);
        if (!Table.compatible(variableType, expressionType))
            semanticError((short)66);
        Generator.assign();
    } /* assignment */


    private static void readStatement(SymbolSet followers) {
        accept(Read);
        accept(LeftParenthesis);
        inputVariable(followers);
        accept(RightParenthesis);
        Generator.assign();
    } /* readStatement */


    private static void inputVariable(SymbolSet followers) {
        SymbolSet localSet = new SymbolSet();
        Table.TypeEntry variableType;

        localSet.copy(followers);
        localSet.include(RightParenthesis);
        variableType = variable(localSet);
        if ( Table.compatible(variableType, charType) )
            Generator.readOperation(Generator.CharMode);
        else if ( Table.compatible(variableType, integerType) )
            Generator.readOperation(Generator.IntegerMode);
        else
            semanticError((short)67);
    } /* inputVariable */


    private static void writeStatement(SymbolSet followers) {
        accept(Write);
        accept(LeftParenthesis);
        outputValue(followers);
        accept(RightParenthesis);
    } /* writeStatement */


    private static void outputValue(SymbolSet followers) {
        SymbolSet localSet = new SymbolSet();
        Table.TypeEntry expressionType;

        localSet.copy(followers);
        localSet.include(RightParenthesis);
        expressionType = expression(localSet);
        if ( Table.compatible(expressionType, charType) )
            Generator.writeOperation(Generator.CharMode);
        else if (Table.compatible(expressionType, integerType) )
            Generator.writeOperation(Generator.IntegerMode);
        else
            semanticError((short)68);
    } /* outputValue */


    private static void ifStatement(SymbolSet followers) {
        SymbolSet localSet = new SymbolSet();
        Table.TypeEntry expressionType;
        Generator.CodeLabel afterTrueAction = new Generator.CodeLabel();
        Generator.CodeLabel afterFalseAction = new Generator.CodeLabel();

        accept(If);
        localSet.copy(followers);
        localSet.include(Then);
        localSet.include(Else);
        localSet.include(End);
        expressionType = expression(localSet);
        if (!Table.compatible(expressionType, booleanType))
            semanticError((short)69);
        Generator.futureCodeLabel(afterTrueAction);
        Generator.jumpOnFalse(afterTrueAction);
        accept(Then);
        localSet.remove(Then);
        statementSequence(localSet);
        if (lexicalAnalyser.symbolDescription.symbol == lexicalAnalyser.Else) {
            Generator.futureCodeLabel(afterFalseAction);
            Generator.jump(afterFalseAction);
            Generator.expectedCodeLabel(afterTrueAction);
            accept(Else);
            localSet.remove(Else);
            statementSequence(localSet);
            Generator.expectedCodeLabel(afterFalseAction);
        } else
            Generator.expectedCodeLabel(afterTrueAction);
        accept(End);
    } /* ifStatement */




    private static void caseStatement(SymbolSet followers) {
        Table.TypeEntry caseType;
        CaseRecord firstCase;
        SymbolSet localSet = new SymbolSet();
        SymbolSet tempSet = new SymbolSet();
        Generator.CodeLabel followingStatement = new Generator.CodeLabel();

        Generator.futureCodeLabel(followingStatement);
        accept(Case);
        localSet.copy(followers);
        localSet.include(Of);
        localSet.include(Separator);
        localSet.include(End);
        caseType = expression(localSet);
        if (!Table.isOrdinalType(caseType)) {
            semanticError((short)68);
            caseType = Table.TypeEntry.getUndefined();
        }
        accept(Of);
        localSet.remove(Of);
        firstCase = null;
        Generator.openCase();
        tempSet.clear();
        tempSet.include(Comma);
        tempSet.include(Identifier);
        tempSet.include(IntegerNumber);
        tempSet.include(CharConstant);
        do
        {
            accept(Separator);
            while (true) {
                firstCase = newCaseLabel(firstCase, caseType);
                if (!tempSet.contains(lexicalAnalyser.symbolDescription.symbol))
                    break;
                accept(Comma);
            }
            accept(Colon);
            statementSequence(localSet);
            Generator.jump(followingStatement);
        }
        while (!(    lexicalAnalyser.symbolDescription.symbol == End
                || (    followers.contains(lexicalAnalyser.symbolDescription.symbol)
                && lexicalAnalyser.symbolDescription.symbol != Separator        )  ));

        Generator.closeCase();
        disposeOfCaseList(firstCase);
        accept(End);
        Generator.expectedCodeLabel(followingStatement);
    } /* caseStatement */


    private static class caseLabelRecord {
        public Table.TypeEntry caseLabelType;
        public short caseLabelValue;
    } /* caseLabelRecord */

    private static void caseLabel(caseLabelRecord details) {
        Table.ConstantsIdentifierEntry constantIdentifier;

        if (lexicalAnalyser.symbolDescription.symbol == lexicalAnalyser.IntegerNumber) {
            details.caseLabelType = integerType;
            details.caseLabelValue = lexicalAnalyser.symbolDescription.intValue;
        } else if (lexicalAnalyser.symbolDescription.symbol == lexicalAnalyser.CharConstant) {
            details.caseLabelType = charType;
            details.caseLabelValue = lexicalAnalyser.symbolDescription.charValue;
        } else if (lexicalAnalyser.symbolDescription.symbol == lexicalAnalyser.Identifier) {
            constantIdentifier = (Table.ConstantsIdentifierEntry )
            Table.searchId( lexicalAnalyser.symbolDescription.spelling,
                    new Table.IdClassSet().include(Constants));
            details.caseLabelType = constantIdentifier.idType;
            details.caseLabelValue = constantIdentifier.constantValue;
        } else
            details.caseLabelType = Table.TypeEntry.getUndefined();
    } /* caseLabel */


    private static class CaseRecord {
        public short caseValue;
        public CaseRecord nextCase;
    }


    private static CaseRecord appendCaseLabel(CaseRecord firstCase, short labelValue) {
        CaseRecord thisCase;
        CaseRecord lastCase;

        thisCase = firstCase;
        lastCase = null;
        while (true) {
            if (thisCase == null) {
                thisCase = new CaseRecord();
                thisCase.caseValue = labelValue;
                Generator.nextIsCase(labelValue);
                thisCase.nextCase = null;
                if (lastCase == null)
                    firstCase = thisCase;
                else
                    lastCase.nextCase = thisCase;
                break;
            } else if (thisCase.caseValue == labelValue) {
                semanticError((short)74);
                break;
            } else {
                lastCase = thisCase;
                thisCase = thisCase.nextCase;
            }
        }
        return firstCase;
    } /* appendCaseLabel */


    private static void disposeOfCaseList(CaseRecord firstCase) {
        CaseRecord thisCase;
        CaseRecord nextCase;

        nextCase = firstCase;
        while (nextCase != null) {
            thisCase = nextCase;
            nextCase = thisCase.nextCase;
            thisCase = null;
        }
    } /* disposeOfCaseList */


    private static CaseRecord newCaseLabel(CaseRecord firstCase, Table.TypeEntry caseType) {
        Table.TypeEntry labelType;
        short labelValue;
        caseLabelRecord theDetails;

        theDetails = new caseLabelRecord();
        caseLabel(theDetails);
        labelType = theDetails.caseLabelType;
        labelValue = theDetails.caseLabelValue;
        theDetails = null;
        if (!labelType.isUndefined()) {
            if (Table.compatible(labelType, caseType))
                firstCase = appendCaseLabel(firstCase, labelValue);
            else
                semanticError((short)73);
        } else
            syntaxError(OtherSymbol);
        lexicalAnalyser.getNextSymbol();
        return firstCase;
    } /* newCaseLabel */


    private static class LoopEntry {
        Generator.CodeLabel endOfLoop;
        LoopEntry enclosingLoop;
    }

    static void createThisLoopRecord() {
        LoopEntry newEntry = new LoopEntry();
        newEntry.enclosingLoop = currentLoop;
        newEntry.endOfLoop = new Generator.CodeLabel();
        currentLoop = newEntry;
    }

    static void destroyThisLoopRecord() {
        LoopEntry oldEntry;

        oldEntry = currentLoop;
        currentLoop = currentLoop.enclosingLoop;
        oldEntry.endOfLoop = null;
        oldEntry = null;
    }

    private static LoopEntry currentLoop;

    private static void loopStatement(SymbolSet followers) {
        SymbolSet localSet = new SymbolSet();
        Generator.CodeLabel startOfThisLoop = new Generator.CodeLabel();

        createThisLoopRecord();
        Generator.bindCodeLabel(startOfThisLoop);
        Generator.futureCodeLabel(currentLoop.endOfLoop);

        accept(Loop);
        localSet.copy(followers);
        localSet.include(End);
        statementSequence(localSet);
        accept(End);
        Generator.jump(startOfThisLoop);
        Generator.expectedCodeLabel(currentLoop.endOfLoop);
        destroyThisLoopRecord();
    } /* loopStatement */


    private static void exitStatement(SymbolSet followers) {
        accept(Exit);
        if (currentLoop != null)
            Generator.jump(currentLoop.endOfLoop);
        else
            semanticError((short)72);
    } /* exitStatement */

    private static void forStatement(SymbolSet followers) {
        SymbolSet localSet = new SymbolSet();
        Table.VariablesIdentifierEntry controlVariableId;
        Table.TypeEntry controlVariableType;
        Table.TypeEntry expressionType;

        accept(For);
        if (lexicalAnalyser.symbolDescription.symbol == lexicalAnalyser.Identifier) {
            controlVariableId = (Table.VariablesIdentifierEntry)
            Table.searchId( lexicalAnalyser.symbolDescription.spelling,
                    new Table.IdClassSet().include(Variables));
            controlVariableType = controlVariableId.idType;
            if (!Table.isOrdinalType(controlVariableType)) {
                semanticError((short)71);
                controlVariableType = Table.TypeEntry.getUndefined();
            }
            Generator.stackReference(controlVariableId.variableAddress);
        } else
            controlVariableType = Table.TypeEntry.getUndefined();
        accept(Identifier);
        accept(Becomes);
        localSet.copy(followers);
        localSet.include(To);
        localSet.include(Do);
        localSet.include(End);
        expressionType = expression(localSet);
        if (!Table.compatible(controlVariableType, expressionType))
            semanticError((short)66);
        accept(To);
        localSet.remove(To);
        expressionType = expression(localSet);
        if (!Table.compatible(controlVariableType, expressionType))
            semanticError((short)66);
        accept(Do);
        localSet.remove(Do);
        Generator.openFor();
        statementSequence(localSet);
        Generator.closeFor();
        accept(End);
    } /* forStatement */

//	the doStatement method recognises the syntax for a do statement
//	so the compiler knows what to look for It passes in a SymbolSet as
//  a parameter so the compiler can understand what the possible followers
//  can be
    private static void doStatement (SymbolSet followers)
    {
//  	as well as a SymbolSet, now a Table.TypeEntry is declared
//		for the expression in the statement
	    SymbolSet localSet = new SymbolSet();
	    Table.TypeEntry expressionType;
//	    code labels are generated to specify the branching of
//		the structure in the object code
	    Generator.CodeLabel endOfDoAction = new Generator.CodeLabel();
	    Generator.CodeLabel whileTrueAction = new Generator.CodeLabel();

	  	accept(Do);
	    localSet.copy(followers);
	    localSet.include(LeftCurlyBracket);
	    localSet.include(RightCurlyBracket);
	    localSet.include(While);
	    localSet.include(LeftParenthesis);
	    localSet.include(RightParenthesis);
//	    branches back to the start of the statement sequence
	    Generator.bindCodeLabel(whileTrueAction);
	    accept(LeftCurlyBracket);
	    localSet.remove(LeftCurlyBracket);
	    statementSequence(localSet);
	    accept(RightCurlyBracket);
	    localSet.remove(RightCurlyBracket);
	    accept(While);
	    localSet.remove(While);
	    accept(LeftParenthesis);
	    localSet.remove(LeftParenthesis);
//  	the expression(localSet) command is replaced by this code which
//  	assigns expression(localSet) to the Table.TypeEntry and
//  	then displays an error if the expression type is not a boolean value
	    expressionType = expression(localSet);
	    if (!Table.compatible(expressionType, booleanType))
	      semanticError((short)69);
	    accept(RightParenthesis);
	    localSet.remove(RightParenthesis);
//	    if the do statement is over and the boolean expression
//		equates to false the program jumps over the next branch
	    Generator.futureCodeLabel(endOfDoAction);
        Generator.jumpOnFalse(endOfDoAction);
//      if the boolean equates to true the program will not jump
//      past this statement and the program will branch back to
//      the start of the statement sequence
        Generator.jump(whileTrueAction);
        Generator.expectedCodeLabel(endOfDoAction);
	    accept(End);
    }

//	the whileStatement method recognises the syntax for a while statement
//	so the compiler knows what to look for. It passes in a SymbolSet as
//  a parameter so the compiler can understand what the possible followers
//  can be
    private static void whileStatement (SymbolSet followers)
    {
//  	as well as a SymbolSet, now a Table.TypeEntry is declared
//		for the expression in the statement
	    SymbolSet localSet = new SymbolSet();
	    Table.TypeEntry expressionType;
//	    code labels are generated to specify the branching of
//		the structure in the object code
	    Generator.CodeLabel whileFalseAction = new Generator.CodeLabel();
        Generator.CodeLabel endOfWhileAction = new Generator.CodeLabel();

	    accept(While);
	    localSet.copy(followers);
	    localSet.include(LeftParenthesis);
	    localSet.include(RightParenthesis);
	    localSet.include(LeftCurlyBracket);
	    localSet.include(RightCurlyBracket);
	    accept(LeftParenthesis);
	    localSet.remove(LeftParenthesis);
//  	the expression(localSet) command is replaced by this code which
//  	assigns expression(localSet) to the Table.TypeEntry and
//  	then displays an error if the expression type is not a boolean value
	    expressionType = expression(localSet);
	    if (!Table.compatible(expressionType, booleanType))
	      semanticError((short)69);
	    accept(RightParenthesis);
	    localSet.remove(RightParenthesis);
//	    branches back to the start of the statement sequence
	    Generator.bindCodeLabel(endOfWhileAction);
//	    if the while statement is over and the boolean expression
//		equates to false the program will branch to the end
//		of the statement sequence
	    Generator.futureCodeLabel(whileFalseAction);
        Generator.jumpOnFalse(whileFalseAction);
	    accept(LeftCurlyBracket);
	    localSet.remove(LeftCurlyBracket);
	    statementSequence(localSet);
	    accept(RightCurlyBracket);
	    localSet.remove(RightCurlyBracket);
//		the program branches back to the start of the
//		statement sequence to test whether the boolean
//		expression is still true or false
        Generator.jump(endOfWhileAction);
//		when the while statement is over and the boolean
//		expression is false it branches to here
	    Generator.expectedCodeLabel(whileFalseAction);
	    accept(End);
    }

} /* FullAnalyser */



