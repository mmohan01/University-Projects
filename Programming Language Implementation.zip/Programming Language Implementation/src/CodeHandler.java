/* CodeHandler.java: code handler */

import java.util.Date;
import java.text.DateFormat;

public class CodeHandler implements OrderCode, Register {
    private static String [ ] mnemonic      = new String [45];
    private static String [ ] registerName  = new String [4];

    private static void initialiseMnemonicsTable() {
        mnemonic[ NOOP ]    =  "NOOP  ";
        mnemonic[ LOAD ]    =  "LOAD  ";
        mnemonic[ LOADL ]   =  "LOADL ";
        mnemonic[ LOADR ]   =  "LOADR ";
        mnemonic[ LOADA ]   =  "LOADA ";
        mnemonic[ LOADI ]   =  "LOADI ";
        mnemonic[ STORE ]   =  "STORE ";
        mnemonic[ STORER ]  =  "STORER";
        mnemonic[ STOREI ]  =  "STOREI";
        mnemonic[ STZ ]     =  "STZ   ";
        mnemonic[ INCR ]    =  "INCR  ";
        mnemonic[ INCREG ]  =  "INCREG";
        mnemonic[ MOVE ]    =  "MOVE  ";
        mnemonic[ SLL ]     =  "SLL   ";
        mnemonic[ SRL ]     =  "SRL   ";
        mnemonic[ ADD ]     =  "ADD   ";
        mnemonic[ SUB ]     =  "SUB   ";
        mnemonic[ MUL ]     =  "MUL   ";
        mnemonic[ DVD ]     =  "DVD   ";
        mnemonic[ DREM ]    =  "DREM  ";
        mnemonic[ LAND ]    =  "LAND  ";
        mnemonic[ LOR ]     =  "LOR   ";
        mnemonic[ INV ]     =  "INV   ";
        mnemonic[ NEG ]     =  "NEG   ";
        mnemonic[ CLT ]     =  "CLT   ";
        mnemonic[ CLE ]     =  "CLE   ";
        mnemonic[ CEQ ]     =  "CEQ   ";
        mnemonic[ CNE ]     =  "CNE   ";
        mnemonic[ BRN ]     =  "BRN   ";
        mnemonic[ BIDX ]    =  "BIDX  ";
        mnemonic[ BZE ]     =  "BZE   ";
        mnemonic[ BNZ ]     =  "BNZ   ";
        mnemonic[ BNG ]     =  "BNG   ";
        mnemonic[ BPZ ]     =  "BPZ   ";
        mnemonic[ BVS ]     =  "BVS   ";
        mnemonic[ BES ]     =  "BBS   ";
        mnemonic[ MARK ]    =  "MARK  ";
        mnemonic[ CALL ]    =  "CALL  ";
        mnemonic[ EXT ]     =  "EXIT  ";
        mnemonic[ SETSP ]   =  "SETSP ";
        mnemonic[ SETPSR ]  =  "SETPSR";
        mnemonic[ HLT ]     =  "HALT  ";
        mnemonic[ CHECK ]   =  "CHECK ";
        mnemonic[ CHIN ]    =  "CHIN  ";
        mnemonic[ CHOUT ]   =  "CHOUT ";

    } /* initialiseMnemonicsTable */


    private static void initialiseRegisterNames() {
        registerName[ BP ] = "BP";
        registerName[ FP ] = "FP";
        registerName[ MP ] = "MP";
        registerName[ SP ] = "SP";
    }

    private static class InstructionRecord {
        public short location;
        public Target.Instruction inst;
        public InstructionRecord next;
    }


    private static InstructionRecord instructionList;
    private static InstructionRecord lastInstruction;
    private static short nextLocation;
    private static Host.File codeFile = new Host.File();

    public static void locateInstruction(short at, Target.Instruction content) {
        InstructionRecord newEntry;
        InstructionRecord thisInstruction;
        InstructionRecord previousInstruction;
        if ( at < nextLocation ) {
            thisInstruction = instructionList;
            previousInstruction = null;
            while (( thisInstruction != null ) && ( thisInstruction.location < at )) {
                previousInstruction = thisInstruction;
                thisInstruction = thisInstruction.next;
            }
        } else {
            previousInstruction = lastInstruction;
            thisInstruction = null;
            nextLocation = at;
        }

        newEntry = new InstructionRecord();

        newEntry.location = at;
        newEntry.inst = content ;
        newEntry.next = thisInstruction;
        if ( previousInstruction == null )
            instructionList = newEntry;
        else
            previousInstruction.next = newEntry;
        if ( thisInstruction == null )
            lastInstruction = newEntry;

    } /* locateInstruction */


    private static void writeInstruction(Target.Instruction thisInstruction) {

        codeFile.writeString( mnemonic[ thisInstruction.opCode ] );
        codeFile.writeString( "   ");
        switch (thisInstruction.opCode) {
            case LOAD:  case LOADA:   case STORE:   case STZ:   case BRN:
            case BZE:   case BNZ:     case BNG:     case BPZ:   case BVS:
            case BES:   case CALL:    case SETSP:
            {
                codeFile.writeInteger( thisInstruction.n, (byte)6 );
                codeFile.writeString( ",[" );
                codeFile.writeString( registerName[ thisInstruction.r ] );
                codeFile.writeChar( ',' );
                codeFile.writeCardinal( thisInstruction.l, (byte)2 );
                codeFile.writeChar( ']' );
                break;
            }

            case LOADL: case LOADI: case STOREI:  case INCR:  case MOVE:
            case SLL:   case SRL:   case BIDX:    case MARK:  case SETPSR:
            {
                codeFile.writeInteger( thisInstruction.n, (byte)6 );
                break;
            }
            case LOADR: case STORER:
            {
                codeFile.writeString( "     " );
                codeFile.writeString( registerName[ thisInstruction.r ]);
                break;
            }
            case INCREG:
            {
                codeFile.writeString( "     " );
                codeFile.writeString( registerName[ thisInstruction.r ]);
                codeFile.writeChar( ',' );
                codeFile.writeInteger( thisInstruction.n, (byte)2 );
                break;
            }
            default:
            {
            }
        }

    } /* writeInstruction */


    public static void listCode() {

        InstructionRecord thisInstruction;
        InstructionRecord NextInstruction;
        short LastLocation;
        boolean OK;

        OK = codeFile.openFile( "Enter name of object code listing file: ", Host.File.Output);
        if (OK) {
            codeFile.writeString( "*** OBJECT CODE GENERATED ***        " );
            codeFile.writeString( DateFormat.getDateTimeInstance().format(new Date() ) );
            codeFile.writeLine();
            thisInstruction = instructionList;
            LastLocation = (short)0;
            while ( thisInstruction != null ) {
                if ( thisInstruction.location != (short)(LastLocation + 2) )
                    codeFile.writeLine();
                codeFile.writeCardinal( thisInstruction.location, (byte)8 );
                codeFile.writeString( "    " );
                writeInstruction( thisInstruction.inst );
                codeFile.writeLine();
                LastLocation = thisInstruction.location;
                NextInstruction = thisInstruction.next;
                thisInstruction = null;
                thisInstruction = NextInstruction;
            }
            codeFile.writeLine();
            codeFile.writeLine();
            codeFile.writeString( "************ END ************" );
            codeFile.writeLine();
            codeFile.closeFile();
        }

    } /* listCode */


    static // initialise
    {
        initialiseMnemonicsTable();
        initialiseRegisterNames();
        instructionList = null;
        lastInstruction = null;
        nextLocation = (short)0;
    }
}





