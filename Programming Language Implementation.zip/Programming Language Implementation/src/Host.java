/* Host.java */  

import java.io.*;

public class Host
  {

  /* This module defines the operations which must be provided for the compiler  */
  /* by the host environment.  These include:                                    */

  /* (1) An operation for determining the ASCII ordinal value of any character   */
  /*     in the the host machine character set:                                  */

  public static byte asciiOrdinalOf (char c)
    {
    /*Extract lower byte of Unicode character */
    return (byte)(c & 0xFF);
    }


  /* (2) Constants and a class for performing text file input and output:        */

  public static final char LF = '\n';
  public static final char CR = '\r';
  public static final char EOL = '\r';

  public static class File
    {
    public static final byte Input = 0;
    public static final byte Output = 1;


    public static boolean endOfInput ( )
      {
      return endOfInput;
      }


    public boolean openFile ( String openPrompt, byte Mode)
      {
      boolean success = false;
      String theFileName;
      theFileName = getFileName (openPrompt);

      theAccessMode = Mode;
      try
        {
        switch (Mode)
          {
          case Input:
            {
            theFile = new FileReader (theFileName);
            success = true;
            endOfInput = false;
            break;
            }
          case Output:
            {
            theFile = new PrintWriter (new FileOutputStream (theFileName), true /* auto line flushing */);
            success = true;
            endOfInput = false;
            break;
            }
          }
        }
      catch (IOException e )
        {
        System.err.println ("File not opened properly - " + e.toString () );
        success = false;
        }

      return success;

      }

    public void closeFile ( )
      {

      switch (theAccessMode)
        {
        case Input:
          {
          try
            {
            ((FileReader) theFile).close ( );
            }
          catch (IOException e )
            {
            System.err.println ("File not closed properly - " + e.toString () );
            }
          break;
          }
        case Output:
          {
          ((PrintWriter) theFile).close ( );
          break;
          }
        }

      }


    public char readChar ( )
      {

      char c = (char)0;
      int charGot;

      try
        {
        charGot = ((FileReader)theFile).read ();
        if (charGot == -1)
          {
          c = EOL;
          endOfInput = true;
          }
        else
          {
          c = (char) charGot;
          endOfInput = false;
          }

        /* Lines end with LF CR so strip LF character */
        if (( c == LF ) && (!endOfInput))
          {
          charGot = ((FileReader)theFile).read ();
          if (charGot == -1)
            {
            c = EOL;
            endOfInput = true;
            }
          else
            {
            c = (char) charGot;
            endOfInput = false;
            }
          }
        }
      catch (IOException e )
        {
        System.err.println ("File read error - " + e.toString () );
        }
      return c;
      }

    public void writeChar (char c)
      {
      ((PrintWriter) theFile).print (c);
      }

    private void writePaddedString (String s, byte totalWidth)
      {
      for (int i = s.length( )+1; i <= totalWidth; i += 1)
        ((PrintWriter) theFile).print (' ');
      ((PrintWriter) theFile).print (s);
      }

    public void writeCardinal (short number, byte fieldWidth)
      {
      writePaddedString (String.valueOf(number), fieldWidth);
      //((PrintWriter) theFile).print (number);
      }


    public void writeInteger (short number, byte fieldWidth)
      {
      writePaddedString (String.valueOf(number), fieldWidth);
      //((PrintWriter) theFile).print (number);
      }

    public void writeCharArray (char[] charArray )
      {
      ((PrintWriter) theFile).print (charArray);
      }

    public void writeString (String s )
      {
      ((PrintWriter) theFile).print (s);
      }

    public void writeLine ( )
      {
      ((PrintWriter) theFile).println ( );
      }

    private String getFileName ( String openPrompt )
      {
      String theFileName = "";
      BufferedReader keyboard = new BufferedReader(new InputStreamReader(System.in));
      System.out.print (openPrompt);
      try
        {
        theFileName = keyboard.readLine();
        }
      catch (IOException e )
        {
        System.err.println ("Error with Standard Input - " + e.toString () );
        }
      return theFileName;
      }

    private byte theAccessMode;

    private Object theFile;  /* Will be either FileReader or PrintWriter */

    private static boolean endOfInput;

    }


  /* (3) Properties of identifiers on the host implementation, and spelling      */
  /*     comparison operations.                                                  */

  public static final byte MaxSignificantIdLength = 12;

  public static class Word
    {
    /*private*/ char [ ] theSpelling = new char [MaxSignificantIdLength];

    public Word (String s)
      {
      s.getChars (0, MaxSignificantIdLength, theSpelling, 0);
      }

    public void setCharAt (byte index, char ch)
      {
      if (index <= MaxSignificantIdLength)
        theSpelling[index] = ch;
      }

    public byte sigLength()
      {
      byte index;

      index = 0;
      while (( theSpelling[index] != ' ') && (index <(MaxSignificantIdLength-1) ) )
        index += 1;
      return index;
      }

    public char [] toCharArray ( )

      {
      return (theSpelling);
      }


    public static final byte FirstIsLess = 0, WordsEqual = 1, SecondIsLess = 2;

    public static byte comparisonOf ( Word w1, Word w2 )
      {

      /* Optimisation */
      if (w1 == w2)
        return WordsEqual;

      else
        {
        byte i = 0;
        while (true)
          {
          if ( w1.theSpelling[ i ] < w2.theSpelling[ i ] )
            return FirstIsLess;
          else if ( w1.theSpelling[ i ] > w2.theSpelling[ i ] )
            return SecondIsLess;
          else if (i == (MaxSignificantIdLength-1))
            return WordsEqual;
          else
            i += 1;
          }
        }
      }

    }

  public static final String blankWordSpelling = "            ";

  public static final Word blankWord = new Word (blankWordSpelling);


  public static interface StandardIdentifiers
    {
    public static final byte
      INTEGER = 0, CHAR = 1, BOOLEAN = 2, FALSE = 3, TRUE = 4;
    }


  static Word [ ] standardIdSpelling = new Word [5];

  public static Word getSpelling ( byte id )
    {
    return standardIdSpelling[id];
    }


  /* class initialisation */
  static
    {
    standardIdSpelling[ StandardIdentifiers.INTEGER ] = new Word ("INTEGER     ");
    standardIdSpelling[ StandardIdentifiers.CHAR ]    = new Word ("CHAR        ");
    standardIdSpelling[ StandardIdentifiers.BOOLEAN ] = new Word ("BOOLEAN     ");
    standardIdSpelling[ StandardIdentifiers.FALSE ]   = new Word ("FALSE       ");
    standardIdSpelling[ StandardIdentifiers.TRUE ]    = new Word ("TRUE        ");
    }

  }



