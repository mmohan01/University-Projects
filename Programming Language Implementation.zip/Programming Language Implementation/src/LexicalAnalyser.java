/* LexicalAnalyser.java  */

public class LexicalAnalyser implements SymbolType
  {

  /* The Lexical Analyser module enables the lexical scanning of symbols in the  */
  /* source stream through the public method getNextSymbol ( ).                  */
  /* When called, getNextSymbol ( ) scans the next language symbol in the input  */
  /* stream and returns a representation of it in the public static class        */
  /* SymbolDescription which has the following fields:                           */
  /*                                                                             */
  /* symbol    In all cases symbol represents the symbol scanned as defined by   */
  /*           the class SymbolType                                              */
  /* spelling  When symbol = Identifier, spelling holds the (significant)        */
  /*           characters of the identifier scanned                              */
  /* intValue  When symbol = IntegerNumber, intValue gives the integer           */
  /*           representation of the constant on the target machine              */
  /* charValue When symbol = Charconstant, charValue gives the ASCII ordinal     */
  /*           value of the constant on the target machine                       */
  /*                                                                             */
  /* The starting position of the symbol scanned is left in the field position.  */
  /*                                                                             */
  /* The Lexical Analyser reports errors with the following codes:               */
  /*  1 .... integer constant too large                                          */
  /*  2 .... illegal character constant                                          */
  /*  3 .... character constant incomplete                                       */

  public static class SymbolDescription
    {
    public static byte symbol;
    public static SourceHandler.TextPosition position;
    /* Next three are mutually exclusive */
    public static short intValue;
    public static short charValue;
    public static Host.Word spelling;
    }

  public static class WordSymbolRecord
    {
    public Host.Word spelling;
    public byte value;
    }

  public LexicalAnalyser( )
    {
    initialiseLookUpTable();
    getNextSymbol();    /* makes first symbol available */
    }

  public static final int MaxInteger = Target.MaxInteger;
  public static final byte MaxIdLength = Host.MaxSignificantIdLength;

  public SymbolDescription symbolDescription = new SymbolDescription ( );

  
						
	private static void nonNestedskipRestOfComment()
  	{
		SourceHandler.getNextCharacter();
		do
			{
			while ( SourceHandler.currentCharacter != '*' )  /* * */
					SourceHandler.getNextCharacter();
			SourceHandler.getNextCharacter();
			}
		while ( SourceHandler.currentCharacter != '>' );   /* > */
		SourceHandler.getNextCharacter();
    }
		
		
	public void getNextSymbol ( )
    {

    byte k;
    byte digit;
    char delimiter;
    byte i;

    while ( SourceHandler.currentCharacter == ' ' )
      SourceHandler.getNextCharacter();
    symbolDescription.position = SourceHandler.positionNow.copy ();

    if (isIdChar( SourceHandler.currentCharacter ))
      {
      /*  "A".."Z", "a".."z", "#", "$", "&" : Identifier or word symbol */
      k = 0;

      symbolDescription.spelling = new Host.Word (Host.blankWordSpelling);
      do
        {
        if (k < MaxIdLength )
          {
          k += 1;
          symbolDescription.spelling.setCharAt ((byte)(k-1), SourceHandler.currentCharacter);
          }
        SourceHandler.getNextCharacter();
        }
      while ( (isDigit( SourceHandler.currentCharacter )) || (isIdChar( SourceHandler.currentCharacter )) );

      wordSymbols[ lastOfLength[ k ] ].spelling = symbolDescription.spelling;
      i = (byte)(lastOfLength[ (k - 1) ] + 1);
      while ( Host.Word.comparisonOf( wordSymbols[ i ].spelling, symbolDescription.spelling ) != Host.Word.WordsEqual )
        i += 1;
      symbolDescription.symbol = wordSymbols[ i ].value;
      }

    else if (isDigit( SourceHandler.currentCharacter ))
      {
      /* "0".."9":  Integer constant */
      symbolDescription.symbol = IntegerNumber;
      symbolDescription.intValue = (short)0;
      do
        {
        digit = (byte)( SourceHandler.currentCharacter - '0' );
        if (     ( symbolDescription.intValue < (MaxInteger/10) )
              || (( symbolDescription.intValue == (MaxInteger/10) ) && ( digit <= (MaxInteger%10) )))
          {
          symbolDescription.intValue = (short)((10 * symbolDescription.intValue) + digit);
          }
        else
          {
          SourceHandler.error( (short)1, SourceHandler.positionNow );
          symbolDescription.intValue = (short)0;
          }
        SourceHandler.getNextCharacter();
        }
      while (isDigit( SourceHandler.currentCharacter ));
      }

    else
      switch (SourceHandler.currentCharacter)
        {
      case '\'':
      case '\"':
          {
          /* Character constant */
          symbolDescription.symbol = CharConstant;
          delimiter = SourceHandler.currentCharacter;
          SourceHandler.getNextCharacter();
          if ( SourceHandler.currentCharacter == delimiter )
            SourceHandler.error((short)2, SourceHandler.positionNow );
          symbolDescription.charValue = Target.ordinalOf( Host.asciiOrdinalOf( SourceHandler.currentCharacter ) );
          SourceHandler.getNextCharacter();
          if ( SourceHandler.currentCharacter != delimiter )
            SourceHandler.error((short)3, SourceHandler.positionNow );
          else
            SourceHandler.getNextCharacter();
          break;
          }

        /* 2-character operators and delimiters */
      case ':':
          {
          SourceHandler.getNextCharacter();
          if ( SourceHandler.currentCharacter == '=' )
            {
            symbolDescription.symbol = Becomes;
            SourceHandler.getNextCharacter();
            }
          else
            symbolDescription.symbol = Colon;
          break;
          }
      case '.':
          {
          SourceHandler.getNextCharacter();
          if ( SourceHandler.currentCharacter == '.' )
            {
            symbolDescription.symbol = Thru;
            SourceHandler.getNextCharacter();
            }
          else
            symbolDescription.symbol = Period;
          break;
          }
      case '<':
          {
          SourceHandler.getNextCharacter();
		  if (SourceHandler.currentCharacter == '*' )//comments line checking 
						{
						nonNestedskipRestOfComment(); //skipRestOfComment();
						getNextSymbol();
						}
         else 
          	if ( SourceHandler.currentCharacter == '=' )
            {
            symbolDescription.symbol = LessThanOrEqual;
            SourceHandler.getNextCharacter();
            }
          else if ( SourceHandler.currentCharacter == '>' )
            {
            symbolDescription.symbol = NotEquals;
            SourceHandler.getNextCharacter();
            }
          else
            symbolDescription.symbol = LessThan;
          break;
          }
      case '>':
          {
          SourceHandler.getNextCharacter();
          if ( SourceHandler.currentCharacter == '=' )
            {
            symbolDescription.symbol = GreaterThanOrEqual;
            SourceHandler.getNextCharacter();
           }
          else
            symbolDescription.symbol = GreaterThan;
          break;
          }
       case '(':
          { 
          SourceHandler.getNextCharacter();
		  
          symbolDescription.symbol = LeftParenthesis;
                
          
          break;
          }
        /* 1-character operators and delimiters */
      case '+':
          {
          symbolDescription.symbol = Plus;
          SourceHandler.getNextCharacter();
          break;
          }
      case '-':
          {
          symbolDescription.symbol = Minus;
          SourceHandler.getNextCharacter();
          break;
          }
      case '*':
          {
          symbolDescription.symbol = Times;
          SourceHandler.getNextCharacter();
          break;
          }
      case '=':
          {
          symbolDescription.symbol = Equals;
          SourceHandler.getNextCharacter();
          break;
          }
          
      
      case ')':
          {
          symbolDescription.symbol = RightParenthesis;
          SourceHandler.getNextCharacter();
          break;
          }
          case '{':
                {
                    symbolDescription.symbol = LeftCurlyBracket;
                    SourceHandler.getNextCharacter();
                    break;
                }
                case '}':
                {
                    symbolDescription.symbol = RightCurlyBracket;
                    SourceHandler.getNextCharacter();
                    break;
                }
      case '[':
          {
          symbolDescription.symbol = LeftBracket;
          SourceHandler.getNextCharacter();
          break;
          }
      case ']':
          {
          symbolDescription.symbol = RightBracket;
          SourceHandler.getNextCharacter();
          break;
          }
      case ',':
          {
          symbolDescription.symbol = Comma;
          SourceHandler.getNextCharacter();
          break;
          }
      case ';':
          {
          symbolDescription.symbol = Semicolon;
          SourceHandler.getNextCharacter();
          break;
          }
      case '|':
          {
          symbolDescription.symbol = Separator;
          SourceHandler.getNextCharacter();
          break;
          }
      default:
          {
          /* illegal character */
          symbolDescription.symbol = OtherSymbol;
          SourceHandler.getNextCharacter();
          }
        }
      }


  private static final byte NumberOfWordSymbols = 23;  
  private static final byte WordSymbolTableSize = NumberOfWordSymbols + MaxIdLength;

  private static WordSymbolRecord[ ] wordSymbols = new WordSymbolRecord[WordSymbolTableSize + 1];
  private static byte [ ] lastOfLength = new byte [MaxIdLength + 1];

  private static boolean isDigit ( char Ch )
    {
    return (( Ch >= '0' ) & ( Ch <= '9' ));
    }


  private static boolean isLetter ( char Ch )
    {
    return ((( Ch >= 'A' ) & ( Ch <= 'Z' )) | (( Ch >= 'a' ) & ( Ch <= 'z' )));
    }
		
	private static boolean isIdChar ( char Ch )
    {
    return (  isLetter(Ch) 	|| ( Ch == '$' ) || ( Ch == '#' ) || ( Ch == '&' ));
    }



  private static void initialiseLookUpTable()
    {

    byte i;

    /* Allocate table elements */
    for (i = 0; i <= WordSymbolTableSize; i++)
      wordSymbols[ i ] = new WordSymbolRecord ( );

    lastOfLength[ 0 ] = 0;
    lastOfLength[ 1 ] = 1;
    lastOfLength[ 2 ] = 7;
    lastOfLength[ 3 ] = 14;
    lastOfLength[ 4 ] = 21;
    lastOfLength[ 5 ] = 26; 
    lastOfLength[ 6 ] = 28;  
    lastOfLength[ 7 ] = 29;  
    lastOfLength[ 8 ] = 30;  
    lastOfLength[ 9 ] = 32;
    lastOfLength[ 10 ] = 33;
    lastOfLength[ 11 ] = 34;
    lastOfLength[ 12 ] = 35;
		


    i = lastOfLength[ 1 ];
    wordSymbols[ i ].value = Identifier;
    wordSymbols[ i ].spelling = Host.blankWord;
    wordSymbols[ (i + 1) ].value = Do;
    wordSymbols[ (i + 1) ].spelling = new Host.Word ( "DO          ");
    wordSymbols[ (i + 2) ].value = If;
    wordSymbols[ (i + 2) ].spelling = new Host.Word ( "IF          ");
    wordSymbols[ (i + 3) ].value = Of;
    wordSymbols[ (i + 3) ].spelling = new Host.Word ( "OF          ");
    wordSymbols[ (i + 4) ].value = Or;
    wordSymbols[ (i + 4) ].spelling = new Host.Word ( "OR          ");
    wordSymbols[ (i + 5) ].value = To;
    wordSymbols[ (i + 5) ].spelling = new Host.Word ( "TO          ");
    i = lastOfLength[ 2 ];
    wordSymbols[ i ].value = Identifier;
    wordSymbols[ i ].spelling = Host.blankWord;
    wordSymbols[ (i + 1) ].value = And;
    wordSymbols[ (i + 1) ].spelling = new Host.Word ( "AND         ");
    wordSymbols[ (i + 2) ].value = Div;
    wordSymbols[ (i + 2) ].spelling = new Host.Word ( "DIV         ");
    wordSymbols[ (i + 3) ].value = End;
    wordSymbols[ (i + 3) ].spelling = new Host.Word ( "END         ");
    wordSymbols[ (i + 4) ].value = For;
    wordSymbols[ (i + 4) ].spelling = new Host.Word ( "FOR         ");
    wordSymbols[ (i + 5) ].value = Not;
    wordSymbols[ (i + 5) ].spelling = new Host.Word ( "NOT         ");
    wordSymbols[ (i + 6) ].value = Var;
    wordSymbols[ (i + 6) ].spelling = new Host.Word ( "VAR         ");
    i = lastOfLength[ 3 ];
    wordSymbols[ i ].value = Identifier;
    wordSymbols[ i ].spelling = Host.blankWord;
    wordSymbols[ (i + 1) ].value = Case;
    wordSymbols[ (i + 1) ].spelling = new Host.Word ( "CASE        ");
    wordSymbols[ (i + 2) ].value = Else;
    wordSymbols[ (i + 2) ].spelling = new Host.Word ( "ELSE        ");
    wordSymbols[ (i + 3) ].value = Exit;
    wordSymbols[ (i + 3) ].spelling = new Host.Word ( "EXIT        ");
    wordSymbols[ (i + 4) ].value = Loop;
    wordSymbols[ (i + 4) ].spelling = new Host.Word ( "LOOP        ");
    wordSymbols[ (i + 5) ].value = Read;
    wordSymbols[ (i + 5) ].spelling = new Host.Word ( "READ        ");
    wordSymbols[ (i + 6) ].value = Then;
    wordSymbols[ (i + 6) ].spelling = new Host.Word ( "THEN        ");
    i = lastOfLength[ 4 ];
    wordSymbols[ i ].value = Identifier;
    wordSymbols[ i ].spelling = Host.blankWord;
    wordSymbols[ (i + 1) ].value = Array;
    wordSymbols[ (i + 1) ].spelling = new Host.Word ( "ARRAY       ");
    wordSymbols[ (i + 2) ].value = Begin;
    wordSymbols[ (i + 2) ].spelling = new Host.Word ( "BEGIN       ");
    wordSymbols[ (i + 3) ].value = Write;
    wordSymbols[ (i + 3) ].spelling = new Host.Word ( "WRITE       ");
	wordSymbols[ (i + 4) ].value = While;
    wordSymbols[ (i + 4) ].spelling = new Host.Word ( "WHILE       ");
    i = lastOfLength[ 5 ];
    wordSymbols[ i ].value = Identifier;
    wordSymbols[ i ].spelling = Host.blankWord;
    wordSymbols[ (i + 1) ].value = Module;
    wordSymbols[ (i + 1) ].spelling = new Host.Word ( "MODULE      ");
    i = lastOfLength[ 6 ];
    wordSymbols[ i ].value = Identifier;
    wordSymbols[ i ].spelling = Host.blankWord;
	i = lastOfLength[ 7 ];
    wordSymbols[ i ].value = Identifier;
    wordSymbols[ i ].spelling = Host.blankWord;
    i = lastOfLength[ 8 ];
    wordSymbols[ i ].value = Identifier;
    wordSymbols[ i ].spelling = Host.blankWord;
    wordSymbols[ (i + 1) ].value = Procedure;
    wordSymbols[ (i + 1) ].spelling = new Host.Word ( "PROCEDURE   ");
    i = lastOfLength[ 9 ];
    wordSymbols[ i ].value = Identifier;
    wordSymbols[ i ].spelling = Host.blankWord;
    i = lastOfLength[ 10 ];
    wordSymbols[ i ].value = Identifier;
    wordSymbols[ i ].spelling = Host.blankWord;
    i = lastOfLength[ 11 ];
    wordSymbols[ i ].value = Identifier;
    wordSymbols[ i ].spelling = Host.blankWord;
    i = lastOfLength[ 12 ];
    wordSymbols[ i ].value = Identifier;
    wordSymbols[ i ].spelling = Host.blankWord;

    }

  }


