/* Generator.java: code generator */  


/* The Generator provides a program generation interface for the syntactic/semantic */
/* analyzer as a set of method calls.  These calls and the types underlying         */
/* their parameter lists provide a generation interface which is independent of the */
/* precise object code to be generated.  Between calls the analyzer stores and      */
/* transmits data of these types but without any necessary knowledge of their       */
/* internal nature.                                                                 */
/*                                                                                  */
/* (a) REPRESENTATION AND STORAGE OF DATA                                           */
/*     The representation and storage of data within the object program is          */
/*     described by the Generator as follows:                                       */
/*     (1) For each type the Generator creates a representation of                  */
/*            class Representation                                                  */
/*         which describes how such data are to be represented in the object        */
/*         program.                                                                 */
/*     (2) For each variable the Generator creates an address of                    */
/*            class RunTimeAddress                                                  */
/*         which holds the necessary address coordinates for the run- time access   */
/*         of those data.                                                           */
/*     These descriptors are generated as follows:                                  */
/*     (3) Representations for the built-in types are made available as accessible  */
/*         values                                                                   */
/*            TypeRepresentation    booleanRepresentation, charRepresentation,      */
/*                                  integerRepresentation;                          */
/*            public static TypeRepresentation arrayRepresentation(...)             */
/*         generates a representation for each program-defined type.                */
/*     (4)    public static RunTimeAddress addressFor (...)                         */
/*         determines the run-time address coordinates for a variable.  Run-time    */
/*         addresses are assumed to lie within storage frames, one frame            */
/*         for each active procedure instance, and so calls of                      */
/*            public static void openFrame()                                        */
/*            public static void closeFrame()                                       */
/*         are used to delimit the static nesting of frames for the address         */
/*         allocation.                                                              */
/*                                                                                  */
/* (b) PROCEDURE AND PROGRAM CONTROL                                                */
/*     The necessary compile- and run-time housekeeping operations associated with  */
/*     the object program are realized as follows:                                  */
/*     (1) A linkage record of                                                      */
/*            class ProcedureLinkage                                                */
/*         is generated for each procedure by a call of                             */
/*            ProcedureLinkage newLinkage(...)                                      */
/*     (2) Transfer of control to a procedure is realized by a call of              */
/*            void callProcedure(...)                                               */
/*         with the appropriate linkage object supplied as an actual-parameter.     */
/*     (3) The necessary prelude and postlude code for each procedure or program    */
/*         block is realized by means of                                            */
/*            void enterBody()                                                      */
/*            void leaveBody()                                                      */
/*            void enterProgram()                                                   */
/*            void leaveProgram()                                                   */
/*                                                                                  */
/* (c) VARIABLES, EXPRESSIONS AND ASSIGNMENT                                        */
/*     The code generation interface for variable access, expression evaluation and */
/*     assignment assumes a postfix code form (though the generating procedures     */
/*     called may transform this code thereafter).                                  */
/*     The generating calls represent operations on a hypothetical run-time stack   */
/*     of operand references and values, as follows:                                */
/*     (1) Variable access is realized by the following hypothetical operations:    */
/*            void stackReference(...)                                              */
/*            void indexedReference                                                 */
/*     (2) Expression evaluation is realized by the following additional stack      */
/*         operations:                                                              */
/*            void dereference(...)                                                 */
/*            void stackConstant(...)                                               */
/*            void negateInteger(...)                                               */
/*            void binaryIntegerOperation(...)                                      */
/*            void comparison(...)                                                  */
/*            void negateBoolean(...)                                               */
/*            void binaryBooleanOperation(...)                                      */
/*         The operation binaryBooleanOperation is defined and used in a way which  */
/*         permits either infix or postfix evaluation of and/or operations.         */
/*     (3) Assignment is realized by the single hypothetical stack operation        */
/*            void assign()                                                         */
/*                                                                                  */
/* (d) INPUT-OUTPUT OPERATORS                                                       */
/*     The input and output operations are realized by the following generative     */
/*     operations:                                                                  */
/*            void readOperation(...)                                               */
/*            void writeOperation(...)                                              */
/*                                                                                  */
/* (e) CONTROL STATEMENTS AND SEQUENTIAL CODE GENERATION                            */
/*     The code generated, whatever its form, is assumed to be for sequential       */
/*     execution.  Each code sequence which can be entered other than sequentially  */
/*     is represented at compile-time by a value of                                 */
/*           class CodeLabel                                                        */
/*     These values are bound to points in the object code by operations            */
/*           void bindCodeLabel(...)                                                */
/*                   - for a previously unreferenced label                          */
/*           void futureCodeLabel(...)                                              */
/*                   - for a label which may be referenced  before it is generated  */
/*           void expectedCodeLabel(...)                                            */
/*                   - for a label previously "expected"                            */
/*     All references (jumps, etc.) are generated by the control generating         */
/*     procedures manipulating these label descriptors.  Control statement code is  */
/*     realized by the following hypothetical operations:                           */
/*           void jumpOnFalse(...)                                                  */
/*           void jump(...)                                                         */
/*                                                                                  */
/* (f) CASE STATEMENTS AND FOR STATEMENTS                                           */
/*     Following evaluation of the case selector in a case statement                */
/*           void openCase(...)                                                     */
/*     is called.  Each label in case limb is signalled by a call of                */
/*           void nextIsCase(...)                                                   */
/*     and the final case limb is followed by a call of                             */
/*           void closeCase(...)                                                    */
/*     The object code of the statement sequence controlled by a for-statement must */
/*     be preceded by a call of                                                     */
/*           void openFor(...)                                                      */
/*     and followed by a call of                                                    */
/*           void closeFor(...)                                                     */
/*                                                                                  */
/*     The Analyser may suppress further code generation at any point by a call     */
/*     of                                                                           */
/*           void noFurtherCode()                                                   */
/*     The Generator ignores all subsequent calls to its operations. This is        */
/*     necessary if analysis of (any part of) an incorrect program causes           */
/*     inconsistent sequences of interface calls.                                   */
/*                                                                                  */
/* The generator reports or violations of implementation restrictions with the      */
/* following codes:                                                                 */
/*     91 ... block too long                                                        */
/*     92 ... too much non-local recursion                                          */
/*     93 ... arithmetic overflow at compile-time                                   */
/*     94 ... division by zero                                                      */
/*     95 ... array index out of range                                              */



interface EntryKind {
    public static final byte
            Reference = 0,  Constant = 1, Result = 2, Operation = 3, Address = 4;
}

interface OperatorKind {
    public static final byte
            Unary = 0,  Binary = 1, ReadOp = 2;
}

interface IOMode {
    public static final byte
            CharMode = 0, IntegerMode = 1;
}





public class Generator
        implements SymbolType, EntryKind, OperatorKind, IOMode, OrderCode, Register {
    
    private static boolean suppressCodeGeneration;
    
    public static void noFurtherCode() {
        suppressCodeGeneration = true;
    }
    
    
    private static void generatorError(short code) {
        SourceHandler.error( code, SourceHandler.positionNow );
    }
    
    
    
    /*************************************************************************************/
    /*                         DATA REPRESENTATION AND STORAGE                           */
    /*************************************************************************************/
    
    public static class RunTimeAddress {
        public short textualLevel;
        public short relativeAddress;
        
        public void copy( RunTimeAddress original ) {
            this.textualLevel = original.textualLevel;
            this.relativeAddress = original.relativeAddress;
        }
    }
    
    public static class TypeRepresentation {
        public short words;
    }
    
    
    public static TypeRepresentation booleanRepresentation  = new TypeRepresentation();
    public static TypeRepresentation charRepresentation     = new TypeRepresentation();
    public static TypeRepresentation integerRepresentation  = new TypeRepresentation();
    
    
    private static void setScalarRepresentations() {
        integerRepresentation.words = (short)1;
        booleanRepresentation.words = (short)1;
        charRepresentation.words    = (short)1;
    }
    
    
    public static TypeRepresentation arrayRepresentation( short boundMin, short boundMax,
            TypeRepresentation elementRepresentation ) {
        TypeRepresentation representation = new TypeRepresentation();
        
        if (!suppressCodeGeneration)
            representation.words = (short)((boundMax - boundMin + 1) * elementRepresentation.words);
        return representation;
    }
    
    
    private static final byte pseudoLevel = 0;
    private static final byte globalLevel = 1;
    
    private static final short firstLocal = 3; /* stack Frame Offsets */
    
    private static class FrameEntry {
        public short nextLocal;
        public FrameEntry nextFrame;
    }
    
    
    private static FrameEntry localFrame;
    
    private static short frameLevel;
    
    private static void initialiseFrames() {
        localFrame = null;
        frameLevel = pseudoLevel;
    }
    
    
    public static void openFrame() {
        FrameEntry newFrame;
        
        if (!suppressCodeGeneration) {
            frameLevel += (short)(1);
            newFrame = new FrameEntry();
            newFrame.nextLocal = firstLocal;
            newFrame.nextFrame = localFrame;
            localFrame = newFrame;
        }
    }
    
    
    public static RunTimeAddress addressFor(TypeRepresentation representation) {
        RunTimeAddress address = new RunTimeAddress();
        
        if (!suppressCodeGeneration) {
            address.textualLevel = frameLevel;
            address.relativeAddress = localFrame.nextLocal;
            localFrame.nextLocal += representation.words;
        }
        return address;
    }
    
    
    public static void closeFrame() {
        
        FrameEntry oldFrame;
        
        if (!suppressCodeGeneration) {
            oldFrame = localFrame;
            localFrame = localFrame.nextFrame;
            oldFrame = null;
            frameLevel -= 1;
        }
    }
    
    
    
    /*************************************************************************************/
    /*                         INSTRUCTION ASSEMBLY & FILING                             */
    /*************************************************************************************/
    
    private static class Code {
        /* Sequentially allocates object program locations from FirstAvailable onwards.    */
        /* Assembles and files Target machine instructions via the procedures Ins and      */
        /* JumpIns.  Labelled points in the code may be represented by variables           */
        /* of type CodeLabel, which are bound to the code itself by procedures NewLabel,   */
        /* FutureLabel, and ExpectedLabel.                                                 */
        /* At run-time the first instruction of the program is a jump to the start of the  */
        /* main program code.  Word 3 contains the address of base of the run-time stack.  */
        
        public static final int CodeMax = 1000;
        
        static short currentAddress;
        static Target.Instruction[ ] theCode = new Target.Instruction[CodeMax];
        static short nextInstruction;
        static boolean noCodeOverflow;
        
        
        static //initialisation
        {
            currentAddress = Target.FirstAvailable;
            nextInstruction = 1;
            noCodeOverflow = true;
        }
        
        public static void newCodeSpace() {
            nextInstruction = 1;
            noCodeOverflow = true;
        }
        
        public static void endOfCodeSpace() {
            short nextLocation;
            short i;
            
            nextLocation = (short)(currentAddress - (2 * (nextInstruction - 1)));
            for (i = 1; ( i <= (nextInstruction - 1) ); i += 1) {
                CodeHandler.locateInstruction( nextLocation, theCode[ i-1 ] );
                nextLocation += 2;
            }
        }
        
        public static void copyCode(Target.Instruction codeValue) {
            if ( nextInstruction > CodeMax ) {
                if (noCodeOverflow) {
                    generatorError( (short)91 );
                    noCodeOverflow = false;
                }
                nextInstruction = 1;
            }
            theCode[ nextInstruction - 1 ] = codeValue ;
            nextInstruction += 1;
            currentAddress += 2;
        }
        
        public static void ins(byte op, short d, byte r, byte l) {
            Target.Instruction newInstruction = new Target.Instruction();
            
            newInstruction.opCode = op;
            newInstruction.n = d;
            newInstruction.r = r;
            newInstruction.l = l;
            copyCode( newInstruction );
        }
        
        public static void ins0(byte op ) {
            Target.Instruction newInstruction = new Target.Instruction();
            
            newInstruction.opCode = op;
            newInstruction.n = 0;
            newInstruction.r = 0;
            newInstruction.l = 0;
            copyCode( newInstruction );
        }
        
        public static void insD(byte op, short d) {
            Target.Instruction newInstruction = new Target.Instruction();
            
            newInstruction.opCode = op;
            newInstruction.n = d;
            newInstruction.r = 0;
            newInstruction.l = 0;
            copyCode( newInstruction );
        }
        
        public static short reserveInstruction() {
            short codeAddress;
            
            codeAddress = nextInstruction;
            ins0( NOOP );
            return codeAddress;
        }
        
        public static void fixUp( short fixUpAddress, byte op, short d, byte reg, byte lev) {
            theCode[ fixUpAddress - 1 ].opCode = op;
            theCode[ fixUpAddress - 1 ].n = d;
            theCode[ fixUpAddress - 1 ].r = reg;
            theCode[ fixUpAddress - 1 ].l = lev;
        }
        
        
        public static void jumpIns( byte jumpType, CodeLabel sequence ) {
            short destination;
            
            if (sequence.expected) {
                destination = sequence.lastCodeReference;
                sequence.lastCodeReference = nextInstruction;
            } else
                destination = sequence.startAddress;
            ins( jumpType, destination, BP, (byte)0 );
        }
        
        public static void newLabel(CodeLabel sequence) {
            sequence.expected = false;
            sequence.startAddress = currentAddress;
        }
        
        public static void futureLabel( CodeLabel sequence ) {
            sequence.expected = true;
            sequence.lastCodeReference = 0;
        }
        
        public static void expectedLabel(CodeLabel sequence) {
            short thisfixUp;
            short nextfixUp;
            
            nextfixUp = sequence.lastCodeReference;
            while ( nextfixUp != 0 ) {
                thisfixUp = nextfixUp;
                nextfixUp = theCode[ thisfixUp - 1 ].n;
                theCode[ thisfixUp - 1 ].n = currentAddress;
            }
            sequence.expected = false;
            sequence.startAddress = currentAddress;
        }
        
        public static void systemCall(byte routineNeeded)
        /* Generates call to specified system routine */
        {
            ins( CALL, Target.addressOf( routineNeeded ), BP, (byte)0 );
        }
        
        public static void enterHere()
        /* Sets third instruction of object program to jump to */
        /* the start of the main program.                      */
        {
            Target.Instruction mainProgramJumpInstruction = new Target.Instruction();
            
            mainProgramJumpInstruction.opCode = BRN;
            mainProgramJumpInstruction.n = currentAddress;
            mainProgramJumpInstruction.r = BP;
            mainProgramJumpInstruction.l = 0;
            CodeHandler.locateInstruction( (short)4, mainProgramJumpInstruction );
        }
        
        public static void generationComplete()
        /* Sets first and second instructions of the object   */
        /* program to set PSR and to set stack base address.  */
        {
            Target.Instruction thisInstruction = new Target.Instruction();
            
            thisInstruction.opCode = SETPSR;
            thisInstruction.n = 0;
            thisInstruction.r = BP;
            thisInstruction.l = 0;
            CodeHandler.locateInstruction( (short)0, thisInstruction );
            thisInstruction = new Target.Instruction(); //addition
            thisInstruction.opCode = SETSP;
            thisInstruction.n = currentAddress;
            thisInstruction.r = BP;
            thisInstruction.l = 0;
            CodeHandler.locateInstruction( (short)2, thisInstruction );
        }
        
    } /* Code */
    
    
    
    /*************************************************************************************/
    /*                    PROCEDURE, PROGRAM AND STORAGE HOUSEKEEPING                    */
    /*************************************************************************************/
    
    public static class ProcedureLinkage {
        public short textualLevel;
        public CodeLabel codeBody;
        public short entryPoint;
    }
    
    public static ProcedureLinkage newLinkage() {
        ProcedureLinkage linkage = null;
        if (!suppressCodeGeneration) {
            linkage = new ProcedureLinkage();
            linkage.textualLevel = frameLevel;
            linkage.codeBody = new CodeLabel();
            Code.futureLabel( linkage.codeBody );
        }
        return (linkage);
    }
    
    
    public static void callProcedure(ProcedureLinkage linkage) {
        if (!suppressCodeGeneration) {
            Code.insD( MARK, (short)3 );
            Code.ins( LOADA, (short)0, FP, (byte)(frameLevel - linkage.textualLevel + 1) );
            Code.jumpIns( CALL, linkage.codeBody );
        }
    }
    
    
    public static void enterBody(ProcedureLinkage linkage) {
        if (!suppressCodeGeneration) {
            Code.newCodeSpace();
            Code.expectedLabel( linkage.codeBody );
            Code.ins( STORE, (short)0, FP, (byte)0 );
            linkage.entryPoint = Code.reserveInstruction();
        }
    }
    
    
    public static void leaveBody(ProcedureLinkage linkage) {
        if (!suppressCodeGeneration) {
            Code.fixUp( linkage.entryPoint, INCREG, (short)(localFrame.nextLocal - firstLocal), SP, (byte)0 );
            Code.ins0( EXT );
            Code.endOfCodeSpace();
        }
    }
    
    private static short mainProgramfixUp;
    
    public static void enterProgram() {
        if (!suppressCodeGeneration) {
            Code.newCodeSpace();
            Code.enterHere();
            Code.insD( MARK, (short)3 );
            mainProgramfixUp = Code.reserveInstruction();
            Code.systemCall( Target.InitialiseIO );
        }
    }
    
    
    public static void leaveProgram() {
        if (!suppressCodeGeneration) {
            Code.fixUp( mainProgramfixUp, INCREG, (short)(localFrame.nextLocal - firstLocal), SP, (byte)0 );
            Code.systemCall( Target.FinaliseIO );
            Code.ins0( HLT );
            Code.endOfCodeSpace();
            Code.generationComplete();
        }
    }
    
    
    /*************************************************************************************/
    /*                          STACK OPERAND DESCRIPTION                                */
    /*************************************************************************************/
    
    private static class StackEntry {
        private StackEntry nextEntry;
        public TypeRepresentation rep;
        public byte kind;
        
        public StackEntry() {
            nextEntry = null;
        }
        
        public static void freeNode(StackEntry oldNode ) {
            oldNode.nextEntry = null;
        }
        
    } /* StackEntry */
    
    
    private static class ReferenceEntry extends StackEntry {
        public RunTimeAddress refAddress;
        public boolean indexed;
        
        public ReferenceEntry() {
            super();
            this.kind = Reference;
            this.refAddress = new RunTimeAddress();
            this.indexed = false;
        }
    } /* ReferenceEntry */
    
    private static class IndexedReferenceEntry extends ReferenceEntry {
        public StackEntry index;
        public short indexMin;
        public short indexMax;
        
        public IndexedReferenceEntry(ReferenceEntry theReference) {
            super();
            this.refAddress = theReference.refAddress;
            this.indexed = true;
        }
    } /* IndexedReferenceEntry */
    
    private static class ConstEntry extends StackEntry {
        public short value;
        
        public ConstEntry() {
            super();
            this.kind = Constant;
        }
    } /* ConstEntry */
    
    private static class OperationEntry extends StackEntry {
        public byte opKind;
        
        public OperationEntry() {
            super();
            this.kind = Operation;
        }
    } /* OperationEntry */
    
    private static class UnaryOperationEntry extends OperationEntry {
        public short unaryOp;
        public StackEntry unaryEntry;
        
        public UnaryOperationEntry() {
            super();
            this.opKind = Unary;
        }
    } /* UnaryOperationEntry */
    
    
    
    public static class BinaryOperationEntry extends OperationEntry {
        public short binaryOp;
        public StackEntry leftEntry;
        public StackEntry rightEntry;
        
        public BinaryOperationEntry() {
            super();
            this.opKind = Binary;
        }
    } /* BinaryOperationEntry */
    
    
    public static class ReadOperationEntry extends OperationEntry {
        public byte mode;
        
        public ReadOperationEntry() {
            super();
            this.opKind = ReadOp;
        }
    } /* ReadOperationEntry */
    
    
    private static class ResultEntry extends StackEntry {
        /* No additional fields */
        
        public ResultEntry(StackEntry loadedEntry) {
            super();
            this.kind = Result;
            this.rep = loadedEntry.rep;
        }
    } /* ResultEntry */
    
    
    private static class AddressEntry extends StackEntry {
        /* No additional fields */
        
        public AddressEntry(StackEntry loadedEntry) {
            super();
            this.kind = Address;
            this.rep = loadedEntry.rep;
        }
    } /* AddressEntry */
    
    
    
    private static class SimulatedStack {
        private StackEntry top;
        
        SimulatedStack() {
            top = null;
        }
        
        public void push(StackEntry entry) {
            entry.nextEntry = top;
            top = entry;
        }
        
        public StackEntry pop() {
            StackEntry entry;
            
            entry = top;
            top = top.nextEntry;
            return entry;
        }
        
    } /* SimulatedStack */
    
    private static SimulatedStack stack = new SimulatedStack();
    
    
    /*************************************************************************************/
    /*                              EXPRESSION EVALUATION                                */
    /*************************************************************************************/
    
    public static void stackReference(RunTimeAddress location) {
        ReferenceEntry newEntry;
        
        if (!suppressCodeGeneration) {
            newEntry = new ReferenceEntry();
            newEntry.refAddress.copy(location) ;
            stack.push( newEntry );
        }
    }
    
    
    public static void indexedReference(short boundMin, short boundMax,
            TypeRepresentation elementRepresentation ) {
        ReferenceEntry variableEntry;
        StackEntry indexEntry;
        if (!suppressCodeGeneration) {
            indexEntry = stack.pop();
            variableEntry = (ReferenceEntry)stack.pop();
            if ( indexEntry.kind == Constant ) {
                short constValue = ((ConstEntry)indexEntry).value;
                if (   (constValue < boundMin)
                | (constValue > boundMax)   ) {
                    generatorError( (short)95 );
                    constValue = boundMin;
                }
                variableEntry.refAddress.relativeAddress
                        += ((constValue - boundMin) * elementRepresentation.words);
                variableEntry.rep = elementRepresentation;
                stack.push( variableEntry );
                StackEntry.freeNode(indexEntry);
            } else {
                IndexedReferenceEntry arrayVariableEntry = new IndexedReferenceEntry(variableEntry);
                /* adjust starting address of array as if lower bound = 0 */
                arrayVariableEntry.refAddress.relativeAddress
                        -= ((boundMin * elementRepresentation.words));
                arrayVariableEntry.indexed = true;
                arrayVariableEntry.index = indexEntry;
                arrayVariableEntry.indexMin = boundMin;
                arrayVariableEntry.indexMax = boundMax;
                arrayVariableEntry.rep = elementRepresentation;
                stack.push( arrayVariableEntry );
                StackEntry.freeNode(variableEntry);
            }
        }
    }
    
    
    public static void deReference(TypeRepresentation representation) {
        StackEntry topEntry;
        
        if (!suppressCodeGeneration) {
            topEntry = stack.pop();
            topEntry.rep = representation;
            stack.push(topEntry);
        }
    }
    
    
    public static void stackConstant(short constantValue, TypeRepresentation constantRepresentation) {
        
        ConstEntry constantEntry;
        
        if (!suppressCodeGeneration) {
            constantEntry = new ConstEntry();
            constantEntry.rep = constantRepresentation;
            constantEntry.value = constantValue;
            stack.push( constantEntry );
        }
    }
    
    
    public static void negateInteger() {
        StackEntry integerEntry;
        UnaryOperationEntry resultEntry;
        
        if (!suppressCodeGeneration) {
            integerEntry = stack.pop();
            if ( integerEntry.kind == Constant ) {
                ((ConstEntry)integerEntry).value = (short)(-((ConstEntry)integerEntry).value);
                stack.push( integerEntry );
            } else {
                resultEntry = new UnaryOperationEntry();
                resultEntry.rep = integerRepresentation;
                resultEntry.unaryOp = LexicalAnalyser.Minus;
                resultEntry.unaryEntry = integerEntry;
                stack.push( resultEntry );
            }
        }
        
    }
    
    
    private static short doArithmetic(byte operator, short left, short right) {
        short Result = 0;
        boolean overflow;
        
        overflow = false;
        switch (operator) {
            case Plus:
            case Minus:
            {
                if ( operator == Minus )
                    right = (short)(-right);
                if (( left > 0 ) && ( right > 0 ))
                    overflow = ( left > (32767 - right) );
                else if (( left < 0 ) && ( right < 0 ))
                    overflow = ( left < ((-32768) - right) );
                if (!overflow)
                    Result = (short)(left + right);
                break;
            }
            case Times:
            {
                if ( right == 0 )
                    Result = (short)0;
                else if ( (short)Math.abs(left) > (32767 / (short)Math.abs(right)) )
                    overflow = true;
                else
                    Result = (short)(left * right);
                break;
            }
            case Div:
            {
                if ( right == 0 ) {
                    generatorError( (short)94 );
                    Result = (short)32767;
                } else
                    Result = (short)(left / right);
                break;
            }
        }
        if (overflow) {
            generatorError( (short)93 );
            Result = (short)32767;
        }
        return Result;
    }
    
    
    public static void binaryIntegerOperation(byte operator) {
        
        StackEntry leftOperand;
        StackEntry rightOperand;
        BinaryOperationEntry resultEntry;
        short resultValue = (short)0;
        
        if (!suppressCodeGeneration) {
            rightOperand = stack.pop();
            leftOperand = stack.pop();
            if (( leftOperand.kind == Constant ) && ( rightOperand.kind == Constant )) {
                resultValue = doArithmetic( operator,
                        ((ConstEntry)leftOperand).value,
                        ((ConstEntry)rightOperand).value );
                stackConstant( resultValue, integerRepresentation );
                StackEntry.freeNode(leftOperand);
                StackEntry.freeNode(rightOperand);
            } else {
                resultEntry = new BinaryOperationEntry();
                resultEntry.rep =  integerRepresentation ;
                resultEntry.binaryOp = operator;
                resultEntry.leftEntry = leftOperand;
                resultEntry.rightEntry = rightOperand;
                stack.push( resultEntry );
            }
        }
        
    }
    
    
    public static void comparison(byte operator) {
        StackEntry leftOperand;
        StackEntry rightOperand;
        BinaryOperationEntry resultEntry;
        boolean resultValue;
        
        if (!suppressCodeGeneration) {
            rightOperand = stack.pop();
            leftOperand = stack.pop();
            if (( leftOperand.kind == Constant ) && ( rightOperand.kind == Constant )) {
                switch (operator) {
                    case LessThan:
                    {
                        resultValue = ( ((ConstEntry)leftOperand).value < ((ConstEntry)rightOperand).value );
                        break;
                    }
                    case LessThanOrEqual:
                    {
                        resultValue = ( ((ConstEntry)leftOperand).value <= ((ConstEntry)rightOperand).value );
                        break;
                    }
                    case GreaterThanOrEqual:
                    {
                        resultValue = ( ((ConstEntry)leftOperand).value >= ((ConstEntry)rightOperand).value );
                        break;
                    }
                    case GreaterThan:
                    {
                        resultValue = ( ((ConstEntry)leftOperand).value > ((ConstEntry)rightOperand).value );
                        break;
                    }
                    case NotEquals:
                    {
                        resultValue = ( ((ConstEntry)leftOperand).value != ((ConstEntry)rightOperand).value );
                        break;
                    }
                    case Equals:
                    {
                        resultValue = ( ((ConstEntry)leftOperand).value == ((ConstEntry)rightOperand).value );
                        break;
                    }
                    default:
                    {
                        resultValue = false;
                    }
                }
                if (resultValue)
                    stackConstant( (short)1, booleanRepresentation );
                else
                    stackConstant( (short)0, booleanRepresentation );
                StackEntry.freeNode(leftOperand);
                StackEntry.freeNode(rightOperand);
            } else {
                resultEntry = new BinaryOperationEntry();
                resultEntry.rep = booleanRepresentation;
                if (( operator == LexicalAnalyser.GreaterThan ) || ( operator == LexicalAnalyser.GreaterThanOrEqual )) {
                    if ( operator == LexicalAnalyser.GreaterThan )
                        resultEntry.binaryOp = LexicalAnalyser.LessThan;
                    else
                        resultEntry.binaryOp = LexicalAnalyser.LessThanOrEqual;
                    resultEntry.leftEntry = rightOperand;
                    resultEntry.rightEntry = leftOperand;
                } else {
                    resultEntry.binaryOp = operator;
                    resultEntry.leftEntry = leftOperand;
                    resultEntry.rightEntry = rightOperand;
                }
                stack.push( resultEntry );
            }
        }
        
    }
    
    
    public static void negateBoolean() {
        
        StackEntry booleanEntry;
        UnaryOperationEntry resultEntry;
        
        if (!suppressCodeGeneration) {
            booleanEntry = stack.pop();
            if ( booleanEntry.kind == Constant ) {
                ((ConstEntry)booleanEntry).value = (short)Math.abs((((ConstEntry)booleanEntry).value - 1));
                stack.push( booleanEntry );
            } else {
                resultEntry = new UnaryOperationEntry();
                resultEntry.rep = booleanRepresentation;
                resultEntry.unaryOp = LexicalAnalyser.Not;
                resultEntry.unaryEntry = booleanEntry;
                stack.push( resultEntry );
            }
        }
        
    }
    
    
    public static void binaryBooleanOperation(byte operator) {
        
        StackEntry leftOperand;
        StackEntry rightOperand;
        BinaryOperationEntry resultEntry;
        short resultValue;
        
        if (!suppressCodeGeneration) {
            rightOperand = stack.pop();
            leftOperand = stack.pop();
            if (( leftOperand.kind == Constant ) && ( rightOperand.kind == Constant )) {
                switch (operator) {
                    case And:
                    {
                        resultValue = (short)(((ConstEntry)leftOperand).value * ((ConstEntry)rightOperand).value);
                        break;
                    }
                    case Or:
                    {
                        if ( (short)(((ConstEntry)leftOperand).value + ((ConstEntry)rightOperand).value) > 0 )
                            resultValue = (short)1;
                        else
                            resultValue = (short)0;
                        break;
                    }
                    default:
                        resultValue = (short)0;
                }
                stackConstant( resultValue, booleanRepresentation );
                StackEntry.freeNode(leftOperand);
                StackEntry.freeNode(rightOperand);
            } else {
                resultEntry = new BinaryOperationEntry();
                resultEntry.rep = booleanRepresentation ;
                resultEntry.binaryOp = operator;
                resultEntry.leftEntry = leftOperand;
                resultEntry.rightEntry = rightOperand;
                stack.push( resultEntry );
            }
        }
        
    }
    
    /*************************************************************************************/
    /*                             DATA ACCESS CODE GENERATION                           */
    /*************************************************************************************/
    
    private static byte[ ] binaryopCode = new byte[46];
    
    private static void initialiseBinaryopCodes() {
        
        binaryopCode[ Not ]                 = NOOP;
        binaryopCode[ And ]                 = LAND;
        binaryopCode[ Or ]                  = LOR;
        binaryopCode[ Div ]                 = DVD;
        binaryopCode[ Times ]               = MUL;
        binaryopCode[ Plus ]                = ADD;
        binaryopCode[ Minus ]               = SUB;
        binaryopCode[ LessThan ]            = CLT;
        binaryopCode[ LessThanOrEqual ]     = CLE;
        binaryopCode[ GreaterThanOrEqual ]  = NOOP;
        binaryopCode[ GreaterThan ]         = NOOP;
        binaryopCode[ NotEquals ]           = CNE;
        binaryopCode[ Equals ]              = CEQ;
        
    }
    
    
    private static void accessWord(RunTimeAddress wordAddress, byte accessopCode) {
        Code.ins( accessopCode, wordAddress.relativeAddress, FP, (byte)((frameLevel) - (wordAddress.textualLevel)) );
    }
    
    
    private static void loadAddress(StackEntry entry) {
        if (entry.kind == Reference) {
            accessWord( ((ReferenceEntry)entry).refAddress, LOADA );
            if (((ReferenceEntry)entry).indexed) {
                load( ((IndexedReferenceEntry)entry).index );
                if ( ((ReferenceEntry)entry).rep.words > 1 ) {
                    Code.insD( LOADL, ((ReferenceEntry)entry).rep.words );
                    Code.ins0( MUL );
                }
                Code.ins0( ADD );
                StackEntry.freeNode(((IndexedReferenceEntry)entry).index);
            }
            entry.kind = Address;
        } else
            /* will not occur */;
    }
    
    
    private static void doUnaryOperation(UnaryOperationEntry entry) {
        
        byte opCode;
        
        load( entry.unaryEntry );
        if ( entry.unaryOp == LexicalAnalyser.Minus )
            opCode = NEG;
        else
            opCode = INV;
        Code.ins0( opCode );
        StackEntry.freeNode(entry.unaryEntry);
        
    }
    
    
    private static void doReadOperation(ReadOperationEntry entry) {
        switch (entry.mode) {
            case IntegerMode:
            {
                Code.systemCall( Target.ReadInteger );
                break;
            }
            case CharMode:
            {
                Code.ins0( CHIN );
                break;
            }
        }
        
    }
    
    
    private static void doBinaryOperation(BinaryOperationEntry entry) {
        
        boolean folded;
        
        folded = false;
        if ( entry.rightEntry.kind == Constant ) {
            ConstEntry rightConstEntry = (ConstEntry)entry.rightEntry;
            switch (entry.binaryOp) {
                case Plus:
                case Minus:
                {
                    load( entry.leftEntry );
                    if ( rightConstEntry.value != 0 ) {
                        if ( entry.binaryOp == LexicalAnalyser.Plus )
                            Code.insD( INCR, rightConstEntry.value );
                        else
                            Code.insD( INCR, (short)(-rightConstEntry.value) );
                    }
                    folded = true;
                    break;
                }
                case Times:
                case And:
                {
                    if ( rightConstEntry.value == 0 ) {
                        Code.insD( LOADL,(short)0 );
                        folded = true;
                    } else if ( rightConstEntry.value == 1 ) {
                        load( entry.leftEntry );
                        folded = true;
                    }
                    break;
                }
                case Div:
                {
                    if ( rightConstEntry.value == 1 ) {
                        load( entry.leftEntry );
                        folded = true;
                    } else if ( rightConstEntry.value == 0 ) {
                        generatorError( (short)94 );
                        Code.insD( LOADL,(short)32767 );
                        folded = true;
                    }
                    break;
                }
                case Or:
                {
                    if ( rightConstEntry.value == 0 ) {
                        load( entry.leftEntry );
                        folded = true;
                    } else if ( rightConstEntry.value == 1 ) {
                        Code.insD( LOADL, (short)1 );
                        folded = true;
                    }
                    break;
                }
                default:
                {
                }
            }
        }
        if ( entry.leftEntry.kind == Constant ) {
            ConstEntry leftConstEntry = (ConstEntry)entry.leftEntry;
            switch (entry.binaryOp) {
                case Plus:
                {
                    load( entry.rightEntry );
                    if ( leftConstEntry.value != 0 ) {
                        Code.insD( INCR, leftConstEntry.value );
                    }
                    folded = true;
                    break;
                }
                case Times:
                case And:
                {
                    if ( leftConstEntry.value == 0 ) {
                        Code.insD( LOADL, (short)0 );
                        folded = true;
                    } else if ( leftConstEntry.value == 1 ) {
                        load( entry.rightEntry );
                        folded = true;
                    }
                    break;
                }
                case Div:
                {
                    if ( leftConstEntry.value == 0 ) {
                        Code.insD( LOADL, (short)0 );
                        folded = true;
                    }
                    break;
                }
                case Or:
                {
                    if ( leftConstEntry.value == 0 ) {
                        load( entry.rightEntry );
                        folded = true;
                    } else if ( leftConstEntry.value == 1 ) {
                        Code.insD( LOADL, (short)1 );
                        folded = true;
                    }
                    break;
                }
                default:
                {
                }
            }
        }
        if (!folded) {
            load( entry.leftEntry );
            load( entry.rightEntry );
            Code.ins0( binaryopCode[ entry.binaryOp ] );
        }
        StackEntry.freeNode(entry.leftEntry);
        StackEntry.freeNode(entry.rightEntry);
        
    }
    
    
    private static void load(StackEntry entry) {
        
        switch (entry.kind) {
            case Reference:
            {
                if (((ReferenceEntry)entry).indexed) {
                    loadAddress( entry );
                    Code.insD( LOADI, (short)1 );
                } else
                    accessWord( ((ReferenceEntry)entry).refAddress, LOAD );
                break;
            }
            case Result:
                break;
            case Constant:
            {
                Code.insD( LOADL, ((ConstEntry)entry).value );
                break;
            }
            case Operation:
            {
                switch (((OperationEntry)entry).opKind) {
                    case Unary:
                    {
                        doUnaryOperation( (UnaryOperationEntry)entry );
                        break;
                    }
                    case Binary:
                    {
                        doBinaryOperation( (BinaryOperationEntry)entry );
                        break;
                    }
                    case ReadOp:
                    {
                        doReadOperation( (ReadOperationEntry)entry );
                        break;
                    }
                }
                break;
            }
        }
        entry.kind = Result;
        
    }
    
    
    public static void assign() {
        
        StackEntry expressionEntry;
        ReferenceEntry variableEntry;
        short size;
        
        if (!suppressCodeGeneration) {
            expressionEntry = stack.pop();
            variableEntry = (ReferenceEntry)stack.pop();
            size = expressionEntry.rep.words;
            if ( size > 1) {
                ReferenceEntry  refExpressionEntry = (ReferenceEntry)expressionEntry;
                loadAddress( refExpressionEntry );
                loadAddress( variableEntry );
                Code.insD( MOVE, size );
            } else if (variableEntry.indexed) {
                load( expressionEntry );
                loadAddress( variableEntry );
                Code.insD( STOREI, (short)1 );
            } else if (     (expressionEntry.kind == Constant )
            &&  ( ((ConstEntry)expressionEntry).value == 0 ))
                accessWord( variableEntry.refAddress, STZ );
            else {
                load( expressionEntry );
                accessWord( variableEntry.refAddress, STORE );
            }
            StackEntry.freeNode(expressionEntry);
            StackEntry.freeNode(variableEntry);
        }
    }
    
    
    /*************************************************************************************/
    /*                            INPUT/OUTPUT OPERATIONS                                */
    /*************************************************************************************/
    
    public static void readOperation(byte readMode) {
        
        ReadOperationEntry valueRead;
        
        if (!suppressCodeGeneration) {
            valueRead = new ReadOperationEntry();
            valueRead.mode = readMode;
            switch (readMode) {
                case 1:
                {
                    valueRead.rep = integerRepresentation ;
                    break;
                }
                case 0:
                {
                    valueRead.rep = charRepresentation ;
                    break;
                }
            }
            stack.push( valueRead );
        }
        
    }
    
    
    public static void writeOperation
            (
            int writeMode
            ) {
        
        StackEntry expressionValue;
        
        if (!suppressCodeGeneration) {
            expressionValue = stack.pop();
            load( expressionValue );
            switch (writeMode) {
                case IntegerMode:
                {
                    Code.systemCall( Target.WriteInteger );
                    break;
                }
                case CharMode:
                {
                    Code.ins0( CHOUT );
                    break;
                }
            }
            StackEntry.freeNode(expressionValue);
        }
        
    }
    
    /*************************************************************************************/
    /*                                  CONTROL STATEMENTS                               */
    /*************************************************************************************/
    
    public static class CodeLabel {
        public boolean expected;
        public short startAddress;
        public short lastCodeReference;
    }
    
    public static void bindCodeLabel(CodeLabel sequence) {
        if (!suppressCodeGeneration)
            Code.newLabel( sequence );
    }
    
    
    public static void futureCodeLabel(CodeLabel sequence) {
        
        if (!suppressCodeGeneration)
            Code.futureLabel( sequence );
    }
    
    
    public static void expectedCodeLabel(CodeLabel sequence) {
        if (!suppressCodeGeneration)
            Code.expectedLabel( sequence );
    }
    
    
    public static void jump(CodeLabel destination) {
        
        if (!suppressCodeGeneration)
            Code.jumpIns( BRN, destination );
    }
    
    
    public static void jumpOnFalse(CodeLabel destination) {
        
        StackEntry booleanEntry;
        
        if (!suppressCodeGeneration) {
            booleanEntry = stack.pop();
            if ( booleanEntry.kind == Constant ) {
                if ( ((ConstEntry)booleanEntry).value == 0 )
                    Code.jumpIns( BRN, destination );
                else
                    /* do nothing */;
            } else {
                load( booleanEntry );
                Code.jumpIns( BZE, destination );
            }
            StackEntry.freeNode(booleanEntry);
        }
        
    }
    
    
    private static class CaseLabelRecord {
        public short LabelValue;
        public CodeLabel limbAddress;
        public CaseLabelRecord next;
        
        public CaseLabelRecord() {
            limbAddress = new CodeLabel();
        }
    }
    
    private static class CaseRecord {
        public StackEntry selector;
        public CodeLabel caseCode; //Jump table
        public short minLabel;
        public short maxLabel;
        public CaseLabelRecord firstLabel;
        public CaseRecord next;
        
        public CaseRecord() {
            caseCode = new CodeLabel();
        }
        
    }
    
    private static CaseRecord topOfCaseStack;
    
    static void initialiseCaseStack() {
        topOfCaseStack = null;
    }
    
    
    public static void openCase() {
        CaseRecord thisCase;
        
        if (!suppressCodeGeneration) {
            thisCase = new CaseRecord();
            thisCase.selector = stack.pop();
            Code.futureLabel( thisCase.caseCode );
            Code.jumpIns( BRN, thisCase.caseCode );
            thisCase.firstLabel = null;
            thisCase.minLabel = (short)32767;
            thisCase.maxLabel = (short)(-32768);
            thisCase.next = topOfCaseStack;
            topOfCaseStack = thisCase;
        }
        
    }
    
    
    public static void nextIsCase(short caseLabel) {
        
        CaseLabelRecord thisLabel;
        CaseLabelRecord previousLabel;
        CaseLabelRecord nextLabel;
        
        if (!suppressCodeGeneration) {
            thisLabel = new CaseLabelRecord();
            thisLabel.LabelValue = caseLabel;
            Code.newLabel( thisLabel.limbAddress );
            thisLabel.next = null;
            previousLabel = null;
            nextLabel = topOfCaseStack.firstLabel;
            while (true) {
                if ( nextLabel == null )
                    break;
                else if ( nextLabel.LabelValue > caseLabel )
                    break;
                else {
                    previousLabel = nextLabel;
                    nextLabel = nextLabel.next;
                }
            }
            if ( previousLabel == null ) {
                thisLabel.next = topOfCaseStack.firstLabel;
                topOfCaseStack.firstLabel = thisLabel;
                topOfCaseStack.minLabel = caseLabel;
                if ( nextLabel == null )
                    topOfCaseStack.maxLabel = caseLabel;
            } else {
                previousLabel.next = thisLabel;
                thisLabel.next = nextLabel;
                if ( nextLabel == null )
                    topOfCaseStack.maxLabel = caseLabel;
            }
        }
        
    }
    
    
    private static void generateJumpTable() {
        
        CaseLabelRecord thisLabel;
        CaseLabelRecord previousLabel;
        short l;
        
        Code.insD( LOADL, topOfCaseStack.minLabel );
        Code.ins0( SUB );
        Code.insD( BIDX, (short)2 );
        thisLabel = topOfCaseStack.firstLabel;
        for (l = topOfCaseStack.minLabel; ( l <= topOfCaseStack.maxLabel ); l += (short)(1)) {
            if ( l == thisLabel.LabelValue ) {
                Code.jumpIns( BRN, thisLabel.limbAddress );
                previousLabel = thisLabel;
                thisLabel = thisLabel.next;
                previousLabel = null;
            } else
                Code.ins0( NOOP );
        }
        
    }
    
    
    public static void closeCase() {
        
        CaseRecord thisCase;
        
        if (!suppressCodeGeneration) {
            Code.expectedLabel( topOfCaseStack.caseCode );
            load( topOfCaseStack.selector );
            generateJumpTable();
            StackEntry.freeNode(topOfCaseStack.selector);
            thisCase = topOfCaseStack;
            topOfCaseStack = topOfCaseStack.next;
            thisCase = null;
        }
    }
    
    
    public static class ForRecord {
        public ReferenceEntry controlVariable;
        public CodeLabel startOfLoop;
        public CodeLabel endOfLoop;
        public ForRecord next;
        
        public ForRecord() {
            startOfLoop = new CodeLabel();
            endOfLoop = new CodeLabel();
        }
    }
    
    
    private static ForRecord topOfForStack;
    
    private static void initialiseForStack() {
        topOfForStack = null;
    }
    
    
    public static void openFor() {
        ForRecord thisFor;
        StackEntry initialExpression;
        StackEntry finalExpression;
        RunTimeAddress temporary = new RunTimeAddress();
        
        if (!suppressCodeGeneration) {
            thisFor = new ForRecord();
            finalExpression = stack.pop();
            initialExpression = stack.pop();
            thisFor.controlVariable = (ReferenceEntry)stack.pop();
            load( initialExpression );
            accessWord( thisFor.controlVariable.refAddress, STORE );
            load( finalExpression );
            /* Save value of FinalExpression in a temporary location */
            temporary = addressFor( integerRepresentation ) ;
            /* Load value of FinalExpression from temporary location */
            accessWord( temporary, STORE );
            Code.newLabel( thisFor.startOfLoop );
            Code.futureLabel( thisFor.endOfLoop );
            accessWord( thisFor.controlVariable.refAddress, LOAD );
            accessWord( temporary, LOAD );
            Code.ins0( CLE );
            Code.jumpIns( BZE, thisFor.endOfLoop );
            StackEntry.freeNode(initialExpression);
            StackEntry.freeNode(finalExpression);
            thisFor.next = topOfForStack;
            topOfForStack = thisFor;
        }
        
    }
    
    
    public static void closeFor() {
        ForRecord thisFor;
        
        if (!suppressCodeGeneration) {
            accessWord( topOfForStack.controlVariable.refAddress, LOAD );
            Code.insD( INCR, (short)1 );
            accessWord( topOfForStack.controlVariable.refAddress, STORE );
            Code.jumpIns( BRN, topOfForStack.startOfLoop );
            Code.expectedLabel( topOfForStack.endOfLoop );
            StackEntry.freeNode(topOfForStack.controlVariable);
            thisFor = topOfForStack;
            topOfForStack = topOfForStack.next;
            thisFor = null;
        }
        
    }
    
    static //initialise
    {
        setScalarRepresentations();
        initialiseBinaryopCodes();
        suppressCodeGeneration = false;
        initialiseFrames();
        initialiseCaseStack();
        initialiseForStack();
    }
}





