/* SymbolType.java  */

public interface SymbolType
  {
  public static final byte
    Identifier = 0, IntegerNumber = 1, CharConstant = 2, Module = 3,
    Var = 4, Procedure = 5, Array = 6, Of = 7, Begin = 8, End = 9,
    If = 10, Then = 11, Else = 12, Case = 13, Loop = 14, Exit = 15,
    For = 16, To = 17, Do = 18, Read = 19, Write = 20,
    Not = 21, And = 22, Or = 23, Div = 24, Times = 25, Plus = 26, Minus = 27,
    LessThan = 28, LessThanOrEqual = 29, GreaterThanOrEqual = 30, GreaterThan = 31,
    NotEquals = 32, Equals = 33,
    RightParenthesis = 34, LeftParenthesis = 35, RightBracket = 36, LeftBracket = 37,
    Comma = 38, Semicolon = 39, Period = 40, Colon = 41,
    Becomes = 42, Thru = 43, Separator = 44,
	While = 45, 	LeftCurlyBracket = 46,  RightCurlyBracket = 47,
    OtherSymbol = 48;
  }


