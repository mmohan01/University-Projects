/* Table2.java : Semantic Table (2) for use with FullAnalyser. */  

/* N.B. Copy this to Table.java before compiling FullAnalyser. */

import java.util.BitSet;

interface TypeClass {
    public static final byte Scalars = 0, Arrays = 1, Unknown = -1;
}


interface IdentifierClass {
    public static final byte Types = 0, Constants = 1, Variables = 2, Procedures = 3;
}


public class Table implements TypeClass, IdentifierClass {
    
    /* The Table module organizes the creation of, location of, and storage recovery    */
    /* from, the identifier and type records which support semantic analysis.           */
    /*                                                                                  */
    /* Scope housekeeping is carried out by calls of the methods openScope() and        */
    /* closeScope() for each block. Between calls of these methods, insertion and       */
    /* lookup of identifiers within the table is provided by the two methods newId(...) */
    /* and searchId(...).                                                               */
    /*                                                                                  */
    /* The creation of type entries is handled by the method newType().                 */
    /*                                                                                  */
    /* The Table module reports errors with the following codes:                        */
    /*                                                                                  */
    /*  76 .... Identifier declared twice                                               */
    /*  77 .... Identifier not declared                                                 */
    /*  78 .... Identifier of wrong class for this context                              */
    
    
    static void idError(short Code) {
        SourceHandler.error(Code, LexicalAnalyser.SymbolDescription.position);
        Generator.noFurtherCode();
    }
    
    /* Recovery from semantic errors is accommodated within the Table data structures   */
    /* and methods as follows:                                                          */
    /*                                                                                  */
    /* (1) If newId(...) finds an entry for the identifier already in the current scope,*/
    /*     an error is flagged but a second entry is still made (for possible selection */
    /*     by searchId(...) as below).                                                  */
    /*                                                                                  */
    /* (2) searchId(...) when called is passed a parameter specifying the acceptable    */
    /*     classes of entry to be found.  If the first entry encountered for the        */
    /*     identifier is not of an acceptable class searching continues within the      */
    /*     current scope for a possible duplicate entry.  If no acceptable duplicate is */
    /*     found in the scope a Misuse error is reported and an anonymous default       */
    /*     entry of acceptable class is returned.                                       */
    /*                                                                                  */
    /* (3) If searchId(...) fails to find an entry in any scope for the identifier      */
    /*     sought, an Undeclared error is reported, and an entry of acceptable class is */
    /*     created for the identifier, with otherwise default attributes.               */
    
    
    
    
    /* TYPE ENTRIES                                                                     */
    /* All types underlying the data defined by the program being compiled are          */
    /* represented by type entries whose form is determined by the "form" of the type   */
    /* so represented (i.e., scalars, arrays, etc.).                                    */
    /* Entries are constructed using a corresponding class TypeEntry.                   */
    /* These type entries are accessed only via the identifier table entries for type-  */
    /* identifiers, or via the representation of the data objects (variables, constants,*/
    /* expressions) whose type they describe.  Thus, for example, all identifier table  */
    /* entries have a common field idType which points to an underlying type entry      */
    /* (with an obvious interpretation for all classes of identifier other than a       */
    /* procedure-identifier).                                                           */
    
    
    public static class TypeEntry {
        private TypeEntry next;
        public Generator.TypeRepresentation representation;
        public byte form;
        
        public TypeEntry(Scope thisScope) {
            this.next = thisScope.typeChain;
            thisScope.typeChain = this;
            
            form = Unknown;
        }
        
        
        /* Unknown types are denoted by nullType */
        
        private static TypeEntry nullType = new TypeEntry();
        
        private TypeEntry() // Private constructor for nullType
        {
            next = null;
            form = Unknown;
        }
        
        public boolean isUndefined() {
            return ( this == nullType );
        }
        
        public static TypeEntry getUndefined() {
            return nullType;
        }
        
    } /* TypeEntry */
    
    
    public static class SimpleTypeEntry extends TypeEntry {
        public SimpleTypeEntry(Scope thisScope) {
            super(thisScope);
            form = Scalars;
        }
    } /* SimpleTypeEntry */
    
    public static class ArrayTypeEntry extends TypeEntry {
        public short indexMin;
        public short indexMax;
        public TypeEntry elementType;
        
        public ArrayTypeEntry(Scope thisScope) {
            super(thisScope);
            form = Arrays;
            indexMin = (short)0;
            indexMax = (short)1;
            elementType = TypeEntry.getUndefined();
        }
    } /* ArrayTypeEntry */
    
    
    public static class IdClassSet extends BitSet {
        public IdClassSet() {
            /* create a BitSet with sufficient bits */
            super(1 + Procedures);
        }
        
        public IdClassSet include(byte id) {
            set(id);
            return this;
        }
        
        public boolean contains(byte id) {
            return (get(id));
        }
    } /* IdClassSet */
    
    
    /* IDENTIFIER ENTRIES                                                                */
    /* An entry is recorded for each identifier, standard or user-defined, which may     */
    /* appear in the program being compiled.  The form of entry depends on the "class"   */
    /* of usage of the identifier and is represented by the class IdentifierEntry.       */
    
    public static class IdentifierEntry {
        public Host.Word name;
        public TypeEntry idType;
        public byte idClass;
        
        public IdentifierEntry(Host.Word spelling) {
            name = spelling;
            idType = TypeEntry.getUndefined();
        }
        
        public IdentifierEntry(Host.Word spelling, byte classNeeded) {
            this(spelling);
            idClass = classNeeded;
        }
        
    } /* IdentifierEntry */
    
    
    public static class ConstantsIdentifierEntry extends IdentifierEntry {
        short constantValue;
        
        public ConstantsIdentifierEntry(Host.Word spelling) {
            super(spelling);
            this.idClass = Constants;
        }
    }
    
    public static class VariablesIdentifierEntry extends IdentifierEntry {
        Generator.RunTimeAddress variableAddress;
        
        public VariablesIdentifierEntry(Host.Word spelling) {
            super(spelling);
            this.idClass = Variables;
        }
    }
    
    public static class ProceduresIdentifierEntry extends IdentifierEntry {
        Generator.ProcedureLinkage linkage;
        
        public ProceduresIdentifierEntry(Host.Word spelling) {
            super(spelling);
            this.idClass = Procedures;
        }
    }
    
    
    /* The identifier table is organized as a set of binary trees, one for each         */
    /* identifier scope currently open.                                                 */
    
    
    private static class IdTree {
        public IdentifierEntry idEntry;
        public IdTree leftLink;
        public IdTree rightLink;
        
        public IdTree(IdentifierEntry theId) {
            IdTree Self = this;
            
            Self.idEntry = theId;
            Self.leftLink = null;
            Self.rightLink = null;
        }
        
        public void insert  (IdTree newEntry) {
            IdTree thisEntry;
            IdTree lastEntry;
            boolean leftTaken;
            Host.Word spelling;
            
            thisEntry = this;
            spelling = newEntry.idEntry.name;
            do
            {
                lastEntry = thisEntry;
                if ( Host.Word.comparisonOf(spelling, thisEntry.idEntry.name) == Host.Word.FirstIsLess ) {
                    thisEntry = thisEntry.leftLink;
                    leftTaken = true;
                } else if ( Host.Word.comparisonOf(spelling, thisEntry.idEntry.name) == Host.Word.SecondIsLess ) {
                    thisEntry = thisEntry.rightLink;
                    leftTaken = false;
                } else {
                    Table.idError( (short)76 );
                    thisEntry = thisEntry.rightLink;
                    leftTaken = false;
                }
            }
            while (thisEntry != null);
            
            if (leftTaken)
                lastEntry.leftLink = newEntry;
            else
                lastEntry.rightLink = newEntry;
        }
    } /* IdTree */
    
    
    /* The nesting of the identifier scopes is represented by a stack of Scope objects.  */
    
    private static class Scope {
        public IdTree firstLocal;
        public TypeEntry typeChain;
        public Scope enclosingScope;
        
        public Scope(Scope theEnclosingScope) {
            this.firstLocal = null;
            this.typeChain = null;
            this.enclosingScope = theEnclosingScope;
        }
        
        public void destroy() {
            disposeIdRecords(this.firstLocal);
            disposeTypeEntrys(this.typeChain);
        }
        
        private void disposeIdRecords(IdTree root) {
            if (root != null) {
                disposeIdRecords(root.leftLink);
                disposeIdRecords(root.rightLink);
                root = null;
            }
        }
        
        private void disposeTypeEntrys(TypeEntry frstType) {
            TypeEntry thisType;
            TypeEntry nextType;
            
            nextType = frstType;
            while (nextType != null) {
                thisType = nextType;
                nextType = thisType.next;
                thisType = null;
            }
        }
    } /* Scope */
    
    
    private static Scope localScope;
    
    public static void openScope() {
        Scope newScope;
        
        newScope = new Scope(localScope);
        localScope = newScope;
    } /* openScope */
    
    public static void closeScope() {
        Scope oldScope;
        
        oldScope = localScope;
        localScope = localScope.enclosingScope;
        oldScope.destroy();
        oldScope = null;
    } /* closeScope */
    
    
    
    public static IdentifierEntry newId(Host.Word spelling, byte classNeeded ) {
        Scope thisScope;
        IdentifierEntry newEntry = null;
        IdTree newNode;
        
        switch (classNeeded) {
            case Types:       newEntry = new IdentifierEntry(spelling, Types);break;
            case Constants:   newEntry = new ConstantsIdentifierEntry(spelling);break;
            case Variables:   newEntry = new VariablesIdentifierEntry(spelling);break;
            case Procedures:  newEntry = new ProceduresIdentifierEntry(spelling);break;
        }
        
        newNode = new IdTree( newEntry );
        
        thisScope = localScope;
        if ( thisScope.firstLocal == null )
            thisScope.firstLocal = newNode;
        else
            thisScope.firstLocal.insert( newNode );
        return newEntry;
    } /* newId */
    
    
    private static byte mostLikelyOf(IdClassSet classes) {
        if (classes.contains(Variables))
            return Variables;
        else if (classes.contains(Procedures))
            return Procedures;
        else if (classes.contains(Types))
            return Types;
        else
            return Constants;
    } /* mostLikelyOf */
    
    
    public static IdentifierEntry searchId(Host.Word spelling,  IdClassSet allowableClasses) {
        IdTree thisTree;
        boolean misUsed;
        Scope thisScope;
        
        misUsed = false;
        thisScope = localScope;
        do
        {
            thisTree = thisScope.firstLocal;
            while ( thisTree != null ) {
                if (Host.Word.comparisonOf(spelling, thisTree.idEntry.name) == Host.Word.FirstIsLess)
                    thisTree = thisTree.leftLink;
                else if ( Host.Word.comparisonOf(spelling, thisTree.idEntry.name) == Host.Word.SecondIsLess)
                    thisTree = thisTree.rightLink;
                else if (allowableClasses.contains(thisTree.idEntry.idClass))
                    return thisTree.idEntry;
                else {
                    misUsed = true;
                    thisTree = thisTree.rightLink;
                }
            }
            if (misUsed) {
                idError( (short)78);
                return defaultEntry[ (mostLikelyOf(allowableClasses)) ];
            }
            thisScope = thisScope.enclosingScope;
        } while (thisScope != null );
        /* Identifier not found */
        idError((short)77);
        return newId(spelling, mostLikelyOf(allowableClasses));
    } /* searchId */
    
    
    /* Each type entry constructed is associated with the current block scope.  All       */
    /* storage allocated to Table entries is recovered at final closure of a block scope. */
    
    public static TypeEntry newType(byte formNeeded)
    
    {
        switch (formNeeded) {
            case Scalars: return new SimpleTypeEntry(Table.localScope);
            case Arrays:  return new ArrayTypeEntry(Table.localScope);
            
            default:      return TypeEntry.getUndefined();
        }
    } /* newType */
    
    
    /* THE METHOD compatible(...)                                    */
    /* To facilitate type analysis within the semantic analyser a    */
    /* general-purpose boolean method compatible() is provided to    */
    /* test the compatibility of two types as represented by         */
    /* variables of the class Table.IdentifierEntry.  A result true  */
    /* is returned if the types are identical (i.e., these           */
    /* variables reference the same type entry), or strictly         */
    /* equivalent (i.e., two distinct type entries of identical form */
    /* and content).                                                 */
    /* Compatible is defined to return true if either of its         */
    /* parameters denotes an undefined type.  In this way normal     */
    /* type analysis can proceed without a preliminary screening for */
    /* indeterminate types at every point at which they might arise. */
    
    public static boolean compatible(TypeEntry type1, TypeEntry type2) {
        if ( type1 == type2 )
            return true;
        else if (( type1.isUndefined()) || ( type2.isUndefined()))
            return true;
        else if ( ( type1.form == Table.Arrays ) && ( type2.form == Table.Arrays ) )
            return (   ( ((ArrayTypeEntry)type1).indexMin ==  ((ArrayTypeEntry)type2).indexMin )
            && ( ((ArrayTypeEntry)type1).indexMax ==  ((ArrayTypeEntry)type2).indexMax )
            && compatible(((ArrayTypeEntry)type1).elementType, ((ArrayTypeEntry)type2).elementType)
            );
        else
            return false;
    } /* compatible */
    
    public static boolean isOrdinalType(TypeEntry type) {
        if (type.isUndefined())
            return true;
        else
            return (type.form == Scalars);
    } /* isOrdinalType */
    
    
    static IdentifierEntry[ ] defaultEntry = new IdentifierEntry[1+Procedures];
    
    static /* Table class initialisation */
    {
        localScope = null;
        
    /* fixed by DMcK
    byte c;
    for (c = Types; ( c <= Procedures ); c += 1)
      defaultEntry[c] = new IdentifierEntry(Host.blankWord, c);
     */
        defaultEntry[Constants]   = new ConstantsIdentifierEntry(Host.blankWord);
        defaultEntry[Variables]   = new VariablesIdentifierEntry(Host.blankWord);
        defaultEntry[Procedures]  = new ProceduresIdentifierEntry(Host.blankWord);
    }
    
} /* Table */




